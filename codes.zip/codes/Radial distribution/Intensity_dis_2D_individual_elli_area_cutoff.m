clear all
x_res=26;
Ellipticity_cutoff = 0.8;
Area_cutoff1 = 300;
Area_cutoff2 = 1000000;

load('speckle_parameter_merged_RGB.mat')

for i=1:9  %update cell number 
    filename = ['speckle2D_RGB_' int2str(i) '.mat'];
    load(filename);
    speckle2D_int=[];
    jj=1;
    for j = 1:speckle2D.N
        Int_dis=[];
        %if cell(1,i).Total(1,j).Area < Area_cutoff1 && cell(1,i).Total(1,j).Ellipticity(1,1) < Ellipticity_cutoff
        %if cell(1,i).Total(1,j).Area < Area_cutoff1 && cell(1,i).Total(1,j).Ellipticity(1,1) < Ellipticity_cutoff
        if cell(1,i).B(1,j).Area >= Area_cutoff1 && cell(1,i).B(1,j).Area < Area_cutoff2 && cell(1,i).B(1,j).Ellipticity(1,1) < Ellipticity_cutoff
           ms = size(speckle2D.R3D{1,j});
           x= cell(1,i).B(1,j).Weighted_Center(1,1);
           y= cell(1,i).B(1,j).Weighted_Center(1,2);
%            x= cell(1,i).G(1,j).Center(1,1);
%            y= cell(1,i).G(1,j).Center(1,2);
           speckle_b=bwboundaries(speckle2D.B3D{1,j});
           xb=speckle_b{1,1}(:,1);
           yb=speckle_b{1,1}(:,2);          
           n=1;
           for m=1:ms(1,1)
               for k=1:ms(1,2)
                   Int_dis(n,1) = sqrt((m-x)^2+(k-y)^2)*x_res;%distance to center;
                   Int_dis(n,2) = speckle2D.R3D{1,j}(m,k); %intensity in R
                   Int_dis(n,3) = speckle2D.G3D{1,j}(m,k); %intensity in G
                   Int_dis(n,4) = speckle2D.B3D{1,j}(m,k); %intensity in B
                   D_r = sqrt((m - xb).^2 + (k - yb).^2);
                   [D_min,I_min]=min(D_r);
                   Int_dis(n,5) = D_min*x_res; %distance to edge;                  
                   Int_dis(n,6) = sqrt((x-xb(I_min))^2 + (y-yb(I_min))^2)*x_res; % edge to center of speckle
                   Int_dis(n,7) = Int_dis(n,5)./Int_dis(n,6);
                   n=n+1;
               end
           end
        end
        
        if isempty(Int_dis)==0 
           speckle2D_int.speckleID{1,jj}=j;
           speckle2D_int.intR{1,jj}=Int_dis;
     
           %radial distribution histogram 
           sel_0=find(Int_dis(:,2)~=0 | Int_dis(:,3)~=0 | Int_dis(:,4)~=0);%%
           xx=(0:100:max(Int_dis(sel_0,1)));
           for q=1:length(xx)-1;
               sel = find(Int_dis(:,1)>=xx(q) & Int_dis(:,1)<xx(q+1));
               PDF_r(q,1) = mean(Int_dis(sel,1));
               PDF_r(q,2) = mean(Int_dis(sel,2));
               PDF_r(q,3) = mean(Int_dis(sel,3));
               PDF_r(q,4) = mean(Int_dis(sel,4));
               PDF_r(q,5) = length(sel);
           end
     
           PDF_r(:,2) = PDF_r(:,2)./sum(PDF_r(:,2));
           PDF_r(:,3) = PDF_r(:,3)./sum(PDF_r(:,3));
           PDF_r(:,4) = PDF_r(:,4)./sum(PDF_r(:,4));  
           speckle2D_int.intR_PDF{1,jj}=PDF_r;
     
           %normalized radial distribution histogram 
           yy=linspace(0,max(Int_dis(sel_0,1)),11);        
           for p=1:length(yy)-1;
               sel = find(Int_dis(:,1)>=yy(p) & Int_dis(:,1)<yy(p+1));
               PDF_nr(p,1) = mean(Int_dis(sel,1));
               PDF_nr(p,2) = mean(Int_dis(sel,2));
               PDF_nr(p,3) = mean(Int_dis(sel,3));
               PDF_nr(p,4) = mean(Int_dis(sel,4));
               PDF_nr(p,5) = length(sel);
           end
     
               PDF_nr(:,2) = PDF_nr(:,2)./sum(PDF_nr(:,2));
               PDF_nr(:,3) = PDF_nr(:,3)./sum(PDF_nr(:,3));
               PDF_nr(:,4) = PDF_nr(:,4)./sum(PDF_nr(:,4));  
               speckle2D_int.intR_PDF_N{1,jj}=PDF_nr;
               
          yyy=linspace(0,max(Int_dis(sel_0,5)),11); 
           for p=1:length(yyy)-1;
               sel = find(Int_dis(:,5)>=yyy(p) & Int_dis(:,5)<yyy(p+1));
               PDF_ne(p,1) = mean(Int_dis(sel,5));
               PDF_ne(p,2) = mean(Int_dis(sel,2));
               PDF_ne(p,3) = mean(Int_dis(sel,3));
               PDF_ne(p,4) = mean(Int_dis(sel,4));
               PDF_ne(p,5) = length(sel);
           end
     
               PDF_ne(:,2) = PDF_ne(:,2)./sum(PDF_ne(:,2));
               PDF_ne(:,3) = PDF_ne(:,3)./sum(PDF_ne(:,3));
               PDF_ne(:,4) = PDF_ne(:,4)./sum(PDF_ne(:,4));  
               speckle2D_int.intR_PDF_E{1,jj}=PDF_ne;     
          clear PDF_r;
          clear PDF_nr;
          clear Int_dis;
          clear Int_ne;
          jj=jj+1;
        end
    end
     
     
     %filename=['speckle2D_int_cell_' int2str(i) '_area' int2str(Area_cutoff1) '.mat'];
     filename=['speckle2D_int_cell_' int2str(i) '_area' int2str(Area_cutoff1) '_' int2str(Area_cutoff2) '.mat'];
     save(filename, 'speckle2D_int');
    clear speckle2D_int
end

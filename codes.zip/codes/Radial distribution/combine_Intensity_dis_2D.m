clear all
n=1;
total_int_r=[];
PDF_nr = zeros(10,3);

for i=1:3 %update cell number 
    filename=['speckle2D_int_cell_' int2str(i) '_area300_5000' '.mat'];
    load(filename);
    if isempty(speckle2D_int)~=1
    ms=size(speckle2D_int.intR);
    for j = 1:ms(1,2)
         total_int_r=[total_int_r;  speckle2D_int.intR{1,j}];
         if  isempty(find(isnan(speckle2D_int.intR_PDF_N{1,j})))
         PDF_nr = PDF_nr(:,1:3) + speckle2D_int.intR_PDF_N{1,j}(:, 2:4);
         end
    n=n+1;
    end
    end
end
save('total_int_r_area300.dat', 'total_int_r','-ascii');

     sel_0=find(total_int_r(:,2)~=0);
     xx=(0:50:max(total_int_r(sel_0,1)));
     for q=1:length(xx)-1;
         sel = find(total_int_r(:,1)>=xx(q) & total_int_r(:,1)<xx(q+1));
         PDF_r(q,1) = mean(total_int_r(sel,1));
         PDF_r(q,2) = mean(total_int_r(sel,2));
         PDF_r(q,3) = mean(total_int_r(sel,3));
         PDF_r(q,4) = mean(total_int_r(sel,4));
         PDF_r(q,5) = length(sel);
     end

         PDF_r(:,2) = PDF_r(:,2)./sum(PDF_r(:,2));
         PDF_r(:,3) = PDF_r(:,3)./sum(PDF_r(:,3));
         PDF_r(:,4) = PDF_r(:,4)./sum(PDF_r(:,4));
         
         PDF_nr(:,2) = PDF_nr(:,2)./sum(PDF_nr(:,2));
         PDF_nr(:,3) = PDF_nr(:,3)./sum(PDF_nr(:,3));
         PDF_nr(:,1) = PDF_nr(:,1)./sum(PDF_nr(:,1));
     
save('total_int_dis_pdf_area300_1000.dat', 'PDF_r','-ascii');
save('total_int_dis_pdf_N_area300_1000.dat', 'PDF_nr','-ascii');
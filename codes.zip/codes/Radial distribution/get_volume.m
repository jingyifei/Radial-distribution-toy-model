function get_volume (N)

V_total=[];
for i=1:N
filename = ['speckle3D_RGB_' int2str(i) '.mat'];
load (filename);
V_total = [V_total; speckle3D.v'];
end
save ('V_total.dat', 'V_total', '-ascii');

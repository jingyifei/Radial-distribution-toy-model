
% note the xy are swapped in this code. row is defined as x, and column is 
%defined as y. therefore the [row, column] format is actually correpsonding to [y,x] in 2D
%specle_1 is for transcription site

function MeanDistance_to_speckle_edge(cell)% for each transcription site in individual cells, find out the distance to all speckles
[r,c]=size(cell);
cellID = c;
res_XY=0.026

rad = [];
k = 1;

for i=1:cellID
    [r1,c1]=size(cell(i).R);
    specID = c1;
    filename = ['speckle_RNA_merged_' int2str(i) '.mat'];
    spec = load(filename);
    
    for j = 1:specID
        if (cell(i).R(j).Intensity ~= 0) & (cell(i).G(j).Intensity ~= 0)
           x_r = cell(i).R(j).Weighted_Center(1,1);
           y_r = cell(i).R(j).Weighted_Center(1,2);
           x_g = cell(i).G(j).Weighted_Center(1,1);
           y_g = cell(i).G(j).Weighted_Center(1,2);
           x_b = cell(i).B(j).Weighted_Center(1,1);
           y_b = cell(i).B(j).Weighted_Center(1,2);
           rad(k,1)=sqrt((x_r-x_b)^2+(y_r-y_b)^2)*res_XY; %red distance to center
           rad(k,2)=sqrt((x_g-x_b)^2+(y_g-y_b)^2)*res_XY; %green distance to center
           
           [r2,c2]=find(spec.speckle_RNA_merged.B3D_peri{1,j}==1);
           
           D_r = sqrt((x_r - r2).^2 + (y_r - c2).^2);
           rad(k,3) = min(D_r)*res_XY; %red distance to edge;
           D_r_min = find(min(D_r));
           rad(k,4) = sqrt((x_b-r2(D_r_min))^2 + (y_b-c2(D_r_min))^2)*res_XY; % edge to center of speckle
           rad(k,5) = rad(k,1)-rad(k,4); % red to center - edge to center, positive-> red is outside, negataive -> inside
           
           
           D_g = sqrt((x_g - r2).^2 + (y_g - c2).^2);
           rad(k,6) = min(D_g)*res_XY; %green distance to edge;
           D_g_min = find(min(D_g));
           rad(k,7) = sqrt((x_b-r2(D_g_min))^2 + (y_b-c2(D_g_min))^2)*res_XY; % edge to center of speckle
           rad(k,8) = rad(k,2)-rad(k,7); % red to center - edge to center, positive-> red is outside, negataive -> inside
           
           rad(k,9) = rad(k,5)/rad(k,4); %normalized position
           rad(k,10) = rad(k,8)/rad(k,7); %normalized position
           rad(k,11) = rad(k,1)/rad(k,4); %normalized position
           rad(k,12) = rad(k,2)/rad(k,7); %normalized position
           
           rad(k,13) = cell(i).R(j).Area; % size of RGB signal
           rad(k,14) = cell(i).G(j).Area;
           rad(k,15) = cell(i).B(j).Area;
           
           rad(k,16) = cell(i).R(j).Intensity; % size of RGB signal
           rad(k,17) = cell(i).G(j).Intensity;
           rad(k,17) = cell(i).B(j).Intensity;
           
        k=k+1; 
        end
    end       
end
mean_R_center = mean(rad(:,1))
mean_G_center = mean(rad(:,2))
mean_R_edge = mean(rad(:,3))
mean_G_edge = mean(rad(:,7))
mean_R_NP = mean(rad(:,9))
mean_G_NP = mean(rad(:,10))
mean_R_ND = mean(rad(:,11))
mean_G_ND = mean(rad(:,12))

save ('distance_to_speckle.dat','rad','-ascii');



% note the xy are swapped in this code. row is defined as x, and column is 
%defined as y. therefore the [row, column] format is actually correpsonding to [y,x] in 2D

clear all
close all
clc

field1 = 'R';
field2 = 'G';
field3 = 'B';
field4 = 'Total';
cell = struct(field1, [], field2, [], field3, [], field4, []);

field5 = 'Center'; % For each Channel
field6 = 'Weighted_Center'; % For each channel

field7 = 'Intensity'; % Total over all channels
field8 = 'Ellipticity'; % Total over all channels
field9 = 'Area';

for cell_id = 1:1
    
    cell_file = strcat(['speckle2D_RGB_', num2str(cell_id), '.mat']);
   
    load(cell_file)
    
    cell(cell_id).R = struct(field5, [], field6, [], field7, [], field8, [], field9, []);
    cell(cell_id).G = struct(field5, [], field6, [], field7, [], field8, [], field9, []);
    cell(cell_id).B = struct(field5, [], field6, [], field7, [], field8, [], field9, []);
%     cell(cell_id).Total = struct(field7, [], field8, [], field9, [], field5, []);
    
    for speckle_id = 1:speckle2D.N
        
%         Total_Cell = double(speckle2D.R3D{1,speckle_id} + speckle2D.G3D{1,speckle_id}...
%                         + speckle2D.B3D{1,speckle_id});
        
        cell(cell_id).R(speckle_id).Center = cellCenter(bwconvhull(speckle2D.R3D{1,speckle_id}),1);
        cell(cell_id).G(speckle_id).Center = cellCenter(bwconvhull(speckle2D.G3D{1,speckle_id}),1);
        cell(cell_id).B(speckle_id).Center = cellCenter(bwconvhull(speckle2D.B3D{1,speckle_id}),1);
    
        cell(cell_id).R(speckle_id).Weighted_Center = weightedCenter(double(speckle2D.R3D{1,speckle_id}),bwconvhull(speckle2D.R3D{1,speckle_id}),1);
        cell(cell_id).G(speckle_id).Weighted_Center = weightedCenter(double(speckle2D.G3D{1,speckle_id}),bwconvhull(speckle2D.G3D{1,speckle_id}),1);
        cell(cell_id).B(speckle_id).Weighted_Center = weightedCenter(double(speckle2D.B3D{1,speckle_id}),bwconvhull(speckle2D.B3D{1,speckle_id}),1);
        
        cell(cell_id).R(speckle_id).Intensity = sum(speckle2D.R3D{1,speckle_id}(:));
        cell(cell_id).G(speckle_id).Intensity = sum(speckle2D.G3D{1,speckle_id}(:));
        cell(cell_id).B(speckle_id).Intensity = sum(speckle2D.B3D{1,speckle_id}(:));
        
%         cell(cell_id).R(speckle_id).Ellipticity = cellEllipse(bwconvhull(speckle2D.R3D{1,speckle_id}),1);
%         cell(cell_id).G(speckle_id).Ellipticity = cellEllipse(bwconvhull(speckle2D.G3D{1,speckle_id}),1);
        cell(cell_id).B(speckle_id).Ellipticity = cellEllipse(bwconvhull(speckle2D.B3D{1,speckle_id}),1);
        
        cell(cell_id).R(speckle_id).Area = cellArea(bwconvhull(speckle2D.R3D{1,speckle_id}),1);
        cell(cell_id).G(speckle_id).Area = cellArea(bwconvhull(speckle2D.G3D{1,speckle_id}),1);
        cell(cell_id).B(speckle_id).Area = cellArea(bwconvhull(speckle2D.B3D{1,speckle_id}),1);
        
%         cell(cell_id).Total(speckle_id).Intensity = sum(Total_Cell(:));
%         cell(cell_id).Total(speckle_id).Ellipticity = cellEllipse(bwconvhull(Total_Cell),1);
%         cell(cell_id).Total(speckle_id).Center = cellCenter(bwconvhull(Total_Cell),1);
%         cell(cell_id).Total(speckle_id).Area = cellArea(bwconvhull(Total_Cell),1);
        
        clear Total_Cell 
    end
    
    clear cell_file speckle2D
end
save ('speckle_parameter_merged_RGB.mat', 'cell');
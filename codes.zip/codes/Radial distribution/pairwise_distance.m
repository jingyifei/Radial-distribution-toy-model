clear all
n=1;
pairwise_D=[];
pairwise_Dn=[];
pairwise_De=[];
x_res=26;
%pairwise_ND = [];

for i=1:9 %update cell number 
    filename=['speckle2D_int_cell_' int2str(i) '_area300_1000000' '.mat'];
    load(filename);
    if isempty(speckle2D_int)~=1
    ms=size(speckle2D_int.intR);
    for j = 1:ms(1,2)
         R_D = sum(speckle2D_int.intR{1,j}(:,1).*speckle2D_int.intR{1,j}(:,2))/sum(speckle2D_int.intR{1,j}(:,2));
         G_D = sum(speckle2D_int.intR{1,j}(:,1).*speckle2D_int.intR{1,j}(:,3))/sum(speckle2D_int.intR{1,j}(:,3));
         B_D = sum(speckle2D_int.intR{1,j}(:,1).*speckle2D_int.intR{1,j}(:,4))/sum(speckle2D_int.intR{1,j}(:,4));
         B_int=speckle2D_int.intR{1,j}(:,4);
         B_area=length(nonzeros(B_int));
         R_Dn=R_D/(x_res*sqrt(B_area));
         G_Dn=G_D/(x_res*sqrt(B_area));
         B_Dn=B_D/(x_res*sqrt(B_area));
         D = [R_D, G_D, B_D];
         Dn=[R_Dn, G_Dn, B_Dn];
         R_De = sum(speckle2D_int.intR{1,j}(:,5).*speckle2D_int.intR{1,j}(:,2))/sum(speckle2D_int.intR{1,j}(:,2));
         G_De = sum(speckle2D_int.intR{1,j}(:,5).*speckle2D_int.intR{1,j}(:,3))/sum(speckle2D_int.intR{1,j}(:,3));
         B_De = sum(speckle2D_int.intR{1,j}(:,5).*speckle2D_int.intR{1,j}(:,4))/sum(speckle2D_int.intR{1,j}(:,4));
         R_De=R_De/(x_res*sqrt(B_area));
         G_De=G_De/(x_res*sqrt(B_area));
         B_De=B_De/(x_res*sqrt(B_area));
         De=[R_De, G_De, B_De];
         pairwise_D=[pairwise_D; D];
         pairwise_Dn=[pairwise_Dn; Dn];
         pairwise_De=[pairwise_De; De];

    end
    end
end
save('pairwise_distance.dat', 'pairwise_D','-ascii');
save('A1_pairwise.mat','pairwise_D','pairwise_Dn','pairwise_De')

function area = cellArea(objects, id, varargin)

% varargin = Pixel Area =  length/pixel

[row,col] = size(objects);
object_i = objects == id;
object_i(1,:) = 0; object_i(row,:) = 0; object_i(:,1) = 0;object_i(:,col)=0;
pixels = sub2ind(size(object_i),find(object_i));
area = 0;


for i = 1:length(pixels)
    [x,y] = ind2sub(size(object_i),pixels(i));
    
    neighbor_pixels = object_i(x-1,y)+object_i(x+1,y)+object_i(x,y-1)+object_i(x,y+1);
    if neighbor_pixels == 1;
        area= area + .25;
        
        % Case 2 : 2 neighbors. Area weight = 1/2
    elseif neighbor_pixels == 2
        area = area + .5;
        
        % Case 3 : 3 neighbors. Area weight = 3/4
    elseif neighbor_pixels == 3
        area = area + .75;
        
        % Case 4 : Fully Surrounded. Area weight = 1
    elseif neighbor_pixels == 4
        area = area + 1;
        
    end
end

if nargin == 3
    pix_area = varargin{1};
    pix_area = pix_area^2;
    area = pix_area * area;
end

area;



end
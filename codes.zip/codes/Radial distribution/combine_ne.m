clear cell
PDF_ne = cell(10,3);

for i=1:9 %update cell number
    filename=['speckle2D_int_cell_' int2str(i) '_area300_1000000' '.mat'];
    load(filename);
    if isempty(speckle2D_int)~=1
        ms=size(speckle2D_int.intR);
        for j = 1:ms(1,2)
            if  isempty(find(isnan(speckle2D_int.intR_PDF_E{1,j})))
                for k=1:10
                    PDF_ne{k,1} = [PDF_ne{k,1};speckle2D_int.intR_PDF_E{1,j}(k,2)];
                    PDF_ne{k,2} = [PDF_ne{k,2};speckle2D_int.intR_PDF_E{1,j}(k,3)];
                    PDF_ne{k,3} = [PDF_ne{k,3};speckle2D_int.intR_PDF_E{1,j}(k,4)];
                end
            end
        end
    end
end

n_spec=length(PDF_ne{1,1});
PDF_se=zeros(10,3);
PDF_mean=zeros(10,3);
for k=1:10
    PDF_se(k,1)=std(PDF_ne{k,1})/sqrt(n_spec);
    PDF_mean(k,1)=mean(PDF_ne{k,1});
    PDF_se(k,2)=std(PDF_ne{k,2})/sqrt(n_spec);
    PDF_mean(k,2)=mean(PDF_ne{k,2});
    PDF_se(k,3)=std(PDF_ne{k,3})/sqrt(n_spec);
    PDF_mean(k,3)=mean(PDF_ne{k,3});
end
figure
errorbar(0.1:0.1:1,PDF_mean(:,1),PDF_se(:,1),'r')
% hold on
% errorbar(0.1:0.1:1,PDF_mean_1(:,2),PDF_std_1(:,2),'g')
% hold on
% errorbar(0.1:0.1:1,PDF_mean_1(:,3),PDF_std_1(:,3),'b')
% hold on
% errorbar(0.1:0.1:1,PDF_mean(:,1),PDF_std(:,1),'r')
hold on
errorbar(0.1:0.1:1,PDF_mean(:,2),PDF_se(:,2),'g')
hold on
errorbar(0.1:0.1:1,PDF_mean(:,3),PDF_se(:,3),'b')
save('combine_A1_ne.mat','PDF_ne','PDF_mean','PDF_se')
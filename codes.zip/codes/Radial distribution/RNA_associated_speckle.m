function RNA_associated_speckle(cell_ID)
% generate fused speckle2D file of RNA-associated speckles.

for k=1:cell_ID % cell ID 
    
    filename = ['speckle2D_B_' int2str(k) '.mat'];
    speckle2D_spec = load (filename); % speckle 
   
    filename = ['speckle2D_RG_' int2str(k) '.mat'];
    speckle2D_RNA =load (filename); % RNA
    
    n=0;
%     speckle_RNA_merged.N = 0;
   speckle_RNA_merged.imgclass = 'unit16';
    
    [r1,c1] = size (speckle2D_RNA.speckle2D.Pobj3D);
    [r2,c2] = size (speckle2D_spec.speckle2D.Pobj3D);
    for i=1:r1
        for l=1:r2
            overlap = intersect(speckle2D_RNA.speckle2D.Pobj3D(i).PixelList, speckle2D_spec.speckle2D.Pobj3D(l).PixelList, 'rows');
            if isempty(overlap) == 0 % overlapping space between RNA and speckle
                n=n+1;
                speckle_RNA_merged.N = n;
                
                speckle_RNA_merged.x_RNA(n)= speckle2D_RNA.speckle2D.x(i);
                speckle_RNA_merged.y_RNA(n)= speckle2D_RNA.speckle2D.y(i);
                speckle_RNA_merged.x_spec(n)= speckle2D_spec.speckle2D.x(l);
                speckle_RNA_merged.y_spec(n)= speckle2D_spec.speckle2D.y(l);
                
                speckle_RNA_merged.v_RNA(n)= speckle2D_RNA.speckle2D.v(i);
                speckle_RNA_merged.v_spec(n)= speckle2D_spec.speckle2D.v(l);
                
                speckle_RNA_merged.R3D{1,n} = speckle2D_RNA.speckle2D.R3D_2{1,i};
                speckle_RNA_merged.G3D{1,n} = speckle2D_RNA.speckle2D.G3D_2{1,i};
                speckle_RNA_merged.B3D{1,n} = speckle2D_spec.speckle2D.B3D_2{1,l};
                
                speckle_RNA_merged.R3D_peri{1,n} = bwperim(speckle2D_RNA.speckle2D.R3D_2{1,i});
                speckle_RNA_merged.G3D_peri{1,n} = bwperim(speckle2D_RNA.speckle2D.G3D_2{1,i});
                speckle_RNA_merged.B3D_peri{1,n} = bwperim(speckle2D_spec.speckle2D.B3D_2{1,l});
                
                speckle_RNA_merged.Pobj3D_RNA(n)= speckle2D_RNA.speckle2D.Pobj3D(i);
                speckle_RNA_merged.Pobj3D_spec(n)= speckle2D_spec.speckle2D.Pobj3D(l);
                
            end
        end
        speckle_RNA_merged.I_R3D = speckle2D_RNA.speckle2D.I_R3D;
        speckle_RNA_merged.I_G3D = speckle2D_RNA.speckle2D.I_G3D;
        speckle_RNA_merged.I_B3D = speckle2D_spec.speckle2D.I_R3D;    
    end
    filename = ['speckle_RNA_merged_' int2str(k) '.mat'];
    save(filename,'speckle_RNA_merged');    
    clear speckle_RNA_merged
end


    
                
        
    

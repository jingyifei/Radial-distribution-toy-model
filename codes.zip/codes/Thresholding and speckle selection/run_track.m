close all;
% clear all;

fp_frame = 'd:\Postdoc\Projects\Codes\ImageProcessing\testing folder\isolated c2_500_068';
fp_data  = 'd:\Postdoc\Projects\Codes\ImageProcessing\testing folder\isolated c2_500_068';
fp_vid   = 'd:\Postdoc\Projects\Codes\ImageProcessing\testing folder\isolated c2_500_068';
% fp_frame = 'C:\Users\Isaac\Desktop\Isaac\Postdoc\Projects\Codes\ImageProcessing\testing folder';
% fp_data  = 'C:\Users\Isaac\Desktop\Isaac\Postdoc\Projects\Codes\ImageProcessing\testing folder';
% fp_vid   = 'C:\Users\Isaac\Desktop\Isaac\Postdoc\Projects\Codes\ImageProcessing\testing folder';

fn='iso-c2_500_068-39_big.avi';
% fn='c2_500_068.avi';
[pathstr,name,ext]=fileparts(fn);
fn_track	= [name '.track'];	
fn_bin		= [name '_bin.sparse'];
fn_box		= [name '_box.sparse'];
fn_cen		= [name '_cen.sparse'];
fn_P		= [name '.P'];
fn_video	= [name '_vid.mp4'];

f1=1;
f2=10000;
%% Analysis full movies
% [frames,Pmov]						= avi2frame(fp_frame,fn,f1,f2);
% 
% T.binary	= 1.5;
% T.dust		= 100;
% [Pobj,I_Binary,I_Box,I_Centroid]	= cellID(frames,T);
% 
% T.trackRadius	= 10;
% T.length		= 5;	% track length <5 removed
% T.borderSize	= 25;
% longTracks							= cellTrack(Pobj,Pmov,T);
% 
% T.quality	= 0.3;
% T.distx		= 20;
% T.area		= 1500;
% longTracks							= analyzeTracks(longTracks,T);
% 
% writeTracks(longTracks, fp_data, fn_track);
% writeSparse(I_Binary,fp_data,fn_bin);
% writeSparse(I_Box,fp_data,fn_box);
% writeSparse(I_Centroid,fp_data,fn_cen);
% writeProperties(Pobj, Pmov, fp_data, fn_P);
% writeCompositeVideo(frames,Pmov,I_Binary,I_Box,I_Centroid,longTracks,fp_vid,fn_video,T);

%% Reading from saved files
% longTracks		= readTracks(fp_data,fn_track);
% I_Binary		= readSparse(fp_data,fn_bin);
% I_Box			= readSparse(fp_data,fn_box);
% I_Centroid		= readSparse(fp_data,fn_cen);
% [Pobj,Pmov]		= readProperties(fp_data,fn_P);

% T.quality	= 0;
% T.distx		= 0;
% T.area		= 5000;
% writeCompositeVideo(frames,Pmov,I_Binary,I_Box,I_Centroid,longTracks,fp_vid,fn_video,T);
% at = analyzeTracks(longTracks);

%% Create isolated movies
% [frames,Pmov] = avi2frame(fp_frame,fn,f1,f2);
% [Pobj,Pmov]	= readProperties(fp_data,fn_P);
% longTracks = readTracks(fp_data,fn_track);
% 
% T.quality	= 0.3;
% T.distx		= 20;
% T.area		= 1500;
% longTracks	= analyzeTracks(longTracks,T);
% 
% I_Binary		= readSparse(fp_data,fn_bin);
% 
% T.cropBox	= 20;
% T.length	= 50;
% T.quality	= 0.3;
% T.distx		= 50;
% T.area		= 1500;
% T.borderSize= 25;
% T.crop		= 0;
% isoframes	= cellIsolate(frames,I_Binary,Pobj,Pmov,longTracks,T);
% 
% writeIsoframes(isoframes,Pmov,fp_frame,fn);

%% Analyzing isolated movie
[frames,Pmov]						= avi2frame(fp_frame,fn,f1,f2);

T.binary	= 3.5;
T.dust		= 10;
[Pobj,I_Binary,I_Box,I_Centroid]	= cellID(frames,T);

T.trackRadius	= 60;
T.length		= 3;	% track length <5 removed
T.borderSize	= 25;
isoTracks							= cellTrack(Pobj,Pmov,T);

T.quality	= 0;
T.distx		= 500;
T.area		= 5000;
isoTracks							= analyzeTracks(isoTracks,T);

% T.quality	= 0;
% T.distx		= 100;
% T.area		= 5000;
% writeCompositeVideo(frames,Pmov,I_Binary,I_Box,I_Centroid,longTracks,fp_vid,fn_video,T);
% 




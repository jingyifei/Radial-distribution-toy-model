% eyample: [I1,I2]=imageSplit(I,Nx,Ny)
% I1:	1 dimensional cell arrax of images
% I2:	2 dimensional cell arrax of images indeyed bx Ny,Nx
% I:	large image
% Ny:	# of splits in y
% Nx:	# of splits in x

function [I1,I2]=imageSplit(I,Nx,Ny)
	bigy=size(I,1);
	bigx=size(I,2);
	smally=floor(bigy/Ny);
	smallx=floor(bigx/Nx);
	counter=0;
	
	for(i=1:Ny)
		for(j=1:Nx)
			counter=counter+1;
			y1=(i-1)*smally+1;
			y2=i*smally;
			x1=(j-1)*smallx+1;
			x2=j*smallx;
			I1{counter}=I(y1:y2,x1:x2);
			I2{i,j}=I(y1:y2,x1:x2);
		end
	end
end
function [fn,results] = batch_analyzeTracks(filepath)
	fn = filelist(filepath,'*.track');
	N_files = size(fn,2);
	results = [];
	histaxis = -10:0.1:10;
	results.hist_axis = histaxis;
	for i=1:N_files		
		fprintf('analyzeTracks_batch: processing %s\r',fn{i});
		% filenames
		[pathstr,name,ext] = fileparts(fn{i});
		
		
		% OPTION 1: load track file directly
		fn_track = [name '.track'];
		tracks	= readTracks2(filepath,fn_track);
		
		% OPTION 2: re-analyze and stich together tracks using new parameters
% 		fn_P = [name '.P'];
% 		fn_track = [name '.track'];
% 		[Pobj, Pmov] = readProperties(filepath, fn_P);
% 		
% 		T.trackRadius	= 10;
% 		T.duration		= 100;
% 		T.borderSize	= 10;
% 		T.weight		= 0.8;
% 		T.alpha			= 0.1;
% 		T.newObjQuality	= 0.3;
% 		T.temporal		= 10;
% 		tracks = cellTrack2(Pobj,Pmov,T);
% 		
% 		writeTracks2(tracks, filepath, fn_track);% write tracks to file
		
		% basic analysis of tracks
		T.quality	= 0.3;
		T.distx		= 20;
		T.area		= 1500;
		T.duration  = 1000;
		P.fps		= 20;		% fps
		P.pixelSize = 1600;		% um/pixel
		goodTracks = analyzeTracks2(tracks,T,P);
		
		% further analyze results from analyzeTracks
		N_tracks = size(tracks,2);
		results.hist_dxx(i,:)	= hist([],histaxis);
		results.hist_dyy(i,:)	= hist([],histaxis);
		results.hist_d(i,:)		= hist([],histaxis);
		results.quality{i}		= [];
		results.d{i}			= [];
		results.dx{i}			= [];
		results.dy{i}			= [];
		results.dxx{i}			= [];
		results.dyy{i}			= [];
		results.angle{i}		= [];
		results.area{i}			= [];
		
		qt = 0;	%qualified track
		for t=1:N_tracks
			%only good ones allowed in the statistics
			if mean(tracks{t}.quality)>0.3 && sum(tracks{t}.dxx)>20
				qt = qt+1;
				results.L(i,qt)			= tracks{t}.length;
				% mean values of each track
				results.mean_quality(i,qt)	= mean(tracks{t}.quality);
				results.mean_d(i,qt)		= mean(tracks{t}.d);
				results.mean_dx(i,qt)		= mean(tracks{t}.dx);
				results.mean_dy(i,qt)		= mean(tracks{t}.dy);
				results.mean_dxx(i,qt)		= mean(tracks{t}.dxx);
				results.mean_dyy(i,qt)		= mean(tracks{t}.dyy);
				results.mean_angle(i,qt)	= mean(tracks{t}.angle);
				results.mean_area(i,qt)		= mean(tracks{t}.area);
				% all points along all tracks in each movie
				% N entries
				results.quality{i}		= cat(2,results.quality{i},tracks{t}.quality);
				results.area{i}			= cat(2,results.area{i},tracks{t}.area);
				% N-1 entries
				results.d{i}			= cat(2,results.d{i},tracks{t}.d);
				results.dx{i}			= cat(2,results.dx{i},tracks{t}.dx);
				results.dy{i}			= cat(2,results.dy{i},tracks{t}.dy);
				results.dxx{i}			= cat(2,results.dxx{i},tracks{t}.dxx);
				results.dyy{i}			= cat(2,results.dyy{i},tracks{t}.dyy);
				results.angle{i}		= cat(2,results.angle{i},tracks{t}.angle);
				
			end
		end
		% histogram of all points along tracks in each file
		results.hist_quality(i,:)	= hist(results.quality{i},histaxis);
		results.hist_d(i,:)			= hist(results.d{i},histaxis);
		results.hist_dx(i,:)		= hist(results.dx{i},histaxis);
		results.hist_dy(i,:)		= hist(results.dy{i},histaxis);
		results.hist_dxx(i,:)		= hist(results.dxx{i},histaxis);
		results.hist_dyy(i,:)		= hist(results.dyy{i},histaxis);
		results.hist_angle(i,:)		= hist(results.angle{i},histaxis);
		results.hist_area(i,:)		= hist(results.area{i},histaxis);
		

		fprintf('analyzeTracks_batch: %d qualified tracks\r\r',qt);
		close all;
	end
end
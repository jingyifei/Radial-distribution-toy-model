% example: [labelRGB,count]=cellcount(I);
function [labelRGB,count]=cellcountI(I)
	I2=imadjust(I);							%Step 1: Auto contrast
	background = imopen(I2,strel('disk',5));		%Step 2: Use Morphological Opening to Estimate the Background, good images, 5 is good, bad fat images, 10
	I3 = I2 - background;							%Step 3: Subtract the Background Image from the Original Image
	I3 = imadjust(I3);

	level = graythresh(I3)*0.8;						%Step 5: Threshold the Image, 0.8 works for lots of cells, 2 for few cells
	Ibw = im2bw(I3,level);
	Ibw = bwareaopen(Ibw, 50);						%Step 5.2: kill the little specs, don't go too high, might erode real objects

	cc = bwconncomp(Ibw, 8);						%Step 6: Identify Objects in the Image
	count=cc.NumObjects;

	label = labelmatrix(cc);						%Step 7: View All Objects
	labelRGB = label2rgb(label, @spring, 'c', 'shuffle');	
end
% example: [imagesFlat,f,fz]=imageFlatten(images,index); 
% to overlay and flatten images{} indices 1,3,5,7,9

% Microscope images, esp. bright field images might be unevely illuminated.
% this program corrects for the general "tilt" of the image intensity by
% overlapping a lot of images of the same illumination first, find a low
% order polynomial fit, then subtract it from the image.
% This function only flattens image indices specified, and leaves the rest
% unchanged. returned I_flat has same dimension as input images
% images:	images in cell array: images{i}
% index:	specifies the image indices in images{i} to be processed
%			e.g. [1,3,5,7,9]

function [imagesFlat,f,fz]=imageFlatten(images,order,index)
	if(nargin<3)
		index=1:1:size(images,2);
	end
	
	close all;
	
	%% overlapping images
	I_int=zeros(size(images{1}),'uint32');
	I_dbl=zeros(size(images{1}),'double');
	N1=size(index,2);
	
	for i=1:N1
		I_int=I_int+cast(images{index(i)},'uint32');		%uint32 precision
		% I_dbl=I_dbl+im2double(images{index(i)});			%0-1 double precision
	end
	I_int=I_int/N1;
	I_int=cast(I_int,'uint8');
	
	figure;
	imshow(imadjust(I_int));
	drawnow;
	
	%% fitting surface to the overlapped images
	for i=1:size(I_int,1)
		for j=1:size(I_int,2)
			x(i,j)=i;
			y(i,j)=j;
		end
	end
	lx=cast(x(:),'double');		% linearize 2D matrix
	ly=cast(y(:),'double');
	lz=cast(I_int(:),'double');
	switch order
		case 1
			f=fit([lx,ly],lz,'poly11');
		case 2
			f=fit([lx,ly],lz,'poly22');
		case 3
			f=fit([lx,ly],lz,'poly33');
		case 4
			f=fit([lx,ly],lz,'poly44');
		case 5
			f=fit([lx,ly],lz,'poly55');
		otherwise
			f=fit([lx,ly],lz,'poly33');
	end
			
	
	fz=feval(f,x,y);			% result of the fit plane
	fz_mean=mean2(fz);			% mean value of the fit plane
	
	figure;
	plot(f,[lx,ly],lz);
	figure;
	plot(f);
	drawnow;
	
	%% flattening image
	N2=size(images,2);
	for i=1:N2
		if ismember(i,index)==1
			imagesFlat{i}=cast(images{i},'double')-fz+fz_mean;
			imageMin = min(imagesFlat{i}(:));	%minimal value might be negative
			imagesFlat{i}=cast(imagesFlat{i} - imageMin,'uint8');
		else
			imagesFlat{i}=cast(images{i},'uint8');	% no change to images not in index
		end
		%imagesFlat{i}=imadjust(imagesFlat{i});	%bad for small bright dots of cells
		%imagesFlat{i}=imageAdjust(imagesFlat{i});
	end
	
	%% display (optional)
	%imageTile(imagesFlat,index,'index',0);
end
% example:	imageTile(images,index,'short',count,4);

% images:   images must be a cell array of images, i.e. opening with images{i}
% index:	index array of the image
% showLabel:'nolabel' 'all' 'short' 'index' 'count', default = 'all'
% count:	array or cell count corresponding to the images cell array. (use
%			cellcount.m)
% Ncolume:	user specify the number of columes

function imageTile(images,index,showLabel,count,numCol)	
	%% Input handling
	if(nargin<4)
		count=zeros(size(images,2));			%cell count array
	end
	if(nargin<3)
		showLabel='all';
	end
	if(nargin<2)
		index=1:size(images,2);				%full range
	end
	if(nargin==0)
		fprintf('ERROR! no input images\r');	%no imput
		return;
	end

	N_range=size(index,2);
	N_column=ceil(sqrt(N_range));
	
	
	if(nargin==5)
		N_column=numCol;				% forcing N_column as specified
	end
	
	%% Plotting stack images
	width=1/N_column;					% width of the grid
	height=1/ceil(N_range/N_column);	% height of the grid
	scale=0.9;							% this is the actual image size as percentage of the grid
	
	figure;
	for i=1:N_range
		col=mod((i-1),N_column);
		row=floor((i-1)/N_column);
		
		left=col*width+(1-scale)/2*width;
		bottom=row*height+(1-scale)/2*height;
		subplot('Position',[left,bottom,scale*width,scale*height]);
		%imshow(imadjust(images{index(i)}));
		imshow(images{index(i)});
		
		%show or not show label
		switch showLabel
			case 'nolabel'
				txt='';
			case 'all'
				txt=sprintf('index:%d \ncellcount:%d',index(i),count(index(i)));
			case 'short'
				txt=sprintf('%d:%d',index(i),count(index(i)));
			case 'index'
				txt=sprintf('index:%d',index(i));
			case 'count'
				txt=sprintf('cellcount:%d',count(index(i)));
			otherwise
				txt=sprintf('index:%d \ncellcount:%d',index(i),count(index(i)));
		end
		text(10,50,txt,'FontWeight','bold','Color','w');
	end
end
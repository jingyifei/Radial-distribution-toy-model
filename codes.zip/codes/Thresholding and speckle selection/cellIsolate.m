% cellIsolate crops original movie around each cell, and look at the cells
% motion in its own frame of reference. 
% Author: Isaac Li
% Date: 2014-07-31
% Version history:
% v1.2 - removed unnecessary threshold, now using goodTracks from
%		 analyzeTracks2 to quality control tracks. only doing so, we can
%		 correlate the cropped movies to the tracks. otherwise, tracks
%		 won't be able to correlate.
% v1.1 - modified tracks from cell type {} object to list (), for
%		 compatibility with cellTrack2 series functions
% v1.0 - basic follow existing tracks to find center and crop.
%
% Inputs:
%	frames	: frames{i} is the original 512x512 matrix image, from avi2frame
%	Pobj	: object properties of each frame
%	Pmov	: movie properties of original movie
%	tracks	: isolated tracks from cellTrack
%	T		: threshold values:
% 				T.cropBox		- size of crop box
% 				T.borderSize	- size around border
%				T.crop			- whether to produce cropped images using
%								  I_Binary
%
% Outputs:
%	isoframes : isolated 41x41 frame j for each object i isoframes(i).frames{j}
%				to get all frames use f = isoframes(i).frames;

function isoframes = cellIsolate(frames,I_Binary,Pobj,Pmov,tracks,T)
	%% THRESHOLD ASSIGNMENT
	% default values of each threshold
	cropBox = 20;				% this is the 'radius size' of the box enclosing each cell from x-cropBox to x+cropBox, y-cropBox to y+cropBox, an area of 1600, should be fine for most cells.
	borderSize = 25;			% within 25 pixel to all border, tracks are not considered because cell may not be completely in the frame
	crop = 0;					% default don't crop the raw movie by the binary file
	if nargin == 6
		if isfield(T,'cropBox') == 1
			cropBox = T.cropBox;
		end
		if isfield(T,'borderSize') == 1
			borderSize = T.borderSize;
		end
		if isfield(T,'crop') == 1
			crop = T.crop;
		end
	end
	
	dimy = Pmov.dimy;			% size of the movie frame
	dimx = Pmov.dimx;			% size of the movie frame
	x_low = borderSize;			% border limites
	x_high = dimy - borderSize;	% border limites
	y_low = borderSize;			% border limites
	y_high = dimy - borderSize;	% border limites
	
	fprintf('cellIsolate: isolating cells in their ref. frame with criteria:\r');
	fprintf('                cropBox: %d x %d px\r',cropBox*2+1);
	fprintf('             borderSize: %d px \r',borderSize);

	
	
	N_tracks = length(tracks);
	for t = 1:N_tracks
		L = tracks(t).length;
		Q = mean(tracks(t).quality);
		A = mean(tracks(t).area);
		X = sum(tracks(t).dx);
		
		fprintf('%d ',t);
		for i = 1:L
			x = tracks(t).x(i);
			y = tracks(t).y(i);
			isoframes(t).frames{i} = uint8(zeros(2*cropBox + 1));	% ensures no empty matrix, if frame outside boundry, it will be black
			if(x>x_low && x<x_high && y>y_low && y<y_high)	% this is for safety check
				% assign original movie's cropped frames to frames of each tracks
				x = round(x);
				y = round(y);
				f = tracks(t).frame(i);	%actual frame number in the movie file
				frameCrop = frames{f}(y-cropBox:y+cropBox, x-cropBox:x+cropBox);
				if crop == 1
					binaryCrop = uint8(full(I_Binary{f}(y-cropBox:y+cropBox, x-cropBox:x+cropBox)));
					isoframes(t).frames{i} = frameCrop .* binaryCrop;
				else
					isoframes(t).frames{i} = frameCrop;
				end
			end
		end
		
	end
	fprintf('\r');
end
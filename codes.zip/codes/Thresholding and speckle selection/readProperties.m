function [Pobj, Pmov] = readProperties(filepath, filename)
	currentFolder = pwd;
	cd(filepath);
	% file format:
	% N_frames:10
	% frame:1 N_obj:5
	% area: 300 301 299 304 302
	% box1: 100 102 102 301 201
	% box2: 
	% box3:
	% box4:
	% cen1:
	% cen2:
	% eccn:
	% qual:
	fprintf('readProperties: read properties file: %s\r',filename);
	f = fopen(filename,'r');
	
	Pmov.dimy = fscanf(f,'dimy:%d\r',1);
	Pmov.dimx = fscanf(f,'dimx:%d\r',1);
	Pmov.duration = fscanf(f,'duration:%e\r',1);
	Pmov.Nframes = fscanf(f,'Nframes:%d\r',1);
	Pmov.fps = fscanf(f,'fps:%e\r');
	Pmov.spf = fscanf(f,'spf:%e\r');
	
	N_frame = fscanf(f,'N_frames:%d\r',1);
	
	for i=1:N_frame
		i=fscanf(f,'frame:%d');
		N_obj=fscanf(f,' N_obj:%d\r');
		fscanf(f,'area: ');
		area = fscanf(f,'%d',N_obj);
		fscanf(f,'\rbox1: ');
		box1 = fscanf(f,'%e',N_obj);
		fscanf(f,'\rbox2: ');
		box2 = fscanf(f,'%e',N_obj);
		fscanf(f,'\rbox3: ');
		box3 = fscanf(f,'%d',N_obj);
		fscanf(f,'\rbox4: ');
		box4 = fscanf(f,'%d',N_obj);
		fscanf(f,'\rcen1: ');
		cen1 = fscanf(f,'%e',N_obj);
		fscanf(f,'\rcen2: ');
		cen2 = fscanf(f,'%e',N_obj);
		fscanf(f,'\reccn: ');
		eccn = fscanf(f,'%e',N_obj);
		fscanf(f,'\rqual: ');
		qual = fscanf(f,'%e',N_obj);
		fscanf(f, '\r');
		for j=1:N_obj
			Pobj{i}(j).Area = area(j);
			Pobj{i}(j).BoundingBox(1) = box1(j);
			Pobj{i}(j).BoundingBox(2) = box2(j);
			Pobj{i}(j).BoundingBox(3) = box3(j);
			Pobj{i}(j).BoundingBox(4) = box4(j);
			Pobj{i}(j).Centroid(1) = cen1(j);
			Pobj{i}(j).Centroid(2) = cen2(j);
			Pobj{i}(j).Eccentricity = eccn(j);
			Pobj{i}(j).Quality = qual(j);
		end
		if N_obj==0				% this handles the error of no objects in current frames
			Pobj{i}=[];
		end
		Pobj{i}=Pobj{i}';		%this rotation is necessary to reproduce the original Pobj matrix
	end
	
	fclose(f);
	cd(currentFolder);
	return;
end
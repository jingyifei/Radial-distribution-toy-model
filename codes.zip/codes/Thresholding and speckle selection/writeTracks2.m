function writeTracks2(tracks, filepath, filename)
	% insufficient input parameter handling
	if nargin <3
		filename = 'track.txt';
	end
	if nargin <2
		filepath = pwd;
	end
	
	currentFolder = pwd;
	cd(filepath);

	% file format:
	% N_tracks:10
	% track:1 length:10
	% frame		x		y		quality		area
	% 1			13.2	100.5	0.1			200
	% 2			13.4	100.2	0.12		203
	% 3			14.2	101.1	0.11		201
	% ...
	fprintf('writeTracks: write track file: %s\r',filename);
	f = fopen(filename,'w');
	N_tracks = size(tracks,2);
	fprintf(f, 'N_tracks:%d\r',N_tracks);
	for t=1:N_tracks
		length = tracks(t).length;
		fprintf(f, 'track:%d length:%d\r',t,length);
		fprintf(f, 'frame x y quality area\r');
		for i=1:length
			fprintf(f, '%d %f %f %f %d\r',tracks(t).frame(i),tracks(t).x(i),tracks(t).y(i),tracks(t).quality(i),tracks(t).area(i));
		end
	end
	
	fclose(f);
	cd(currentFolder);
	return;
end
% writeSparse writes sparse matrix cell array s{i} to file
function writeSparse(sparsematrix, filepath, filename)
	% insufficient input parameter handling
	if nargin <3
		filename = 'sparse.txt';
	end
	if nargin <2
		filepath = pwd;
	end

	currentFolder = pwd;
	cd(filepath);
	
	% file format:
	% N_frames:10
	% frame:1 dimx:512 dimy:512 size: 20
	% x:	2	4	3	7 ...
	% y:	5	5	2	9 ...
	% z:	0.2	0.1	2.3	4.2 ...
	% frame: 2 dim:128 dimy:128 size: 18
	%...
	
	fprintf('writeSparse: write sparsematrix file: %s\r',filename);
	f = fopen(filename,'w');
	N_frames = size(sparsematrix,2);
	fprintf(f,'N_frames:%d\r',N_frames);
	for i=1:N_frames
		dimx = size(sparsematrix{i},1);
		dimy = size(sparsematrix{i},2);
		[x,y,z] = find(sparsematrix{i});
		l = size(x,1);
		fprintf(f,'frame:%d dimx:%d dimy:%d size:%d\r',i,dimx,dimy,l);
		fprintf(f,'x:');
		fprintf(f,' %d',x);
		fprintf(f,'\ry:');
		fprintf(f,' %d',y);
		fprintf(f,'\rz:');
		fprintf(f,' %e',z);
		fprintf(f,'\r');
	end
	
	fclose(f);
	cd(currentFolder);
	return;
end
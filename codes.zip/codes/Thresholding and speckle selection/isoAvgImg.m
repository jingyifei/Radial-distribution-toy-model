% isoAvgImg - isolate average image from a large number of frames
% Author: Isaac Li
% Date: 2014-08-13
% Version history:
% v1.0: based on isoStaticImg format, gets average image while skipping
%		all-0 frames
% INPUT:
%		frames			- cell array of images frames{i} of uint8 class
% OUTPUT:
%		avgImg			- avg image in uint8 class
%		framesSubAvg	- frames subtracted avg;


function [avgImg,framesSubAvg] = isoAvgImg(frames)
	N_frames = length(frames);
	skip = 1;									% skip every N frames for speed
	avgImg32 = uint32(zeros(size(frames{1})));	% use 32 bit integer so no out of range error
	nonZeroCount = 0;							% count the number of non-zero frames
	displayMod = 10;
	for f = 1:skip:N_frames						% start from frame 2
		if mod(f,displayMod)==0					% display progress every displayMod frames
			if f > (displayMod+1)
				for j=1:length(str_stat)
					fprintf('\b');
				end
			end
			str_stat = sprintf('frame:%d/%d',f,N_frames);
			fprintf('%s',str_stat);
		end
		if nnz(frames{f})~=0					% if frame is not all-zero frame
			avgImg32 = avgImg32 + uint32(frames{f});
			nonZeroCount = nonZeroCount + 1;
		end
	end
	avgImg = uint8(avgImg32/nonZeroCount);		% convert back to uint8
	
	if nargout>1								% in case framesSubAvg is wanted
		for f=1:N_frames
			framesSubAvg{f} = frames{f} - avgImg;
		end
	end
end
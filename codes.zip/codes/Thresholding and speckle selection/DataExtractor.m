function [x,y,xdata,ydata] = DataExtractor

global rawDataPath

if ~isempty(rawDataPath)
    startpath = [rawDataPath '\'];
else
    startpath = [pwd '\'];
end

[file, currentpath] = uigetfile([startpath '*.png']);

M = imread([currentpath file],'png');
%M = M(:,:,1:3); %041509 LM

figure;
image(M); hold on;
title('Enter first point on the data axes - zoom in and press space');
pause;
[xaxis1,yaxis1] = ginput(1);
param = getnumbers('First data point',{'x','y'},{'0','0'});
x1 = param(1);
y1 = param(2);
title('Enter second point on the data axes - zoom in and press space');
pause;
[xaxis2,yaxis2] = ginput(1);
param = getnumbers('Second data point',{'x','y'},{'0','0'});
x2 = param(1);
y2 = param(2);
param = getnumbers('Enter axis type',{'x (0 linear, 1 log)','y (0 linear, 1 log)'},{'0','0'});
xaxistype = param(1);
yaxistype = param(2);

choice = 1; i = 1;
while choice == 1
    title(['Enter point #',num2str(i),' on the data trace - zoom in and press space']);
    pause;
    [xdata(i),ydata(i)] = ginput(1);
    plot(xdata(i),ydata(i),'ro');
    choice = menu('Enter another data point?','Yes','No');
    i = i+1;
end;

if yaxistype == 0 %linear
    y = (y2-y1)/(yaxis2-yaxis1)*ydata + (y1*yaxis2-y2*yaxis1)/(yaxis2-yaxis1);
else %log
    y = 10.^((log10(y2)-log10(y1))/(yaxis2-yaxis1)*ydata + (log10(y1)*yaxis2-log10(y2)*yaxis1)/(yaxis2-yaxis1));
end;

if xaxistype == 0 %linear
    x = (x2-x1)/(xaxis2-xaxis1)*xdata + (x1*xaxis2-x2*xaxis1)/(xaxis2-xaxis1);
else %log
    x = 10.^((log10(x2)-log10(x1))/(xaxis2-xaxis1)*xdata + (log10(x1)*xaxis2-log10(x2)*xaxis1)/(xaxis2-xaxis1));
end;

figure;
if yaxistype == 0
    if xaxistype == 0
        plot(x,y,'ro');
    else
        semilogx(x,y,'ro');
    end;
else
    if xaxistype == 0
        semilogy(x,y,'ro');
    else
        loglog(x,y,'ro');
    end;
end;
x=rot90(x);x=rot90(x);x=rot90(x);
y=rot90(y);y=rot90(y);y=rot90(y);
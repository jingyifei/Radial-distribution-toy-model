% cellTrack - take object position in each frame to join into tracks
% Author: Isaac Li
% Date: 2014-05-02
% Version history:
% v1.0: taking frame by frame object properties and movie
%		properties to construct long tracks of individual cells.
%		track by a defined 10px radius for finding connected points
% v2.0: track by more intelligent method... so that long jumps
%		can be counted, 50% performance gain converting from cell array to
%		struct array. cell quality factor taken into.
% todo: live update current track direction, is this really necessary
%
% Inputs:
%	Pobj :	properties of objects in each frame, in particular the centroid 
%			of each objects in each frame to compute connected elements and 
%			produce a track as a cell array, each lists the sequential 
%			centroid locations.
%	Pmov :	movie properties 
%	T    :	threshold values:
%				T.trackRadius	- the pixel distance that defines connected track points
%				T.duration		- limit the minimal length of a track
%				T.borderSize	- within 25 pixel to all border, tracks are not considered because cell may not be completely in the frame
%				T.weight		- weight limit for the predictive track	finding algorithm
%				T.alpha			- alpha fudge factor, see D:\Postdoc\Projects\3. Cell Rolling\2014-04-14 - cell tracking code development - better tracks.pptx
%								  for alpha = 0.1, use weight>0.6,
%								  for alpha = 0.0, distance matters not
%				T.newObjQuality	- quality threshold of individual cells. if
%								  the quality of a cell point does not
%								  reach standard, that point is not taken
%								  into tracks!
%				T.temporal		- temporal connectivity threshold, new
%								  object found in a frame can still join a
%								  track ended <T.temporal frames back! a
%								  value of 0 means immediate termination of
%								  a track if nothing found in the current
%								  frame.
%
% Outputs:
%	tracks: track t with all properties:
%			tracks(t).done		- finished tracks
% 			tracks(t).length	- total datapoint length not same as
%								  frame(L)-frame(1) because some frames can
%								  be skipped for temporal connectivity!
% 			tracks(t).frame(L)	- actual frame number in the movie
% 			tracks(t).x(L)		- x value
% 			tracks(t).y(L)		- y value
% 			tracks(t).quality(L)- quality
% 			tracks(t).area(L)	- area

function tracks = cellTrack2(Pobj,Pmov,T)
	%% THRESHOLD ASSIGNMENT
	% default values of each threshold	
	trackRadius = 10;			% the pixel distance that defines connected track points
	durationThreshold = 5;		% limit the minimal length of a track
	borderSize = 25;			% within 25 pixel to all border, tracks are not considered because cell may not be completely in the frame
	weightThreshold = 0.6;		% weight greater than this would still be counted towards an existing track
	alphaFudgeFactor = 0.1;		% fudge factor for distance
	newObjQuality = 0.5;		% quality of new objects to be considered as part of a track, if a new obj below threshold, then auto discard
	temporalThreshold = 5;			% within N frames, a new object can still connect to a track that found last entry N frames back
	
	if nargin == 3
		if isfield(T,'trackRadius') == 1
			trackRadius = T.trackRadius;	% the pixel distance that defines connected track points
		end
		if isfield(T,'duration') == 1
			durationThreshold = T.duration;		% limit the minimal duration of a track
		end
		if isfield(T,'borderSize') == 1
			borderSize = T.borderSize;		% within 25 pixel to all border, tracks are not considered because cell may not be completely in the frame
		end
		if isfield(T,'weight') == 1
			weightThreshold = T.weight;		% weight greater than this would still be counted towards an existing track
		end
		if isfield(T,'alpha') == 1
			alphaFudgeFactor = T.alpha;		% fudge factor for distance
		end
		if isfield(T,'newObjQuality') == 1
			newObjQuality = T.newObjQuality;% quality of new objects to be considered as part of a track, if a new obj below threshold, then auto discard
		end
		if isfield(T,'temporal') == 1
			temporalThreshold = T.temporal;		% within N frames, a new object can still connect to a track that found last entry N frames back
		end
	end
	
	%% MAIN ANALYSIS
	dimy = Pmov.dimy;			% size of the movie frame
	dimx = Pmov.dimx;			% size of the movie frame
	x_low = borderSize;			% border limites
	x_high = dimy - borderSize;	% border limites
	y_low = borderSize;			% border limites
	y_high = dimy - borderSize;	% border limites
	
	%% MAKE TRACKS FROM EVERY CENTROIDS IN EVERY FRAME:
	tic;
	fprintf('cellTrack2: tracking centroid with thresholds:\r',borderSize);
	fprintf('                  track radius : %4.1f [pixels]\r',trackRadius);
	fprintf('            duration threshold : %4.1f [frames]\r',durationThreshold);
	fprintf('                 border cutoff : %4.1f [pixels]\r',borderSize);
	fprintf('              weight threshold : %4.1f, alphaFudgeFactor: %4.2f\r',weightThreshold,alphaFudgeFactor);
	fprintf('            object Q threshold : %4.1f \r',newObjQuality);
	fprintf('            temporal threshold : %4.1f [frames]\r',temporalThreshold);
	fprintf('            ');
 	N_tracks = 0;
	N_frames = length(Pobj);
	% construct Distance and Weight matrix
	for f=1:N_frames					% 1. go through each new frame
		N_obj = length(Pobj{f});
		% display progress every 5 frames
		if mod(f,5)==1
			if f>1
				for j=1:length(str_stat)
					fprintf('\b');
				end
			end
			str_stat = sprintf('frame:%d/%d  #track:%d  #obj:%d',f,N_frames,N_tracks,N_obj);
			fprintf('%s',str_stat);
		end
		
		TODist = zeros(N_tracks,N_obj);		% track - object distance matrix, reinitialize each time as size changes
		TOWeight = zeros(N_tracks,N_obj);	% track - object weight matrix, reinitialize each time as size changes
		newObj = ones(1,N_obj);				% to flag whether obj has been assigned or not
		newTrack = ones(1,N_tracks);		% to flag whether track has been assigned or not
		
		% preload Pobj.Centroid for each frame for speed:
		for j=1:N_obj
			x(f,j)=Pobj{f}(j).Centroid(1);
			y(f,j)=Pobj{f}(j).Centroid(2);
		end
		
		% Step 0: construct distance and weight matrix, and specially
		% handles tracks that are done already
		for i=1:N_tracks
			if ~tracks(i).done				% if the track is not done yet
				L=tracks(i).length;			% get length of track to get the last position
				trackx = tracks(i).x(L);	% last position x
				tracky = tracks(i).y(L);	% last position y
				for j=1:N_obj
					TODist(i,j)=sqrt((x(f,j)-trackx)^2 + (y(f,j)-tracky)^2);	% distant matrix
					preDir=[1 0];			% previous direction unit vector, live defined, currently not yet
					curDir=[(x(f,j)-trackx) (y(f,j)-tracky)] / TODist(i,j);
					TOWeight(i,j)=(preDir(1)*curDir(1) + preDir(2)*curDir(2))/ TODist(i,j)^alphaFudgeFactor;
				end
			else							% tracks that has already ended
				TODist(i,:) = inf;			% give +infinite value for distance, ensure never takes
				TOWeight(i,:) = -inf;		% give -infinite value for weight, ensure never takes
				newTrack(i) = 0;			% this track is no longer a new track
			end
		end
		
		% Step 1: excluding new points that do not have good shape factor,
		% i.e. if the quality factor of the object is below threshold, then
		% the object column is marked bad
		for j=1:N_obj
			if Pobj{f}(j).Quality < newObjQuality
				TODist(:,j) = inf;			% give +infinite value for distance, ensure never takes
				TOWeight(:,j) = -inf;		% give -infinite value for weight, ensure never takes
				newObj(j) = 0;				% this track is no longer a new object
			end
		end

		
		% Step 2: track within fixed radius (<cell radius), this takes care
		% of the pixel level uncertainty of localization.
		for i=1:min(N_tracks,N_obj)				% only need to go through the min of the 2
			[TODist_min,ij] = min2(TODist);		% min value and the indices
			track_min = ij(1);
			object_min = ij(2);
			if TODist_min<trackRadius && newObj(object_min) && newTrack(track_min) && ~tracks(track_min).done		%redundant check but safe guards
				% assign new track point and properties
				L = tracks(track_min).length + 1;
				tracks(track_min).done		= 0;									% still not done, this is redundant
				tracks(track_min).length	= L;									% length ++
				tracks(track_min).frame(L)	= f;									% current frame
				tracks(track_min).x(L)		= Pobj{f}(object_min).Centroid(1);		% new position x
				tracks(track_min).y(L)		= Pobj{f}(object_min).Centroid(2);		% new position y
				tracks(track_min).quality(L)= 1-Pobj{f}(object_min).Eccentricity;	% quality of the current point in track
				tracks(track_min).area(L)	= Pobj{f}(object_min).Area;				% area of cell
				% remove the row and column of the min index to +inf to avoid futhre detection
				TODist(track_min,:)		= inf;
				TODist(:,object_min)	= inf;
				TOWeight(track_min,:)	= -inf;
				TOWeight(:,object_min)	= -inf;
				newObj(object_min)		= 0;
				newTrack(track_min)		= 0;
			end
		end
		
		% Step 3: weight matrix detection, direction is biased towards
		% historic direction.essentially the same as step 1, but must be
		% separated
		for i=1:min(N_tracks,N_obj)				% only need to go through the min of the 2
			[TOWeight_max,ij] = max2(TOWeight);	% max value of weight matrix and the indices
			track_max = ij(1);
			object_max = ij(2);
			if TOWeight_max>weightThreshold && newObj(object_max) && newTrack(track_max) && ~tracks(track_max).done		%redundant check but safe guards
				% assign new track point and properties
				L = tracks(track_max).length + 1;
				tracks(track_max).done		= 0;									% still not done, this is redundant
				tracks(track_max).length	= L;									% length ++
				tracks(track_max).frame(L)	= f;									% current frame
				tracks(track_max).x(L)		= Pobj{f}(object_max).Centroid(1);		% new position x
				tracks(track_max).y(L)		= Pobj{f}(object_max).Centroid(2);		% new position y
				tracks(track_max).quality(L)= 1-Pobj{f}(object_max).Eccentricity;	% quality of the current point in track
				tracks(track_max).area(L)	= Pobj{f}(object_max).Area;				% area of cell
				% remove the row and column of the min index to +inf to avoid futhre detection
				TODist(track_max,:)		= inf;
				TODist(:,object_max)	= inf;
				TOWeight(track_max,:)	= -inf;
				TOWeight(:,object_max)	= -inf;
				newObj(object_max)		=0;
				newTrack(track_max)		=0;
			end
		end
		
		% Step 4: terminate unassigned tracks if not new or too old
		for i=1:N_tracks
			L = tracks(i).length;
			if newTrack(i) && f-tracks(i).frame(L)>=temporalThreshold
				tracks(i).done = 1;
			end
		end
		
		% Step 5: initialize unassigned objects into tracks
		for i=1:N_obj
			if newObj(i)
				x = Pobj{f}(i).Centroid(1);		% x position of the object centroid
				y = Pobj{f}(i).Centroid(2);		% y position of the object centroid
				if(x>x_low && x<x_high && y>y_low && y<y_high)	% only do something if the centroid position is the border
					N_tracks = N_tracks + 1;								% one more track
					tracks(N_tracks).done		= 0;						% not done
					tracks(N_tracks).length		= 1;						% length = 1
					tracks(N_tracks).frame(1)	= f;						% current frame
					tracks(N_tracks).x(1)		= x;						% x value
					tracks(N_tracks).y(1)		= y;						% y value
					tracks(N_tracks).quality(1) = 1-Pobj{f}(i).Eccentricity;% quality
					tracks(N_tracks).area(1)	= Pobj{f}(i).Area;			% area of cell
				end
			end
		end
		
		% Step 6: remove finished tracks that only have N elements inside (for speeding up large number of cells, N>1, for small number, N=0)
		for i=N_tracks:-1:1			% counting backwards because once element deleted, the index greater will all change, but lower index won't
			if tracks(i).done == 1 && tracks(i).length < durationThreshold
				tracks(i)=[];
				N_tracks = N_tracks - 1;
			end
		end
	end
	

	%% REMOVE SHORT TRACKS (lengthThreshold)
	fprintf('\r            remove track <%d frames\r',durationThreshold);
	N_longTracks = 0;
	for t=1:N_tracks
		tracks(N_tracks).done = 1;		% take care of tracks that didn't properly end before loop finishes
		if tracks(t).length >= durationThreshold
			N_longTracks = N_longTracks + 1;
			longTracks(N_longTracks) = tracks(t);
		end
	end
	fprintf('            (%4.2f s)\r',toc);

	%% IN CASE THERE IS NO TRACKS, RETURN SOMETHING
	if N_longTracks==0
		longTracks=[];
	end
	
	%% REASSIGN TRACKS 
	tracks = [];
	tracks = longTracks;
	
	%% DISPLAY ALL TRACKS
	dimx = Pmov.dimx;
	dimy = Pmov.dimy;
	I_black = zeros(dimy,dimx);				% 1. create a black image
	figure;									% 2. open a figure
	map=colormap(jet);						% 3. create color map
	for t=1:N_longTracks
		linecolor{t} = map(uint8(mean(tracks(t).quality)*62)+1,:);
	end
	imshow(I_black,'Border','tight');		% 4. use no border to show the black image
	hold on;								% 5. do not close
	for t=1:N_longTracks					% 6. draw tracks
		plot(tracks(t).x,tracks(t).y,'-','Color',linecolor{t});
	end
	hold off;
	%axis off;

end

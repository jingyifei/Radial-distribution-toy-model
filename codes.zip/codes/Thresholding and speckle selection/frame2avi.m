% frames2avi - write frames{} to avi
% Author: Isaac Li
% Date: 2014-08-01
% Version history:
% v1.2 adds rescaling function
% v1.1 uses new video writer handles to write images cell arrays into video
% what is new here is that for large movies in memory, do not write to
% movie in memory anymore, but goes straight into harddrive. output only
% available when asked for.

% INPUTS:
%   frames		: original frames  [(0-255) uint8]
%	filepath	: file path to write to
%   filename	: file name in the current directory
%   fps			: frames per sec
%	rescale		: rescaling factor of movie
% OUTPUT:
%   mov			: movie

function mov = frame2avi(frames,filepath,filename,fps,resize)
	%% Exception and error handling
	if nargin < 4
		fps = 30;	% default
	end
	if nargin < 5
		resize = 1;	% default no rescaling, hence factor=1
	end
	
	frameclass = class(frames{1});
	fprintf('\rimage2Video: %s\r',filename);
	fprintf('               frames of class %s\r',frameclass);

	currentFolder = pwd;
	cd(filepath);
	dimy = size(frames{1},1);
	dimx = size(frames{1},2);

	if dimy>128 && dimx>128
% 		writerObj = VideoWriter(filename,'MPEG-4');
		writerObj = VideoWriter(filename,'Motion JPEG AVI');
	else
		writerObj = VideoWriter(filename,'Motion JPEG AVI');
	end
	
	writerObj.FrameRate = fps;
	N_frames = length(frames);
	open(writerObj);
	
	for i=1:N_frames
		% ensures if sparse matrix is used, this is still ok
		if issparse(frames{i})
			thisframe = im2uint8(full(frames{i}));
		else
			thisframe = im2uint8(frames{i});
		end
		if resize ~= 1
			thatframe = imresize(thisframe,resize);
		else
			thatframe = thisframe;
		end
		writeVideo(writerObj,thatframe);
	end
	
	close(writerObj);
	cd(currentFolder);
		 
	return;
%% old code v1.0
% 	if(nargin<3)
% 		fps=20;
% 	end
% 	N=size(I,2);
% 	cmap=colormap(gray(256));		%for bw movies
% 	%[X, cmap] = rgb2ind(I{1},128);	%for color jpg images
% 	
% 	for i=1:N
% 		if issparse(I{i})
% 			I{i} = full(I{i});				% ensures if sparse matrix is used, this is still ok
% 		end
% 		Iuint8{i}=im2uint8(I{i});		
% 		mov(i)=im2frame(Iuint8{i},cmap);
% 	end
% 	
% 	%Convert movie to avi file and save it on current folder
% 	movie2avi(mov, [filename,'.avi'], 'compression', 'None','fps',fps);
% 
% 	close all;
end
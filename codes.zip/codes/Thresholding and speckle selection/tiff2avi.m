% tiff2avi converts *.tiff to *.avi with specified frame rate
% INPUTS:
%	filepath - path to all the tiff files
%	filename - name of the avi file
%	fps - frames per second for the avi

function frames = tiff2avi(tiff_path,avi_name,fps)

	if nargin<3
		fps=20;
	end
	
	currentFolder = pwd;
	cd(tiff_path);


	% load all frames
	fprintf('tiff2avi: loading tiff files...');
	[frames,filelist,N]=imageLoad(tiff_path,'tif');
	fprintf('          %d frames loaded\r',N);
	
	% finding dynamic range
	fprintf('          determining dynamic range\r');
	for i=1:N
		frame_max(i) = max(frames{i}(:));
		frame_min(i) = min(frames{i}(:));
	end
	scale_max = double(max(frame_max));
	scale_min = double(min(frame_min));
	
	% writing movie to file with global rescaling factor
	fprintf('          writing avi at %d fps...\r',fps);
	writerObj = VideoWriter(avi_name,'Grayscale AVI');	% uncompressed grayscale
% 	writerObj = VideoWriter(avi_name,'Motion JPEG AVI');	% default lossy
% 	writerObj = VideoWriter(avi_name,''MPEG-4'');		% compressed mp4
% 	writerObj = VideoWriter(avi_name,'Uncompressed AVI');	% uncompressed color
	writerObj.FrameRate = fps;
	open(writerObj);
	
	for i=1:N
		frame_gray = mat2gray(frames{i},[scale_min,scale_max]);
		frame_uint8 = im2uint8(frame_gray);
		writeVideo(writerObj,frame_uint8);
	end
	
	close(writerObj);
	cd(currentFolder);
end
% this function gives the real angle that arctan can't give depending on dx
% and dy value. range of a is -pi to +pi
function a = angleXY(dx,dy)
% 	a=0;	%initialization otherwise function won't take it... because of changes that a may not be assigned
% 	if dx==0
% 		if dy==0
% 			a=0;				% 0 degree
% 		elseif dy>0
% 			a = pi/2;			% +90 degree
% 		elseif dy<0
% 			a = -pi/2;			% -90 degree			
% 		end	
% 	elseif dx>0
% 		a = atan(dy/dx);		% in the 1,4 quadrant
% 	elseif dx<0
% 		if dy>0
% 			a = atan(dy/dx) + pi;	% in the 2 quadrant
% 		elseif dy<0
% 			a = atan(dy/dx) - pi;	% in the 3 quadrant
% 		end
% 	end
	a=atan2(dy,dx);
end
function speckle3D = speckleSelect(speckle3D,indices)
	for i=speckle3D.N:-1:1
		if sum(indices==i)==0
			speckle3D.N = speckle3D.N -1;
			speckle3D.x(i)=[];
			speckle3D.y(i)=[];
			speckle3D.z(i)=[];
			speckle3D.v(i)=[];
			speckle3D.R3D(i)=[];
			speckle3D.G3D(i)=[];
			speckle3D.B3D(i)=[];
			speckle3D.RGB3D(i)=[];
            speckle3D.Pobj3D(i)=[];
		end
	end
end
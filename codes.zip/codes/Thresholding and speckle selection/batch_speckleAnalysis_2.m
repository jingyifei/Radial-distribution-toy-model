
%% ========================================================================
%loading speckle3D if not in workspace
filepath = 'D:\Research\Data\phase seperation with Oded\STORM data\cell_5_2';

for i=1:85
    filename = ['speckle3D_G_' int2str(i) '.mat'];
    load([filepath '\' filename]);
    
%% ========================================================================
% set parameters
P.imgclass = 'uint16';
P.imageMax = 65535;							% 16 bit data max
P.zdim = 1;								% # z slices updated by cellSelect
P.dust = 25;								% < this many pixel in each slice objects destroyed
P.pixelXY = 0.044;							% 0.04 um/pixel x,y, resolution
P.pixelZ = 0.126;							% 0.126 um/pixel z resolution
P.radialHistBin = 0.1;						% radial RGB intensity distribution bin size in um.
P.radialNBin = 20;                          % how many bins are needed
P.percentile_R = 50;						% percentile threshold for selecting color:
P.percentile_G = 50;						% based on color intensity distribution:
P.percentile_B = 50;						% 10 gives value where 10% population is lower and 90% is higher.
P.display = 0;								% no figure display, faster for obvious purposes

P.percentile_R = 50;						% percentile threshold for selecting color:
P.percentile_G = 50;						% based on color intensity distribution:
P.percentile_B = 50;

if speckle3D.N ==0
    speckle3D = speckle3D;
else
speckle3D = speckleAnalysis(speckle3D, P);
end

% for i=0:100
% 	i
% 	P.percentile_R = i;						% percentile threshold for selecting color:
% 	P.percentile_G = i;						% based on color intensity distribution:
% 	P.percentile_B = i;
% 	speckle3D = speckleAnalysis(speckle3D, P);
% 	v_colorE_frac{i+1} = speckle3D.v_colorE_frac;
% 	v_colorE_um3{i+1} = speckle3D.v_colorE_um3;
% 	v_colorI_frac{i+1} = speckle3D.v_colorI_frac;
% 	v_colorI_um3{i+1} = speckle3D.v_colorI_um3;
% end
% 
% for i=1:101
% 	v_colorE_frac_median(i,:) = median(v_colorE_frac{i}');
% 	v_colorE_frac_mean(i,:) = mean(v_colorE_frac{i}');
% 	v_colorE_frac_std(i,:) = std(v_colorE_frac{i}');
% 	v_colorE_frac_p10(i,:) = prctile(v_colorE_frac{i}',10);
% 	v_colorE_frac_p20(i,:) = prctile(v_colorE_frac{i}',20);
% 	v_colorE_frac_p30(i,:) = prctile(v_colorE_frac{i}',30);
% 	v_colorE_frac_p40(i,:) = prctile(v_colorE_frac{i}',40);
% 	v_colorE_frac_p50(i,:) = prctile(v_colorE_frac{i}',50);
% 	v_colorE_frac_p60(i,:) = prctile(v_colorE_frac{i}',60);
% 	v_colorE_frac_p70(i,:) = prctile(v_colorE_frac{i}',70);
% 	v_colorE_frac_p80(i,:) = prctile(v_colorE_frac{i}',80);
% 	v_colorE_frac_p90(i,:) = prctile(v_colorE_frac{i}',95);
% 	
% 	v_colorE_um3_median(i,:) = median(v_colorE_um3{i}');
% 	v_colorE_um3_mean(i,:) = mean(v_colorE_um3{i}');
% 	v_colorE_um3_std(i,:) = std(v_colorE_um3{i}');
% 	
% 	v_colorI_frac_mean(i,:) = mean(v_colorI_frac{i}');
% 	v_colorI_um3_mean(i,:) = mean(v_colorI_um3{i}');
% end
% 
% cmap = [	1	0	0
% 			0	1	0
% 			0	0	1
% 			1	1	0
% 			1	0	1
% 			0	1	1
% 			0.5 0.5 0.5];
% 	
% figure, plot(v_colorE_frac_median), colormap(cmap), axis([0 100 0 1]), hold on;
% 		plot(v_colorE_frac_p40), colormap(cmap), axis([0 100 0 1]), hold on;
% 		plot(v_colorE_frac_p60), colormap(cmap), axis([0 100 0 1]), hold on;
% 		
% figure, plot(v_colorE_um3_mean), colormap(cmap), axis([0 100 0 2]), hold on;
% 
% frac = 0:100;
% R_um3 = v_colorE_um3_mean(:,1);
% G_um3 = v_colorE_um3_mean(:,2);
% B_um3 = v_colorE_um3_mean(:,3);
% RG_um3 = v_colorE_um3_mean(:,4);
% RB_um3 = v_colorE_um3_mean(:,5);
% GB_um3 = v_colorE_um3_mean(:,6);
% RGB_um3 = v_colorE_um3_mean(:,7);
% R_all_um3 = v_colorI_um3_mean(:,1);
% G_all_um3 = v_colorI_um3_mean(:,2);
% B_all_um3 = v_colorI_um3_mean(:,3);
% 
% allR = [R_um3./R_all_um3 RG_um3./R_all_um3 RB_um3./R_all_um3 RGB_um3./R_all_um3];
% allG = [G_um3./G_all_um3 RG_um3./G_all_um3 GB_um3./G_all_um3 RGB_um3./G_all_um3];
% allB = [B_um3./B_all_um3 RB_um3./B_all_um3 GB_um3./B_all_um3 RGB_um3./B_all_um3];
% 
% allR = [R_um3 RG_um3 RB_um3 RGB_um3 R_all_um3];
% allG = [G_um3 RG_um3 GB_um3 RGB_um3 G_all_um3];
% allB = [B_um3 RB_um3 GB_um3 RGB_um3 B_all_um3];
% 
% 
% 
% figure, plot(allB);

filename1 = ['speckle3D_G_anal_' int2str(i) '.mat'];
save([filepath '\' filename1], 'speckle3D');
end


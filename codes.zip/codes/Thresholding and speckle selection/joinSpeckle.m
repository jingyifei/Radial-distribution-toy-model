% speckle3D = joinSpeckle(speckle3D,channel,mergeIndex)
% Author: Isaac Li
% Date: 2015-08-09
% Description: this function combines speckle in the mergeIndex
% merge is done on specific channels assuming the speckle identification is
% done solely on those channels. This is because the centroid location x y
% z are defined by the entire speckle as identified based on the specified
% channels. Even though there might be data in the unspecified channel,
% those data are not used for speckle location determination in the initial
% stage. It is CRITICAL to make the correct channel assignment to ensure
% correct speckle location.
% Sample code:
% 	filepath = 'D:\Postdoc\Projects\Collaborations\Jingyi\2015-07-01 - more speckle\sample1\cell1_RGB7000_d25_v1000';
% 	load([filepath '\speckle3D.mat']);	% loads speckle3D
% 	channel = 'RGB';					% set channel
% 	mergeIndex{1} = [20 2 3];			% sets of speckles to be merged
% 	mergeIndex{2} = [14 8 9];
% 	mergeIndex{3} = [21 23 59];
% 
% 	speckle3D = joinSpeckle(speckle3D,channel,mergeIndex);

function speckle3D = joinSpeckle(speckle3D,channel,mergeIndex)
	imgclass = speckle3D.imgclass;
	RGBflag = [0 0 0];
	switch channel
		case 'R'
			RGBflag = [1 0 0];
		case 'G'
			RGBflag = [0 1 0];
		case 'B'
			RGBflag = [0 0 1];
		case 'RG'
			RGBflag = [1 1 0];
		case 'RB'
			RGBflag = [1 0 1];
		case 'GB'
			RGBflag = [0 1 1];
		case 'RGB'
			RGBflag = [1 1 1];
	end
	
	
	
	for i = 1:length(mergeIndex)
		% 1.getting the correct bounding box
		bb = [];					% absolute bounding box {j}(x1 y1 z1; x2 y2 z3) in the original coordinates
		N = speckle3D.N;
		for j = 1:length(mergeIndex{i})
			m = mergeIndex{i}(j);
			RGB3D = speckle3D.R3D{m}*RGBflag(1) + speckle3D.G3D{m}*RGBflag(2) + speckle3D.B3D{m}*RGBflag(3);
			RGB3Dbw = RGB3D>0;
			p = regionprops(RGB3Dbw, 'Area','BoundingBox','Centroid','PixelList','PixelIdxList');
			bb(j,1) = speckle3D.x(m) - p.Centroid(1) + 1;	% lower boundary index, starts from 1
			bb(j,2) = speckle3D.y(m) - p.Centroid(2) + 1;
			bb(j,3) = speckle3D.z(m) - p.Centroid(3) + 1;
			bb(j,4) = bb(j,1) + p.BoundingBox(4) - 1;			% upper boundary index, bounding box size is the # of element in the matrix
			bb(j,5) = bb(j,2) + p.BoundingBox(5) - 1;
			bb(j,6) = bb(j,3) + p.BoundingBox(6) - 1;
		end
		% 2. test bb should be integers after the subtraction, if not, something is not right
		testbbinteger = mod(round(bb*1000)/1000,1);	% if anything not integer, testbbinteger>0, round to 0.001 to avoid mod(0.999999999,1)=1
		if sum(testbbinteger(:))>0
			fprintf('ERROR: bounding box non-integer - most likely using wrong channel assignment\r');
		end
		bb = round(bb);								% ok to round, purpose is to round 0.99999 to 1
		bbMerge = [min(bb(:,1:3)) max(bb(:,4:6))];	% this is now the biggerbox

		% 3. create a copy of original image with only the selected portion
		I_R3D = speckle3D.I_R3D;					%copy of I_R3D, to be modified each tiem
		I_G3D = speckle3D.I_G3D;
		I_B3D = speckle3D.I_B3D;
		I_select = zeros(size(speckle3D.I_R3D));
		for j = 1:length(mergeIndex{i})
			m = mergeIndex{i}(j);
			RGB3D = speckle3D.R3D{m}*RGBflag(1) + speckle3D.G3D{m}*RGBflag(2) + speckle3D.B3D{m}*RGBflag(3);
			RGB3Dbw = RGB3D>0;
			I_select(bb(j,2):bb(j,5),bb(j,1):bb(j,4),bb(j,3):bb(j,6)) = RGB3Dbw;	% this copies RGB3Dbw to the right region of I_select
		end
		
		% 4. create region properties of I_select
		p = regionprops(I_select, 'Area','BoundingBox','Centroid','PixelList','PixelIdxList');
		speckle3D.x(N+1) = p.Centroid(1);
		speckle3D.y(N+1) = p.Centroid(2);
		speckle3D.z(N+1) = p.Centroid(3);
		speckle3D.v(N+1) = p.Area;
		speckle3D.Pobj3D(N+1) = p;
		
		% 5. copy I_select specified image out
		I_select = cast(I_select,imgclass);
		I_R3D = I_R3D.*I_select;
		I_G3D = I_G3D.*I_select;
		I_B3D = I_B3D.*I_select;
		
		speckle3D.R3D{N+1} = speckle3D.I_R3D(bbMerge(2):bbMerge(5),bbMerge(1):bbMerge(4),bbMerge(3):bbMerge(6));
		speckle3D.G3D{N+1} = speckle3D.I_G3D(bbMerge(2):bbMerge(5),bbMerge(1):bbMerge(4),bbMerge(3):bbMerge(6));
		speckle3D.B3D{N+1} = speckle3D.I_B3D(bbMerge(2):bbMerge(5),bbMerge(1):bbMerge(4),bbMerge(3):bbMerge(6));
		speckle3D.RGB3D{N+1}(:,:,:,1) = speckle3D.R3D{N+1};					% {index}(x,y,z,color) in a single matrix
		speckle3D.RGB3D{N+1}(:,:,:,2) = speckle3D.G3D{N+1};
		speckle3D.RGB3D{N+1}(:,:,:,3) = speckle3D.B3D{N+1};
		speckle3D.N = N + 1;
	end
	
	speckle3D
	
	% remove merged speckles
	m = [];
	for i = 1:length(mergeIndex)
		m = [m mergeIndex{i}];
	end
		
	length(m)
	speckle3D.N
	m
	speckle3D.N = speckle3D.N - length(m);
	speckle3D.x(m) = [];
	speckle3D.y(m) = [];
	speckle3D.z(m) = [];
	speckle3D.v(m) = [];
	speckle3D.R3D(m) = [];
	speckle3D.G3D(m) = [];
	speckle3D.B3D(m) = [];
	speckle3D.RGB3D(m) = [];
	speckle3D.Pobj3D(m) = [];
	% user friendliness
	fprintf('\rold indices -> new index\r');
	fprintf('----------------------------\r');
	for i = 1:length(mergeIndex)
		list = sprintf('%d ',mergeIndex{i});
		fprintf('%s\r', ['( ' list ') -> ' num2str(speckle3D.N-length(mergeIndex)+i)]);
	end
	
end

function tracks = readTracks2(filepath, filename)
	currentFolder = pwd;
	cd(filepath);
	
	% file format:
	% N_tracks:10
	% track:1 length:10
	% frame		x		y		quality		area
	% 1			13.2	100.5	0.1			200
	% 2			13.4	100.2	0.12		203
	% 3			14.2	101.1	0.11		201
	% ...
	fprintf('readTracks: read track file: %s\r',filename);
	f = fopen(filename,'r');
	N_tracks = fscanf(f, 'N_tracks:%d\r');
	% if no track was found / recorded, return empty
	if N_tracks==0
		tracks=[];
		return;
	end
	% if there are tracks, go through them.
	for t=1:N_tracks
		t = fscanf(f, 'track:%d');
		length = fscanf(f, ' length:%d\r');
		tracks(t).length = length;
		tracks(t).done = 1;
		fscanf(f, 'frame x y quality area\r');
		for i=1:length
			tracks(t).frame(i) = fscanf(f, '%d',1);
			tracks(t).x(i) = fscanf(f, '%f',1);
			tracks(t).y(i) = fscanf(f, '%f',1);
			tracks(t).quality(i) = fscanf(f, '%f',1);
			tracks(t).area(i) = fscanf(f, '%d\r',1);
		end
	end
	fclose(f);
	cd(currentFolder);
	return;
end
% imageLoad - loading all image of format in filepath
% Example: [frames,filelist,N]=loadImage('c:\images','bmp');
% Author: Isaac Li
% Date:2013-06-27
% Version history
% 1.0 - this function loads all images in "path" with "format" into a cell 
% array of image, and also tells how many images (N) it has loaded.

function [frames,filelist,N]=imageLoad(filepath,format)
	currentpath = pwd;
    cd(filepath);
	
    formatstring = strcat ('*.',format);
    filelist = ls(formatstring);
    N = size(filelist,1);
    for i=1:N
       frames{i}=imread(filelist(i,:),format);
	end
	
	cd(currentpath);
end
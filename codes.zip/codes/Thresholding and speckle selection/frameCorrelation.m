function fc = frameCorrelation(frames)
	N_frames = length(frames);
	fc = zeros(N_frames);	% 2D matrix of N_frames^2
	for i = 1:N_frames
		frameDouble{i} = double(frames{i}) - double(mean(frames{i}(:)));
		frameDouble2 = frameDouble{i}.*frameDouble{i};
		frameRMS(i) = sqrt(sum(frameDouble2(:)));
	end
	for i = 1:N_frames
		for j = i:N_frames
			dotIJ = frameDouble{i}.*frameDouble{j};
			fc(i,j) = sum(dotIJ(:))/(frameRMS(i)*frameRMS(j));
			fc(j,i) = fc(i,j);
		end
	end
 	nonZeroMin = min2(fc(fc>0));
 	fc(fc==0) = nonZeroMin;
	
	imagesc(fc);
	axis equal;
	axis tight;
end
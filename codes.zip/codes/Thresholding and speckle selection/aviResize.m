function aviResize(filepath,filename,scale)
	currentFolder = pwd;
	cd(filepath);
	
	% read video and info
	fprintf('aviResize: reading %s\r',filename);
	readObj = VideoReader(filename);		% VideoReader handles the total number of frame correctly - actual total number, not computed, like in mmreader
	dimy = readObj.Height;
	dimx = readObj.Width;
	duration = readObj.Duration;
	Nframes = readObj.NumberOfFrames;	% this is based on the meta data, not real frame number - meta says 100fps for 10s, then 1000 frames, but actually might be only 10fps, so 100 frames
	fps = Nframes / duration;

	index = [1 Nframes];	
	vid = read(readObj,index);

	% write video and info
	[pathstr,name,ext]=fileparts(filename);
	filename_big = [name '_big.avi'];
	writerObj = VideoWriter(filename_big,'Motion JPEG AVI');
	writerObj.FrameRate = fps;
	open(writerObj);
	
	% resize each frame
	fprintf('           resizing from %dx%d to %dx%d\r',dimx,dimy,dimx*scale,dimy*scale);
	for i=1:Nframes
		frame = imresize(vid(:,:,:,i),scale);
		writeVideo(writerObj,frame);
	end
	
	close(writerObj);
	cd(currentFolder);
end
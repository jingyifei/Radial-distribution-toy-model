% THis function allows the user to click on data on a plot, and returns the
% x and y values
% Created by Patrick Mears
% June 2, 2011

%Inputs:

%Outputs: OUT = x and y data from the selected data

function out = getClickedData

x = get(gco,'xdata');   % Acquire the x-data from the selected line
y = get(gco,'ydata');   % Acquire the x-data from the selected line
out = [x' y'];          % Concatenate the x and y data into a single variable
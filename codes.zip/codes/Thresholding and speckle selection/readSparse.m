% writeSparse writes sparse matrix cell array s{i} to file
function sparsematrix = readSparse(filepath, filename)
	currentFolder = pwd;
	cd(filepath);
	
	% file format:
	% N_matrix:10
	% frame:1 dimx:512 dimy:512 size: 20
	% x:	2	4	3	7 ...
	% y:	5	5	2	9 ...
	% z:	0.2	0.1	2.3	4.2 ...
	% frame: 2 dim:128 dimy:128 size: 18
	%...
	
	fprintf('readSparse: read sparsematrix file: %s\r',filename);
	f = fopen(filename,'r');
	N_frame = fscanf(f,'N_frames:%d\r',1);
	for i=1:N_frame
		i = fscanf(f, 'frame:%d',1);
		dimx = fscanf(f, ' dimx:%d',1);
		dimy = fscanf(f, ' dimy:%d',1);
		l = fscanf(f, ' size:%d\r',1);
		fscanf(f, 'x: ');
		x = fscanf(f, '%d', l);
		fscanf(f, '\ry: ');
		y = fscanf(f, '%d', l);
		fscanf(f, '\rz: ');
		z = fscanf(f, '%e', l);
		fscanf(f, '\r');
		
		sparsematrix{i}=sparse(x,y,z,dimx,dimy);	%create sparse matrix with the xyz values with dimension dimx dimy
	end
	
	fclose(f);
	cd(currentFolder);
	return;
end
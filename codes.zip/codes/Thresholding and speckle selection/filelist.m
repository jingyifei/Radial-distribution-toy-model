% filelist: creats a cell array of filenames
% filepath:		string of filepath
% format:		string of file format, e.g. 'hel*.avi'
% e.g. list = filelist('c:\test\','*.avi');

function list = filelist(filepath,format)
	if nargin < 1
		filepath = pwd;
	end
	if nargin < 2
		format = '*.*';
	end
	
	currentFolder = pwd;
	cd(filepath);
	
	f = dir(format);
	N_files = size(f,1);
	for i=1:N_files
		list{i} = f(i).name;
	end
	
	cd(currentFolder);
	return;
end
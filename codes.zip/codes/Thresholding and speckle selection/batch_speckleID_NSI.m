
clear
filepath = ['G:\SNEHA\knockdown\172\12-7-2022\Analysis\SR\3'];

% set parameters
P.imgclass = 'uint16';
P.imageMax = 65535;							% 16 bit data max
P.zdim = 1;								% # z slices updated by cellSelect
% P.numCell = 2;							% number of cells in this image
% P.intensityThreshold = 2000;				% intensity threshold - speckle selection
P.dust = 1;								% < this many pixel in each slice objects destroyed
P.volumeThreshold = 300;					% volume cut off for selecting speckle
P.method = 'B';							% RGB or RB
P.pixelXY = 0.026;							% 0.026 um/pixel x,y, resolution
P.pixelZ = 0.126;							% 0.126 um/pixel z resolution
P.radialHistBin = 0.1;						% radial RGB intensity distribution bin size in um.
P.radialNBin = 20;                          % how many bins are needed

%update parameters
P = cellSelect(filepath, P);				% update P.zdim, P.numCell, P.cellPolygonX, P.cellPolygonY;


% dynamic parameters: run blue channel
P.dust = 1;								% < this many pixel in each slice objects destroyed
P.method = 'RGB';							% RGB or RB
intensityThreshold = [6000 6500 7000 10000 10500 11000 11500 12000 12500 13000 13500 14000 14500 16000 16500 17000 18000 20000 21000 22000 25000 28000 30000];% intensity threshold - speckle selection
%intensityThreshold = [18500 19000 19500 19700];
P.volumeThreshold = 300;					% volume cut off for selecting speckle

for c = 1:P.numCell
	P.cellIndex = c;
    for j = 1:length(intensityThreshold)
        P.intensityThreshold = intensityThreshold(j);		% Colocalization and Pearson inside each speckle
		speckle2D = speckleID_2D_3(filepath, P);
    end
end
% 
% % dynamic parameters: run blue channel
% P.dust = 1;								% < this many pixel in each slice objects destroyed
% P.method = 'B';							% RGB or RB
% intensityThreshold = [3000];			% intensity threshold - speckle selection
% P.volumeThreshold = 300;					% volume cut off for selecting speckle
% 
% for c = 1:P.numCell
% 	P.cellIndex = c;
%     for j = 1:length(intensityThreshold)
%         P.intensityThreshold = intensityThreshold(j);		% Colocalization and Pearson inside each speckle
% 		speckle2D = speckleID_2D_3(filepath, P);
%     end
% end
% 
% % dynamic parameters: run red and green channel
% P.dust = 1;								% < this many pixel in each slice objects destroyed
% P.method = 'RG';							% RGB or RB
% intensityThreshold = [11000];			% intensity threshold - speckle selection
% P.volumeThreshold = 200;					% volume cut off for selecting speckle
% 
% for c = 1:P.numCell
% 	P.cellIndex = c;
%     for i = 1:length(intensityThreshold)
%         P.intensityThreshold = intensityThreshold(i);		% Colocalization and Pearson inside each speckle
% 		speckle2D = speckleID_2D_3(filepath, P);
%     end
% end
% 
close all;


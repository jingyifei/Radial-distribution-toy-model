% isoStaticImg - isolate true static image from a large number of frames
% Author: Isaac Li
% Date: 2014-05-13
% Version history:
% v1.1: added error handling to handle blank frames - those all-0 frames
%		makes staticImg = all-0 frame in v1.0. This version ensures no
%		all-0 frames are used for the analysis. really awesome code. also
%		added option to take subtracted frames out.
% v1.0: use the 2014-05-13 notebook algorithm. Restrictions are that
%       currently only support frames{i} are uint8 class. this function is
%       so awesome, so so awesome, it's 2014-07-31, i see it, i like it.
%       elegant solution.
% INPUT:
%		frames			- cell array of images frames{i} of uint8 class
% OUTPUT:
%		staticImg		- static component of all images with no bias as uint8
%		framesSubStatic	- frames subtract static image


function [staticImg, framesSubStatic] = isoStaticImg(frames)
	N_frames = length(frames);
	skip = 1;						% skip every N frames for speed
	firstIndex = 1;					% first non-zero frame index
	nonZeroCount = 1;				% count the number of non-zero frames
	displayMod = 10;				% display progress modulation
	% first, find te first non-zero frame
	while nnz(frames{firstIndex})==0
		firstIndex = firstIndex + 1;
	end
	img1 = int16(frames{firstIndex});		% initialization of img1 using greater precision with negative
	for f = firstIndex+1:skip:N_frames			% start from frame 2
		if mod(f,displayMod)==0				% display progress every 5 frames
			if f > (firstIndex+displayMod)
				for j=1:length(str_stat)
					fprintf('\b');
				end
			end
			str_stat = sprintf('frame:%d/%d',f,N_frames);
			fprintf('%s',str_stat);
		end
		
		img2 = int16(frames{f});	% load current frame
		if nnz(img2)~=0				% make sure new image is not an empty image!
			imgDiff = img1 - img2;		% diff between 2

			dyn1 = imgDiff;				% dynamic component of image 1
			dyn1(dyn1<0)=0;				% what's negative belongs to dyn2
			dyn2 = -imgDiff;			% dynamic component of image 2
			dyn2(dyn2<0)=0;				% what's negative belongs to dyn1

			sta1 = img1 - dyn1;			% static component of image 1
			sta2 = img2 - dyn2;			% static component of image 2

			sta = (sta1 + sta2) / 2;	% average static component, checked, difference is 0
			img1 = sta;					% reset img1 as the current static component
			
			nonZeroCount = nonZeroCount + 1;
		end
	end
	
	staticImg = uint8(sta);			% revert back to uint8
	
	if nargout>1								% in case framesSubAvg is wanted
		for f=1:N_frames
			framesSubStatic{f} = frames{f} - staticImg;
		end
	end
end
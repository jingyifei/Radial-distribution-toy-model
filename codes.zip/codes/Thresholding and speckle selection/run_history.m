close all;
clear all;
path=['D:\Postdoc\Projects\3. Cell Rolling\2013-10-11 - PEG chamber cell adhesion\dynamic set3 - avidin 2000uLhr\tiff-LZW'];
I=imageLoad(path,'tif');
N=size(I,2);
index=1:1:N;

Iflat=I;
Iflat=imageFlatten(I,index);
% 
for i=1:N
	Iflat{i}=imageAdjust(Iflat{i},0,40000);
end

close all;

index2=1:10;
[Ic,c,a]=cellcountIx(Iflat,index,0.20);
index1=1:9;
imageTile(Iflat,index1,'short',c);
imageTile(Ic,index1,'short',c);
figure; plot(c)
mean(c)
std(c)


close all
imshow(Ic{2})


%add all binary together
overlap=cast(Ic{1},'uint16')*0;
for i=1:N
	overlap=overlap+cast(Ic{i},'uint16');
end

I1=imageAdjust(overlap,1,2);	% this shows everything that stayed on screen for more than 2 frames, but anything more than 5 frame is the same thing
I2=imageAdjust(overlap,50,51);		% this shows long staying points
I3=I1*0;
Icombine=cat(3,I1-I2,I2,I3);		%combine into RGB for color coding, delete I2 from I1 makes green show up
imshow(Icombine);


image2Video(Iflat,'flat1');
image2Video(Ic,'binary');


imshow(Iflat{120});
figure
imshow(Ic{120});
figure
imshow(Iflat{300});
figure
imshow(Ic{300});

for i=1:N
	I{i}=I{i}/20;
end

for i=1:N
	total(i)=sum(I{i}(:));
	avg(i)=total(i)/512/512;
end
plot(avg);
mean(avg)
std(avg)


%%

		img_stack_subset(:,:,1,i)=img_stack(:,:,1,i); % full size image
		%img_stack_subset(:,:,1,i)=img_stack(:,257:512,1,i); % cy5 channel
		%img_stack_subset(:,:,1,i)=img_stack(:,1:256,1,i); % cy3 channel

		test(:,:)=cast(I{2}(:,266:502),'double')./cast(I{2}(:,14:250),'double');
		imshow(imageAdjust(test))
		imshow(I{2})
%%
path1='D:\Postdoc\Projects\3. Cell Rolling\2013-07-23 - 2 rolling experiments\exp 2 channel B real exp 1fps 100ms exposure\movies';
path2='D:\Postdoc\Projects\3. Cell Rolling\2013-07-04 - timelapse capture ecoli adhesion and concentration dep\50ugmL image';
path3='D:\Postdoc\Projects\3. Cell Rolling\2013-07-04 - timelapse capture ecoli adhesion and concentration dep\5ugmL image';
path4='D:\Postdoc\Projects\3. Cell Rolling\2013-07-24 - avidin neutravidin control\channel D - BSA-BSA-biotin + streptavidin + neutravidin';

I1=imageLoad(path1,'tif');
I2=imageLoad(path2,'tif');
I3=imageLoad(path3,'tif');
I4=imageLoad(path4,'tif');

N1=size(I1,2);
N2=size(I2,2);
N3=size(I3,2);
N4=size(I4,2);
for i=1:N1
	I1{i}=imageAdjust(I1{i});
end
for i=1:N2
	I2{i}=imageAdjust(I2{i});
end
for i=1:N3
	I3{i}=imageAdjust(I3{i});
end
for i=1:N4
	I4{i}=imageAdjust(I4{i});
end


index1=1:1:N1;
index2=1:1:N2;
index3=1:1:N3;
index4=1:1:N4;

I1=imageFlatten(I1,index1);
I2=imageFlatten(I2,index2);
I3=imageFlatten(I3,index3);

[Ic1,c1,a1]=cellcountIx(I1,index1,0.25);
[Ic2,c2,a2]=cellcountIx(I2,index2,0.25);
[Ic3,c3,a3]=cellcountIx(I3,index3,0.25);
[Ic4,c4,a4]=cellcountIx(I4,index4,0.25);

image2Video(I1);

Iflat=imageFlatten(I,index);
%% differentiate between frames
dsum=zeros(512,512);
for i=1:N-1
	d{i}=imabsdiff(Iflat{i+1},Iflat{i});
	dsum=dsum+cast(d{i},'double');
end



dsum=zeros(512,512);
for i=1:N-1
	dsum=dsum+cast(Ibw{i},'double');
end

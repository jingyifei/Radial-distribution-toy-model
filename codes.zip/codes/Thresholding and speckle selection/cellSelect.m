function P = cellSelect(filepath, P)

	f1 = dir([filepath '\R.tif']);
% 	I = imread([filepath '\' f(round(length(f)/2)).name]);
    I(:,:,1) = imread([filepath '\' f1.name]);
    f2 = dir([filepath '\G.tif']);
    I(:,:,2) = imread([filepath '\' f2.name]);
    f3 = dir([filepath '\B.tif']);
    I(:,:,3) = imread([filepath '\' f3.name]);
    
    % use this if shown B channel
    up = floor(0.9*max(max(I(:,:,3)))); 
    down = floor(min(min(I(:,:,3))));
	figure, imshow(I(:,:,3),[down up],'Border','tight'), hold on;
    
%      % use this if shown R or G channel, for showing G channel, use
%      % I(:,:,2)
%     up = floor(0.1*max(max(I(:,:,1)))); 
%     down = floor(min(min(I(:,:,1))));
% 	figure, imshow(I(:,:,1),[down up],'Border','tight'), hold on;
	
	numberOfCells = input('Number of cells: ');
	
	for c = 1:numberOfCells
		disp(['Selecting cell#: ' num2str(c)]);
		[x0,y0] = ginputWhite;
		P.cellPolygonX{c} = round(x0);	% mouse event non integer
		P.cellPolygonY{c} = round(y0);	% mouse event non integer
		plot([x0; x0(1)],[y0; y0(1)],'--ow');
		text(mean(x0),mean(y0),num2str(c),'color','w');
		drawnow;
	end
	
	%P.zdim = length(f);
	P.numCell = numberOfCells;
	
end
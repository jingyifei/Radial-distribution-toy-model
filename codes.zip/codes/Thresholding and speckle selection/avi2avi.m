% avi2avi
% the point of this pointless function is to solve the display problem of
% interlacing during some stupid Nikon microscope codec's encoding. this
% function can be easily modified to convert avi to mp4 as well
% author: Isaac Li
% date: 2014-07-31
% INPUTS: 
%	filepath - filepath
%	filename - filename, if omitted, all .avi is processed!!


function avi2avi(filepath, filename)
	if nargin < 1
		filepath = pwd;
	end
	currentFolder = pwd;
	cd(filepath);
	filepath_new = [filepath '\avi2avi'];
	if ~exist(filepath_new,'dir')
		mkdir(filepath_new);
	end
	
	if nargin == 2
		[frames,Pmov] = avi2frame2(filepath,filename);
		frame2avi(frames,filepath_new,filename,Pmov.fps);
	else
		fn = filelist(filepath,'*.avi');
		N_files = size(fn,2);
		for i=1:N_files
			[pathstr,name,ext]=fileparts(fn{i});
			[frames,Pmov] = avi2frame2(filepath,[name ext]);
			frame2avi(frames,filepath_new,name,Pmov.fps);
		end
	end

end
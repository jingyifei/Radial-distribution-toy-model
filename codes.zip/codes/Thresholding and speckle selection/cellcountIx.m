% example: [labelRGB,count]=cellcountIx(I,index,level);
function [I_RGB,count,area,area_all]=cellcountIx(I,index,level)
	%% Image processing
	wb = waitbar(0);
	set(wb,'Name','processing images...');
	N=size(index,2);
	for i=1:N
		%I2=imadjust(I{index(i)});						%Step 1: Auto contrast
		I2=I{index(i)};
		background = imopen(I2,strel('disk',5));		%Step 2: Use Morphological Opening to Estimate the Background, good images, 5 is good, bad fat images, 10
		I3 = I2 - background;							%Step 3: Subtract the Background Image from the Original Image
		%I3 = imadjust(I3);								% *IMPORTANT* when cell count is too low, don't use I3 adjust.
		
		if(nargin<3)
			level = graythresh(I3)*0.8;					%Step 5: AUTO-Threshold the Image, 0.8 works for lots of cells, 2 for few cells
		end
		
		Ibw = im2bw(I3,level);
		Ibw = bwareaopen(Ibw, 1);						%Step 5.2: kill the little specs <# pixels, don't go too high, might erode real objects
		
		cc{index(i)} = bwconncomp(Ibw, 8);				%Step 6: Identify Objects in the Image
		count(i)=cc{index(i)}.NumObjects;
		celldata = regionprops(cc{index(i)}, 'basic');
		area{i}=[celldata.Area];
		
		
		label = labelmatrix(cc{index(i)});				%Step 7: View All Objects
		I_RGB{index(i)} = label2rgb(label, @spring, 'c', 'shuffle');	
		waitbar(i/N,wb,sprintf('Progress: %d / %d',i,N));
		
		I_RGB{index(i)}=Ibw;
	end
	
	area_all=cell2mat(area);
	
	close(wb);
 
end
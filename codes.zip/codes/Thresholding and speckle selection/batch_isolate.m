% batch_isolateCells
% full tracking needs to run before running this program. The files needed
% here are:
% .avi - original
% .track - detected tracks
% .P - movie and object properties
% _bin.sparse - binary cell 
% 

fp='D:\Postdoc\Projects\3. Cell Rolling\2014-07-30 - [code] deep wide analysis track inside cell correlations\good movies to use\2014-03-14 movies';
fn = filelist(fp,'*.avi');
for index = 2:length(fn);
	[pathstr,name,ext]=fileparts(fn{index});
	['processing ' name]

	%% file and directory names
	fn_avi = [name '.avi'];
	fn_bin = [name '_bin.sparse'];
	fn_track = [name '.track'];
	fn_P = [name '.P'];
	fn_isolatedMap = [name '_map'];

	fp_avi = fp;
	fp_bin = [fp '\bin'];
	fp_track = [fp '\track'];
	fp_P = [fp '\P'];
	fp_isolated = [fp '\' name];

	%% reading files
	frames = avi2frame2(fp_avi,fn_avi);
	I_Binary = readSparse(fp_bin,fn_bin);
	[Pobj, Pmov] = readProperties(fp_P, fn_P);
	tracks = readTracks2(fp_track, fn_track);

	% only do the good tracks - criteria matches that of tracks, hence
	% goodTracks = tracks, but with more analysis done
	T.quality	= 0;	% min mean quality of a track
	T.distx		= 0;	% min dx length to be considered
	T.area		= 5000;	% max pixel^2 area to be considered
	T.duration	= 0;	% min # of frames a track must have
	P.fps		= Pmov.fps;
	P.pixelSize = 0.4;
	goodTracks	= analyzeTracks2(tracks,T,P);

	% isolation thresholds
	T.cropBox = 20;			% this is the 'radius size' of the box enclosing each cell from x-cropBox to x+cropBox, y-cropBox to y+cropBox, an area of 1600, should be fine for most cells.
	T.borderSize = 25;		% within 25 pixel to all border, tracks are not considered because cell may not be completely in the frame
	T.crop = 0;				% default don't crop the raw movie by the binary file
	% isolate frames
	isoframes = cellIsolate(frames,I_Binary,Pobj,Pmov,goodTracks,T);

	%% write isolated movie
	if ~exist(fp_isolated,'dir')
		mkdir(fp_isolated);
	end

	for i=1:length(goodTracks)
		fn_isolated = [name '_' num2str(i) '.avi'];
		frame2avi(isoframes(i).frames,fp_isolated,fn_isolated,Pmov.fps,10);	% no resize here because isoFrame already resized
	end

	%% draw tracks
	N_tracks = length(goodTracks);
	dimy = Pmov.dimy;
	dimx = Pmov.dimx;
	I_black = zeros(dimy,dimx);				% 1. create a black image
	figure;								% 2. open a figure
	map=colormap(jet);						% 5. create color map
	for t=1:N_tracks
		linecolor{t} = map(uint8(t/N_tracks*63+1),:);
	end
	imshow(I_black,'Border','tight');		% 3. use no border to show the black image
	hold on;								% 4. do not close
	for t=1:length(goodTracks)
		plot(goodTracks(t).x,goodTracks(t).y,'Color',linecolor{t});		% 6. plot all tracks onto the black figure
		text(goodTracks(t).x(1),goodTracks(t).y(1),['\color{white}' num2str(t)]);
	end
	drawnow;
	fig2png(fp_isolated, fn_isolatedMap);
end

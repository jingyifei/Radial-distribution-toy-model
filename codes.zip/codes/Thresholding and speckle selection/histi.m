% example: [b,h,f]=histi(data,[0,5,100]);
% data:		data to make histogram
% bin:		specifies low, binsize, and high of histogram
%			[low,binsize,high]
% b:		bin array
% h:		histogram corresponding to b
% f:		fit curve

function [b,h,f]=histi(data,bin)
	%% Make histogram
	b=bin(1):bin(2):bin(3);	% bin
	h = histc(data,b);		% histogram
	
	%% Gaussian fit
	load enso;				% load package
	b=rot90(b,3);			% rotate 3x90degree, such that bin goes from small to big
	h=rot90(h,3);			% rotate 3x90degree
	%f=fit(b,h,'gauss1')		% 1 gaussian fit, use gauss2-8 to have 2-8 gaussians fit
    
	%% Plot
	figure;
	bar(b,h,'hist'); hold on;	% print histogram
%	plot(f,'-r');				% print fit
	xlabel('cells/FOV');
	ylabel('# frames');
	%xlabel('cell size (pixel)');
	%ylabel('counts');
	axis([bin(1),bin(3),0,1]);
	axis autoy;
	
end
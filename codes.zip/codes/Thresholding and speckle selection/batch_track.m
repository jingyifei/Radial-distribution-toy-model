% batch_track: analyzes all .avi files in the given directory and
% writes the results and movies to files.
% INPUTS:
%	filepath: full file path without '\' in the end. e.g. 'C:\test\good'

function batch_track(filepath)
	fn = filelist(filepath,'*.avi');
	N_files = size(fn,2);
	for i=1:N_files
		close all;
		% file names
		[pathstr,name,ext]=fileparts(fn{i});
		fn_track	= [name '.track'];	
		fn_bin		= [name '_bin.sparse'];
		fn_box		= [name '_box.sparse'];
		fn_cen		= [name '_cen.sparse'];
		fn_P		= [name '.P'];
		fn_video	= [name '_vid.mp4'];
		
		fp_track	= [filepath '\track'];	
		fp_bin		= [filepath '\bin'];
		fp_box		= [filepath '\box'];
		fp_cen		= [filepath '\cen'];
		fp_P		= [filepath '\P'];
		fp_video	= [filepath '\composite'];
		
		% start end end frame number
		f1 = 1;
		f2 = 10000;
		
		% 1. extract frames and movie properties from avi
		[frames,Pmov] = avi2frame2(filepath,fn{i},f1,f2);
		
		% 2. analyze frames to get properties of each frame and objects in each frames
 		%T.binary	= 3;	% leukocyte darkfield 10x + 2.5x / 4.0x
 		%T.dust		= 20;	% leukocyte darkfield 10x + 2.5x / 4.0x
		%T.binary	= 0.5;	% bacteria darkfield 10x
		%T.dust		= 1;	% bacteria darkfield 10x
		T.binary	= 3;	% leukocyte tracking inside
 		T.dust		= 50;	% leukocyte tracking inside
		[Pobj,I_Binary,I_Box,I_Centroid,frames_noBg] = cellID(frames,T);		
		
		% 3. analyze extracted frame properties to generate tracks
		T.trackRadius	= 10;
		T.duration		= 10;
		T.borderSize	= 10;
		T.weight		= 0.1;
		T.alpha			= 0.1;
		T.newObjQuality	= 0.25;
		T.temporal		= 10;
		tracks		= cellTrack2(Pobj,Pmov,T);
		
		% 4. analyze tracks
		T.quality	= 0.25;		% all-are-welcome parameters - any quality
		T.distx		= 0;		% all-are-welcome parameters - any distance in x
		T.area		= 5000;		% all-are-welcome parameters - area <5000
		P.fps		= Pmov.fps;
		P.pixelSize = 0.4;
		goodTracks	= analyzeTracks2(tracks,T,P);

		% 5. write results to file
		if ~exist(fp_track,'dir')
			mkdir(fp_track);
		end
		if ~exist(fp_bin,'dir')
			mkdir(fp_bin);
		end
		if ~exist(fp_box,'dir')
			mkdir(fp_box);
		end
		if ~exist(fp_cen,'dir')
			mkdir(fp_cen);
		end
		if ~exist(fp_P,'dir')
			mkdir(fp_P);
		end
		
		writeTracks2(goodTracks,	fp_track, fn_track);	% write tracks to file	
		writeSparse(I_Binary,		fp_bin, fn_bin);		% write binary image sparse
		writeSparse(I_Box,			fp_box, fn_box);		% write bounding box image sparse
		writeSparse(I_Centroid,		fp_cen, fn_cen);		% write centroid image sparse
		writeProperties(Pobj, Pmov, fp_P, fn_P);			% write Properties of each frame
		
		% 6. write composite video to file
		if ~exist(fp_video,'dir')
			mkdir(fp_video);
		end
		T.quality	= 0;
		T.distx		= 0;
		T.area		= 5000;
		writeCompositeVideo2(frames, Pmov, I_Binary, I_Box, I_Centroid, tracks, fp_video, fn_video, T);	
		% writeCompositeVideo2(frames_noBg, Pmov, I_Binary, I_Box, I_Centroid, tracks, fp_video, fn_video, T);	
	end
end
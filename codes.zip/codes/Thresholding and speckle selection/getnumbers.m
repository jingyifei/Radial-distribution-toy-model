%2012-12-19 - Isaac Li
%adapted from getnumbers.m, modified

% returns an array of numbers from a dialog prompting on an array of prompts and default values
% e.g. results=GetNumbers('get these', {'#a:','#b:'}, {'5','6'});
% results will be [5,6] if default.

function [results]=getnumbers(title,prompts,defaults)

% get values and store in cell array c
c=inputdlg(prompts,title,1,defaults,'on');

% go through the number of prompts
for i=1:max(size(prompts))
	resultstring = cell2struct(c(i),{'abc'});	% create a single struct with field name 'abc'
	results(i) = str2num(resultstring.abc);		% converts the struct corresponding to abc to number
end;
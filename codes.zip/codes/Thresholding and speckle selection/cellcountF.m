% example: [image,labelRGB,count]=cellcountF('d:\images','bmp');
function [image,labelRGB,count]=cellcountF(path,type)
	%% PATH handling
	%path = 'D:\Postdoc\Projects\3. Cell Rolling\2013-06-26 - BSA-biotin Neutravidin mannose dep test\2013-06-26 - mannose dependence sticking to neutravidin\bare glass channel\0.00 - top no mannose (-0.55 top)\';
	[image,N] = imageLoad(path,type);
	cd('D:\Postdoc\Projects\Codes\Matlab\');
	
	%% Image processing
	wb = waitbar(0);
	set(wb,'Name','processing images...');
	for i=1:N
		I2=imadjust(image{i});							%Step 1: Auto contrast
		background = imopen(I2,strel('disk',5));		%Step 2: Use Morphological Opening to Estimate the Background, good images, 5 is good, bad fat images, 10
		I3 = I2 - background;							%Step 3: Subtract the Background Image from the Original Image
		I3 = imadjust(I3);
		
		level = graythresh(I3)*0.8;						%Step 5: Threshold the Image, 0.8 works for lots of cells, 2 for few cells
		Ibw = im2bw(I3,level);
		Ibw = bwareaopen(Ibw, 50);						%Step 5.2: kill the little specs, don't go too high, might erode real objects
		
		cc{i} = bwconncomp(Ibw, 8);						%Step 6: Identify Objects in the Image
		count(i)=cc{i}.NumObjects;
		
		label = labelmatrix(cc{i});						%Step 7: View All Objects
		labelRGB{i} = label2rgb(label, @spring, 'c', 'shuffle');	
		waitbar(i/N,wb,sprintf('Progress: %d / %d',i,N));
	end
	close(wb);
 
end
function file_sorting

threshold = '8000';
dir1 = 'D:\MALAT1\MALAT1-KD'; %need be changed
dir2 = 'D:\MALAT1\MALAT1-KD\GB8000'; %need be changed
dir3 = ['\GB_T' threshold '_D25_V1000']; %need be changed

fname='speckle3D.mat';
num = 0;
for i=10:20 %need be changed
    for j=1:10
        cd(dir1)
        if exist([num2str(i)],'file')
            cd([num2str(i)]);
            if exist(['c' num2str(j) dir3],'file')
                cd(['c' num2str(j) dir3]);
                num = num+1;
                fname_2=['speckle3D_GB_' num2str(num) '.mat'];
                copyfile(fname,[dir2 '\' fname_2]);
            end
        end
    end
end

end
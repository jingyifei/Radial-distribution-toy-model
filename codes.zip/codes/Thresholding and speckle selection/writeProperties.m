function writeProperties(Pobj, Pmov, filepath, filename)
	% insufficient input parameter handling
	if nargin <3
		filename = 'sparse.txt';
	end
	if nargin <2
		filepath = pwd;
	end
	
	currentFolder = pwd;
	cd(filepath);
	
	% file format:
	% dimy:512 dimx:512 duration:20.3 Nframes:400 fps:20.03 spf:0.05
	% N_frames:400
	% frame:1 N_obj:5
	% area: 300 301 299 304 302
	% box1: 100 102 102 301 201
	% box2: 
	% box3:
	% box4:
	% cen1:
	% cen2:
	% eccn:
	% qual:
	fprintf('writeProperties: write properties file: %s\r',filename);
	f = fopen(filename,'w');
	N_frames = size(Pobj,2);
	fprintf(f,'dimy:%d\r',Pmov.dimy);
	fprintf(f,'dimx:%d\r',Pmov.dimx);
	fprintf(f,'duration:%e\r',Pmov.duration);
	fprintf(f,'Nframes:%d\r',Pmov.Nframes);
	fprintf(f,'fps:%e\r',Pmov.fps);
	fprintf(f,'spf:%e\r',Pmov.spf);
	fprintf(f,'N_frames:%d\r',N_frames);
	for i=1:N_frames
		N_obj=size(Pobj{i},1);
		fprintf(f,'frame:%d N_obj:%d\r',i,N_obj);
		area = [];
		box1 = [];
		box2 = [];
		box3 = [];
		box4 = [];
		cen1 = [];
		cen2 = [];
		eccn = [];
		qual = [];
		for j=1:N_obj
			area(j) = Pobj{i}(j).Area;
			box1(j) = Pobj{i}(j).BoundingBox(1);
			box2(j) = Pobj{i}(j).BoundingBox(2);
			box3(j) = Pobj{i}(j).BoundingBox(3);
			box4(j) = Pobj{i}(j).BoundingBox(4);
			cen1(j) = Pobj{i}(j).Centroid(1);
			cen2(j) = Pobj{i}(j).Centroid(2);
			eccn(j) = Pobj{i}(j).Eccentricity;
			qual(j) = Pobj{i}(j).Quality;
		end
		fprintf(f,'area:');
		fprintf(f,' %d',area);
		fprintf(f,'\rbox1:');
		fprintf(f,' %e',box1);
		fprintf(f,'\rbox2:');
		fprintf(f,' %e',box2);
		fprintf(f,'\rbox3:');
		fprintf(f,' %d',box3);
		fprintf(f,'\rbox4:');
		fprintf(f,' %d',box4);
		fprintf(f,'\rcen1:');
		fprintf(f,' %e',cen1);
		fprintf(f,'\rcen2:');
		fprintf(f,' %e',cen2);
		fprintf(f,'\reccn:');
		fprintf(f,' %e',eccn);
		fprintf(f,'\r');
		fprintf(f,' %e',qual);
		fprintf(f,'\r');
	end
	fclose(f);
	cd(currentFolder);
	return;
end
% frame2tiff - write frames{} to tiffstack
% Author: Isaac Li
% Date: 2014-08-017
% Version history:
% v1.0 uses as name suggests
% INPUTS:
%   frames		: original frames  [(0-255) uint8]
%	filepath	: file path to write to
%   filename	: file name in the current directory

function frame2tiff(frames,filepath,filename)
	currentFolder = pwd;
	cd(filepath);
	
	switch class(frames)
		case 'cell'							% in case of cell array
			imwrite(frames{1}, filename);
			for m = 2:length(frames)
				imwrite(frames{m}, filename, 'WriteMode', 'append','Compression','lzw');
			end
		otherwise							% in case of a single frame not in cell array
			imwrite(frames, filename);
	end
	fclose('all');
	cd(currentFolder);
end
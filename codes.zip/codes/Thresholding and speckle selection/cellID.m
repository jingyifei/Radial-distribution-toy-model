% cellID Identifies cells and calculate their properties including
% location, shape, etc...
% Author: Isaac Li
% Date: 2014-08-13
% Version history:
% v1.2: adding support for tracking inside the cell with MSER method. at
%		this point, the functions such as isoStaticImg has also been
%		optimized and improved to detect all-zero frames. Maybe MSER method
%		can eventually be used to track cells too? this is still to be
%		proven. cosmetic code 2014-08-13
% v1.1:	dramatically improved performance (30-40%) with selective parallel
%		processing. boundary definition better with erosion. proved that
%		threshold method is still way faster than other more advanced, less
%		parameter dependent methods. but so far, this is the fastest and
%		most reliable for darkfield images. A new highly improved static
%		background detection algorithm was added using the function
%		isoStaticImg. 2014-05-02
% v1.0: threshold method and parallel processing to find cell centroid
%
% Inputs:
%	frames		: contrast adjusted grayscale [(0-255) uint8] stacks frames{i}
%	T			: threshold values:
%					T.method	- method for detecting cells or features:
%								  'threshold' (default) - mainly for whole cell tracking.
%								  'MSER' - mainly for tracking within cells
%					T.binary	- (threshold) binary image threshold for standard deviation
%					T.dust		- (threshold) max size of dust to be cleaned up
%					T.MSERDelta - (MSER) MSERDelta parameter for feature
%								   detection
%
% Outputs:
%	Pobj		: Properties of object j in each frame i Pobj{i}(j)'Area','BoundingBox','Centroid','Eccentricity'
%					Pobj.Area			- Area
%					Pobj.BoundingBox	- (1)-(4):(x1,y1) and (x2,y2)
%					Pobj.Centroid		- Centroid(1) and (2) are x,y
%					Pobj.Eccentricity	- Circle is 0, line is 1
%					Pobj.Quality		- 1-Eccentricity
%	I_Binary	: binary image [(0-1) logic] of the identified cells
%	I_Box		: image [(0-1) double, sparse] of the boundary box
%	I_Centroid	: image [(0-1) double, sparse] of centroid in sparse matrix format
%	frames_noBg	: background subtracted frames
%
% NOTE: matlab is stupid, an image displayed has upperleft corder as 0 the
% matrix specifies y value first, then x value. So the point (x,y) on the
% image A correspond to A(y,x) entry. the size of y is the height, and size
% of x is width, so stupid!

function [Pobj,I_Binary,I_Box,I_Centroid,frames_noBg] = cellID(frames,T)
	%% THRESHOLD AND PARAMETERS ASSIGNMENT ================================
	% default values
	detectionMethod = 'threshold';	% default method is classic threshold
	binaryThreshold = 3;	% 'threshold' method - binary image threshold for standard deviation
	dustThreshold = 20;		% 'threshold' method - max size of dust to be cleaned up
	MSERDelta = 2;			% 'MSER' method - ThresholDelta parameter for detectMSERFeatures function
	
	if nargin == 2
		if isfield(T,'method') == 1
			detectionMethod = T.method;		% max size of dust to be cleaned up
		end
		if isfield(T,'binary') == 1
			binaryThreshold = T.binary;		% binary image threshold for standard deviation
		end
		if isfield(T,'dust') == 1
			dustThreshold = T.dust;			% max size of dust to be cleaned up
		end
		if isfield(T,'MSERDelta') == 1
			MSERDelta = T.MSERDelta;		% max size of dust to be cleaned up
		end
	end
	
	% parameters
	N_frames = length(frames);
	frame_height = size(frames{1},1);
	frame_width = size(frames{1},2);
	
	
	%% START MULTI-THREADING ==============================================
	poolSize = matlabpool('size');
	if poolSize == 0
		warning('cellID: Matlabpool not open, opening for multithreading...');
		matlabpool('open');					% if the number of cores used isn't the right one, run cluster profile manager to set.
	end
	poolSize = matlabpool('size');			% double check
	if poolSize == 0
		warning('cellID: Failed to open Matlabpool for multithreading, loop run in sequential mode');
	else
		fprintf('cellID: multithreading using %d cores\r',poolSize);
	end

	%% STATIC BACKGROUND REMOVAL ==========================================
	tic;
	fprintf('        static bg detection... ');
	[staticbg,frames] = isoStaticImg(frames);	% new highly improved static background detection algorithm
	fprintf(' (%4.2f s)\r',toc);
	figure;
	imshow(staticbg,'Border','tight');
	drawnow;

	tic;
% 	fprintf('        static bg subtraction...');
% 	for i=1:N_frames
% 		frames{i} = frames{i} - staticbg;
% 		frames{i}(frames{i}<0)=0;				% negative values are now 0
% 	end
	
	frames_noBg = frames;						% for returning only!
	fprintf('(%4.2f s)\r',toc);

	%% CELL / FEATURE DETECTION ===========================================
	fprintf('cellID: identifying cells...\r');
	switch detectionMethod
		% THRESHOLD METHOD ================================================
		% this method is the classic method of cell detection. works well
		% with dark field microscopy where cells are bright and field is
		% dark. very efficient.
		case 'threshold'
			% 1. get new frames mode and stdev for thresholding -----------
			tic;
			fprintf('        mode and stdev = ');
			count = 0;
			if N_frames>100
				step = floor(N_frames/100);				% want roughly 100 frames to assess this parameter
			else				
				step = 1;								% in case total # frames <100 frames
			end

			for i=1:step:N_frames						% only doing half of the frames to save time
				count = count + 1;
				I_gray = mat2gray(frames{i},[0 255]);
				fm(count) = mode(I_gray(:));			% mode of image
				fs(count) = std(I_gray(:));				% stdev of image
			end
			m = mean(fm);
			s = mean(fs);
			fprintf('[%4.2f %4.2f] ',m,s);
			fprintf('(%4.2f s)\r',toc);

			% 2. main threshold image processing --------------------------
			tic;
			fprintf('        parallel process each frame...');
			% disk = strel('disk',15);					% disc structure element for obsolete function
			seD = strel('diamond',1);					% diamond structure element
			parfor i=1:N_frames							% parfor not compatible with MSER routine
				I = mat2gray(frames{i},[0 255]);		% convert uint8 frame to 0-1 binary:

				% METHOD 1: black and white binary image of the thresholded image, and kill small speckles
				Ibw = im2bw(I,m+s*binaryThreshold);		% threshold image
				Ibw = imfill(Ibw,'holes');				% fills holes in the image	
				Ibw = imclearborder(Ibw,4);				% clear images touching border
				Ibw = imerode(Ibw,seD);					% smooth edge
				Ibw = imerode(Ibw,seD);					% smooth edge
				Ibw = bwareaopen(Ibw,dustThreshold);	% eat dusts <100pixel after erode
				% Ibw = bwconvhull(Ibw,'objects');		% creates convex hall of each objects

				% % METHOD 2: edge detection - sucks
				% [~, threshold] = edge(I, 'canny');					% canny edge detection
				% Ibw = edge(I,'canny',threshold*binaryThreshold);	% canny edge detection	
				% Ibw = bwareaopen(Ibw,10);% eat dusts <100pixel total area
				% Ibw_dialate = imdilate(Ibw, seD);					% dialate kill gap
				% Ibw_fill = 1 - imfill(Ibw_dialate,'holes');			% fills holes and inverse
				% Ibw_inside = 1 - (Ibw + Ibw_fill);					% define interior
				% Ibw_dialate = imerode(Ibw_inside,seD);				% kill 2ndary boundary
				% Ibw_dialate = bwareaopen(Ibw_dialate,dustThreshold);% eat dusts <100pixel total area
				% Ibw_dialate = imdilate(Ibw_dialate, seD);			% reverse cell shape level 1 - safe expansion
				% Ibw_final = imclearborder(Ibw_dialate, 4);			% clear images touching border
				% Ibw = Ibw_final;

				% Find connected components and identify individual cell
				cc = bwconncomp(Ibw, 8);				% find connected elements
				N_obj = cc.NumObjects;					% total number of objects in each frame
				Pobj{i} = regionprops(cc, 'Area','BoundingBox','Centroid','Eccentricity');	% properties of each region
				for j=1:N_obj
					Pobj{i}(j).Quality = 1-Pobj{i}(j).Eccentricity;
				end
				% drawing display boxes
				[dimy,dimx] = size(I);
				I_Box{i} = sparse(dimy,dimx);			% boundingbox - sparse matrix method
				I_Centroid{i} = sparse(dimy,dimx);		% centroid - sparse matrix method
				I_Binary{i} = sparse(Ibw);				% binary image - sparse matrix method
				for j=1:N_obj
					% drawing bounding box
					bb_x1 = max(1,ceil(Pobj{i}(j).BoundingBox(1)));
					bb_x2 = min(frame_height, (bb_x1 + Pobj{i}(j).BoundingBox(3)));
					bb_y1 = max(1,ceil(Pobj{i}(j).BoundingBox(2)));
					bb_y2 = min(frame_width, (bb_y1 + Pobj{i}(j).BoundingBox(4)));
					I_Box{i}(bb_y1:bb_y2,bb_x1) = Pobj{i}(j).Quality;
					I_Box{i}(bb_y1:bb_y2,bb_x2) = Pobj{i}(j).Quality;
					I_Box{i}(bb_y1,bb_x1:bb_x2) = Pobj{i}(j).Quality;
					I_Box{i}(bb_y2,bb_x1:bb_x2) = Pobj{i}(j).Quality;
					% drawing centroid
					c_x = ceil(Pobj{i}(j).Centroid(1));
					c_y = ceil(Pobj{i}(j).Centroid(2));
					I_Centroid{i}(c_y,c_x)=1;
				end
			end
			fprintf('(%4.2f s)\r',toc);
		
		% MSER METHOD =====================================================
		% this method is great for detecting features during inside cell
		% tracking. the best way to use this is to subtract frames from
		% average frames before passing into there:
		% frames{i} = frames{i} - isoAvgImg(frames)
		case 'MSER'
			for i=1:N_frames
				Iregion{i} = detectMSERFeatures(frames{i},'ThresholdDelta',MSERDelta);
				N_regions = length(Iregion{i});
				for j=1:N_regions
					Pobj{i}(j).Area = double(length(Iregion{i}.PixelList{j}));
					Pobj{i}(j).BoundingBox = double([min(Iregion{i}.PixelList{j}(:,2)) min(Iregion{i}.PixelList{j}(:,1)) peak2peak(Iregion{i}.PixelList{j}(:,2)) peak2peak(Iregion{i}.PixelList{j}(:,1))]);
					Pobj{i}(j).Centroid = double(Iregion{i}.Location(j,:));	
					Pobj{i}(j).Eccentricity = double(Iregion{i}.Axes(j,2)/Iregion{i}.Axes(j,1));
					Pobj{i}(j).Quality = 1-Pobj{i}(j).Eccentricity;
				end

				% drawing Binary matrix with zebra patterns
				Ibw_final = false(size(frames{i}));
				for j=1:N_regions
					Ibw{j} = false(size(frames{i}));
					pixelList = Iregion{i}.PixelList{j};
					pixelIndex = sub2ind(size(frames{i}),pixelList(:,2),pixelList(:,1));
					Ibw{j}(pixelIndex) = true;
					Ibw_final = xor(Ibw_final,Ibw{j});
				end
				I_Binary{i} = sparse(Ibw_final);				% binary image - sparse matrix method
				
				% drawing display matrices
				[dimy,dimx] = size(frames{i});
				I_Box{i} = sparse(dimy,dimx);			% boundingbox - sparse matrix method
				I_Centroid{i} = sparse(dimy,dimx);		% centroid - sparse matrix method
				for j=1:N_regions
					% drawing bounding box
					bb_x1 = max(1,ceil(Pobj{i}(j).BoundingBox(1)));
					bb_x2 = min(frame_height, (bb_x1 + Pobj{i}(j).BoundingBox(3)));
					bb_y1 = max(1,ceil(Pobj{i}(j).BoundingBox(2)));
					bb_y2 = min(frame_width, (bb_y1 + Pobj{i}(j).BoundingBox(4)));
					I_Box{i}(bb_y1:bb_y2,bb_x1) = Pobj{i}(j).Quality;
					I_Box{i}(bb_y1:bb_y2,bb_x2) = Pobj{i}(j).Quality;
					I_Box{i}(bb_y1,bb_x1:bb_x2) = Pobj{i}(j).Quality;
					I_Box{i}(bb_y2,bb_x1:bb_x2) = Pobj{i}(j).Quality;
					% drawing centroid
					c_x = ceil(Pobj{i}(j).Centroid(1));
					c_y = ceil(Pobj{i}(j).Centroid(2));
					I_Centroid{i}(c_y,c_x)=1;
				end
			end
		otherwise
			fprintf('ERROR: THIS SHOULD NOT HAPPEN?!?!?!');
	end
end
function batch_track_inside(filepath)
	fn = filelist(filepath,'*.avi');
	N_files = length(fn);
	for i=1:N_files
		close all;
		% file names ----------------------------------------------------------
		[pathstr,name,ext]=fileparts(fn{i});
		fn_track	= [name '.track'];	
		fn_bin		= [name '_bin.sparse'];
		fn_box		= [name '_box.sparse'];
		fn_cen		= [name '_cen.sparse'];
		fn_P		= [name '.P'];
		fn_video	= [name '_vid.mp4'];
		fn_pic1		= [name '_map.png'];
		fn_pic2		= [name '_xy.png'];

		fp_track	= [filepath '\track'];	
		fp_bin		= [filepath '\bin'];
		fp_box		= [filepath '\box'];
		fp_cen		= [filepath '\cen'];
		fp_P		= [filepath '\P'];
		fp_video	= [filepath '\composite'];

		% start end end frame number
		f1 = 1;
		f2 = 10000;

		% 1. extract frames and movie properties ------------------------------
		[frames,Pmov] = avi2frame2(filepath,fn{i},f1,f2);

		% 2. remove average bg ------------------------------------------------
		clear I
		[I_avg,framesSubAvg] = isoAvgImg(frames);

		% 3. cell ID with MSER features ---------------------------------------
		T.method = 'MSER';
		T.MSERDelta = 2;
		[Pobj,I_Binary,I_Box,I_Centroid,frames_noBg] = cellID(framesSubAvg,T);

		% 4. track ------------------------------------------------------------
		T.trackRadius	= 50;
		T.duration		= 25;
		T.borderSize	= 0;
		T.weight		= inf;	% don't want directional bias
		T.alpha			= inf;
		T.newObjQuality	= 0;	% shape doesn't matter
		T.temporal		= 10;
		tracks		= cellTrack2(Pobj,Pmov,T);

		% 5. analyze tracks ---------------------------------------------------
		T.quality	= 0;		% all-are-welcome parameters - any quality
		T.distx		= 0;		% all-are-welcome parameters - any distance in x
		T.area		= 5000;		% when blob too big, it will fail to track anyways..?
		P.fps		= Pmov.fps;
		P.pixelSize = 0.4;
		goodTracks	= analyzeTracks2(tracks,T,P);

		% 6. write results to file --------------------------------------------
		if ~exist(fp_track,'dir')
			mkdir(fp_track);
		end
		if ~exist(fp_P,'dir')
			mkdir(fp_P);
		end
		writeTracks2(goodTracks, fp_track, fn_track);	% write tracks to file	
		writeProperties(Pobj, Pmov, fp_P, fn_P);		% write Properties of each frame

		% 7. write composite video to file ------------------------------------
		if ~exist(fp_video,'dir')
			mkdir(fp_video);
		end
		T.showBox	= 0;
		T.showBin	= 0;
		T.showTrack	= 0;
		writeCompositeVideo2(frames, Pmov, I_Binary, I_Box, I_Centroid, tracks, fp_video, fn_video, T);	

		% 8. write images -----------------------------------------------------
		plotXthreshold = 0;
		if ~exist(fp_video,'dir')
			mkdir(fp_video);
		end
		close all;
		N_tracks = length(goodTracks);

		%x vs.y
			dimy = Pmov.dimy;
			dimx = Pmov.dimx;
			I_black = zeros(dimy,dimx);				% 1. create a black image
			figure;								% 2. open a figure
			map=colormap(jet);						% 5. create color map
			for t=1:N_tracks
				linecolor{t} = map(uint8(t/N_tracks*63+1),:);
			end
			imshow(I_black,'Border','tight');		% 3. use no border to show the black image
			hold on;								% 4. do not close
			for t=1:length(goodTracks)
				if(max(goodTracks(t).x)-min(goodTracks(t).x)>plotXthreshold)
					plot(goodTracks(t).x,goodTracks(t).y,'Color',linecolor{t});		% 6. plot all tracks onto the black figure
					text(goodTracks(t).x(1),goodTracks(t).y(1),['\color{white}' num2str(t)],'HorizontalAlignment','center','VerticalAlignment','middle'););
				end
			end
			drawnow;
			fig2png(fp_video, fn_pic1);

		% x(t) and y(t)
			figure('Position', [1,100,600,600]);
			subplot(2,1,1);
			hold on;			
			for t=1:length(goodTracks)
				if(max(goodTracks(t).x)-min(goodTracks(t).x)>plotXthreshold)
					plot(goodTracks(t).frame,goodTracks(t).x,'Color',linecolor{t});	
					text(goodTracks(t).frame(1),goodTracks(t).x(1),['\color{black}' num2str(t)],'HorizontalAlignment','center','VerticalAlignment','middle'););
				end
			end
			axis tight
			hold off

			subplot(2,1,2);
			hold on;			
			for t=1:length(goodTracks)
				if(max(goodTracks(t).x)-min(goodTracks(t).x)>plotXthreshold)
					plot(goodTracks(t).frame,goodTracks(t).y,'Color',linecolor{t});
					text(goodTracks(t).frame(1),goodTracks(t).y(1),['\color{black}' num2str(t)],'HorizontalAlignment','center','VerticalAlignment','middle'););
				end
			end
			axis tight
			hold off
			fig2png(fp_video, fn_pic2);
	end
end
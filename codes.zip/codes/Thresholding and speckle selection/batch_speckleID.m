
clear
filepath = 'D:\Postdoc\Projects\Collaborations\Jingyi\2015-07-01 - more speckle\sample1';

% set parameters
P.imgclass = 'uint16';
P.imageMax = 65535;							% 16 bit data max
P.zdim = 31;								% # z slices updated by cellSelect
% P.numCell = 2;							% number of cells in this image
% P.intensityThreshold = 2000;				% intensity threshold - speckle selection
P.dust = 25;								% < this many pixel in each slice objects destroyed
P.volumeThreshold = 1000;					% volume cut off for selecting speckle
P.method = 'RGB';							% RGB or RB
P.pixelXY = 0.04;							% 0.04 um/pixel x,y, resolution
P.pixelZ = 0.126;							% 0.126 um/pixel z resolution
P.radialHistBin = 0.1;						% radial RGB intensity distribution bin size in um.
P.radialNBin = 20;                          % how many bins are needed

% update parameters
P = cellSelect(filepath, P);				% update P.zdim, P.numCell, P.cellPolygonX, P.cellPolygonY;

% dynamic parameters
intensityThreshold = [7000];			% intensity threshold - speckle selection

for c = 1:P.numCell
	P.cellIndex = c;
    for i = 1:length(intensityThreshold)
        P.intensityThreshold = intensityThreshold(i);		% Colocalization and Pearson inside each speckle
		speckle3D = speckleID(filepath, P);
    end
end

close all;
close all
composite(:,:,:)=0;

composite(:,:,1)=channel3_005c3;
composite(:,:,2)=imadjust(channel3_005c2)-channel3_005c3;;
composite(:,:,3)=0.3*(65535-channel3_005c1);
imshow(composite)


%%

(mean(channel8_034c3(:)) + mean(channel8_035c3(:)) + mean(channel8_036c3(:)) + mean(channel8_037c3(:)) + mean(channel8_038c3(:)) + mean(channel8_039c3(:)))/6 


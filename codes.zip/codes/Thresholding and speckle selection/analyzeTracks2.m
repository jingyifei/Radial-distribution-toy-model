% analyzeTracks: inherit all data from tracks, but adds more data
% if tracks is already analyzed, it does it again and overwrites certain
% properties anyways. This overwriting properties is necessary as changes
% might be added to the function later such that analyzed tracks can be
% analyzed again
% Author: Isaac Li
% Date: 2014-05-02
% Version history:
% v1.0:	basic analysis of track, with distance, dx, dy, average angle,
%		directioned-dxx dyy
% v2.0:	tracks no longer cell array as they are slow, using struct arrays
%		instead now. improved direction detection, and more computations
%
% Inputs:
%	tracks	: track t with all properties:
%				tracks(t).done		- finished tracks
% 				tracks(t).length	- total length
% 				tracks(t).frame(L)	- actual frame in movie
% 				tracks(t).x(L)		- x value
% 				tracks(t).y(L)		- y value
% 				tracks(t).quality(L)- quality
% 				tracks(t).area(L)	- area
%	T		: threshold values:
%				T.quality	- min mean quality of a track
%				T.distx		- min dxx length to be considered
%				T.area		- max pixel^2 area to be considered
%				T.duration	- min # of frames a track must have
%	P		: properties values:
%				P.fps		- frames per second of movie [fps]
%				P.pixelSize - size of each pixel in [um] 
%							  Nikon 10x : 1.6 [um/pixel] calculated
%							  Nikon 20x : 0.8 [um/pixel] calculated
%							  Nikon 40x : 0.4 [um/pixel] calculated
%
% Outputs:
%	goodTracks:	original properties:
% 				goodTracks(t).done			- finished tracks
% 				goodTracks(t).length		- total datapoint length not same as
%										  frame(L)-frame(1) because some frames can
%										  be skipped for temporal connectivity!
% 				goodTracks(t).frame(L)		- actual frame number in the movie
% 				goodTracks(t).x(L)			- x value [pixel]
% 				goodTracks(t).y(L)			- y value [pixel]
% 				goodTracks(t).quality(L)	- quality of each frame!
% 				goodTracks(t).area(L)		- area [pixel^2]
%
%				additional properties (raw units):
%				goodTracks(t).d(L-1)		- raw distance [pixel]
%				goodTracks(t).dx(L-1)		- raw dx [pixel]
% 				goodTracks(t).dy(L-1)		- raw dy [pixel]
%
%				additional properties (real units):
%				goodTracks(t).v(L-1)		- real speed [um/s]
%				goodTracks(t).vx(L-1)		- real vx [um/s]
% 				goodTracks(t).vy(L-1)		- real vy [um/s]
%				goodTracks(t).xx(L)			- along mean track angle [um]
%				goodTracks(t).yy(L)			- perpendicular to mean track angle [um]
% 				goodTracks(t).vxx(L-1)		- along mean track angle [um/s]
% 				goodTracks(t).vyy(L-1)		- perpendicular to mean track angle [um/s]
% 				goodTracks(t).angle(L-1)	- angle to horizontal [rad]
%				goodTracks(t).time(L)		- real time [s]
%				
%				threshold settings for getting the above values:
% 				goodTracks(t).T.quality		- threshold quality
% 				goodTracks(t).T.distx		- threshold distance [pixel]
% 				goodTracks(t).T.area		- threshold area [pixel^2]
% 				goodTracks(t).T.duration	- threshold duration [frames]
% 				goodTracks(t).P.fps			- properties fps [frames/s]
% 				goodTracks(t).P.pixelSize	- properties pixel size [um/pixel]

function goodTracks = analyzeTracks2(tracks,T,P)
	tic;
	%% THRESHOLD ASSIGNMENT
	% default values of each threshold
	qualityThreshold = 0.3;		% min mean quality of a track
	distanceThreshold = 20;		% min dxx length to be considered
	areaThreshold = 1500;		% max pixel^2 area to be considered
	durationThreshold = 10;		% min # of frames a track must have
	areaSpikeThreshold = 5;		% when cell area in trajectory spikes beyond areaSpikeThreshold*stdev, remove that datapoint!
	% if there are input threshold info, use the input threshold
	if nargin == 3
		% Threshold handling
		if isfield(T,'quality') == 1
			qualityThreshold = T.quality;	% min mean quality of a track
		end
		if isfield(T,'distx') == 1
			distanceThreshold = T.distx;	% min dxx length to be considered
		end
		if isfield(T,'area') == 1
			areaThreshold = T.area;			% max pixel^2 area to be considered
		end
		if isfield(T,'duration') == 1
			durationThreshold = T.duration;	% min # of frames a track must have
		end
		if isfield(T,'areaSpike') == 1
			areaSpikeThreshold = T.areaSpike;	% when cell area in trajectory spikes beyond areaSpikeThreshold*stdev, remove that datapoint!
		end
		
		% Properties handling
		if isfield(P,'fps') == 1
			fps = P.fps;					% fps
		else
			fprintf('analyzeTracks2: ERROR - P.fps field empty\r');
			return;
		end
		if isfield(P,'pixelSize') == 1
			pixelSize = P.pixelSize;		% pixelSize
		else
			fprintf('analyzeTracks2: ERROR - P.pixelSize field empty\r');
			return;
		end
	end

	%% MAIN ANALYSIS
	
	N_tracks = length(tracks);
	
	% Step 0: clean up track by area filtering, remove sudden big jumps in
	% cell area, those are when 2 cells overlap!
	fprintf('analyzeTracks2: removing cell area jumps...\r');
	for t = 1:N_tracks
		L = tracks(t).length;
		area_median = median(tracks(t).area);
		area_stdev = std(tracks(t).area);
		for i = L:-1:1		% count backwards as L changes length
			if abs(tracks(t).area(i)-area_median) > area_stdev*areaSpikeThreshold
				tracks(t).frame(i)	= [];
				tracks(t).x(i)		= [];
				tracks(t).y(i)		= [];
				tracks(t).quality(i)= [];
				tracks(t).area(i)	= [];
				tracks(t).length = tracks(t).length - 1;
			end
		end
	end
	
	% Step 1: basicanalyze all tracks
	fprintf('                analyzing tracks, 1st pass...\r');
	for t = 1:N_tracks
		% write additional track conditions
		tracks(t).T.quality		= qualityThreshold;
		tracks(t).T.distx		= distanceThreshold;
		tracks(t).T.area		= areaThreshold;
		tracks(t).T.duration	= durationThreshold;
		tracks(t).T.areaSpike	= areaSpikeThreshold;
		% write additional track properties
		tracks(t).P.fps			= fps;
		tracks(t).P.pixelSize	= pixelSize;

		% write computed properties
		L = tracks(t).length;
		dx=[];
		dy=[];
		d=[];
		for i=1:L-1
			dx(i) = (tracks(t).x(i+1) - tracks(t).x(i));
			dy(i) = (tracks(t).y(i+1) - tracks(t).y(i));
		end
		d = sqrt(dx.^2 + dy.^2);
		tracks(t).dx	= dx;					% dx in pixel
		tracks(t).dy	= dy;					% dy in pixel
		tracks(t).d		= d;					% d in pixel
		tracks(t).vx	= dx * pixelSize * fps / (tracks(t).frame(i+1) - tracks(t).frame(i));	% vx in um/s, dividing frame number difference because of temporal connectivity - not all adjacent entries are 1 frame apart.
		tracks(t).vy	= dy * pixelSize * fps / (tracks(t).frame(i+1) - tracks(t).frame(i));	% vy in um/sdividing frame number difference because of temporal connectivity - not all adjacent entries are 1 frame apart.
		tracks(t).v		= d * pixelSize * fps / (tracks(t).frame(i+1) - tracks(t).frame(i));	% v in um/sdividing frame number difference because of temporal connectivity - not all adjacent entries are 1 frame apart.
		tracks(t).angle	= atan2(dy,dx);			% atan2 takes care of the angle from -pi to +pi
		tracks(t).time	= tracks(t).frame / fps;% actual time from beginning of frames
	end
	
	% Step 2: correct tilts in trajectory to produce vxx vyy along flow direction
	fprintf('                analyzing tracks, 2nd pass...\r');
	cumdirx = 0;	% cumulative direction vector x
	cumdiry = 0;	% cumulative direction vector y
	for t = 1:N_tracks
		if mean(tracks(t).quality) > qualityThreshold ...	% condition 1 - overall track quality
		&& mean(tracks(t).area) < areaThreshold ...			% condition 2
			% join up all vectors, since each tracks vector is just
			% beginning to end, we just joing up that way
			L = tracks(t).length;
			cumdirx = cumdirx + tracks(t).x(L) - tracks(t).x(1);
			cumdiry = cumdiry + tracks(t).y(L) - tracks(t).y(1);
			
		end
	end
	mean_angle = atan2(cumdiry,cumdirx);
	% create velocity in the projected direction of mean_angle
	for t = 1:N_tracks
		if mean(tracks(t).quality) > qualityThreshold ...	% condition 1 - overall track quality
		&& mean(tracks(t).area) < areaThreshold ...			% condition 2 - overall area threshold
			% get only the distance component along mean angle
			relative_angle = tracks(t).angle - mean_angle;
			tracks(t).vxx = tracks(t).d .* cos(relative_angle) * pixelSize * fps;
			tracks(t).vyy = tracks(t).d .* sin(relative_angle) * pixelSize * fps;
 			tracks(t).xx = [0 cumsum(tracks(t).dx .* cos(relative_angle)) * pixelSize];	% insert 0 at the beginning to indicate starting point and bring length of this to L instead of L-1 of velocity
			tracks(t).yy = [0 cumsum(tracks(t).dy .* abs(sin(relative_angle))) * pixelSize];	%abs(sin) because + move is + angle, - move is - angle, so then the product just sums up, so we need projection in the y direction.
		end
	end
	
	
	%% TAKE THE GOOD TRACKS
	
	fprintf('                qualified tracks:\r');
	fprintf('                ');
	N_goodTracks = 0;
	for t = 1:N_tracks
		% minimal quality on the track determines whether it'll be shown or not
		if mean(tracks(t).quality) > qualityThreshold ...	% condition 1 - overall track quality
		&& mean(tracks(t).area) < areaThreshold ...			% condition 2 - overall area threshold
		&& sum(abs(tracks(t).dx)) > distanceThreshold ...	% condition 3 - total x distance
		&& tracks(t).length > durationThreshold				% condition 4
			fprintf('%d ',t);
			N_goodTracks = N_goodTracks + 1;
			goodTracks(N_goodTracks) = tracks(t);	
		end
	end
	fprintf('\r');
	
	if N_goodTracks ==0
		fprintf('\rERROR: analyzeTracks2 - no goodTracks selected, lower requirement\r');
		goodTracks=[];
	end
	
	%% PLOTTING SOME RESULTS
	figure('Position',[50 0 1500 800]);	
	
	spacing = 0.04;
	padding = 0.01;
	margin = 0.04;
	
	% generate color map for each track
	map=colormap(jet);
	maxQ = 0;
	minQ = 1;
	medQ = [];
	for t=1:N_goodTracks
		medQ(t) = median(goodTracks(t).quality);
		if medQ(t) > maxQ
			maxQ = medQ(t);
		end
		if medQ(t) < minQ
			minQ = medQ(t);
		end
	end
	
	for t=1:N_goodTracks
		if maxQ ~= minQ
			linecolor{t} = map(ceil((medQ(t)-minQ)/(maxQ-minQ)*63+1),:);
		else
			linecolor{t} = map(1,:);
		end
	end
	% x ---------------------------------------------------------------------
	subaxis(3,4,1, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('time [s]');
	ylabel('x - raw [pixel]');
	hold on;
	for t=1:N_goodTracks
		plot(goodTracks(t).time,goodTracks(t).x,'Marker','.','Color',linecolor{t});
	end
	% y ---------------------------------------------------------------------
	subaxis(3,4,5, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('time [s]');
	ylabel('y - raw [pixel]');
	hold on;
	for t=1:N_goodTracks
		plot(goodTracks(t).time,goodTracks(t).y,'Marker','.','Color',linecolor{t});
	end
	% xx ---------------------------------------------------------------------
	subaxis(3,4,2, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('time [s]');
	ylabel('xx - corrected [um]');
	hold on;
	for t=1:N_goodTracks
		plot(goodTracks(t).time,goodTracks(t).xx,'Color',linecolor{t});
	end
	% yy ---------------------------------------------------------------------
	subaxis(3,4,6, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('time [s]');
	ylabel('yy - corrected [um]');
	hold on;
	for t=1:N_goodTracks
		plot(goodTracks(t).time,goodTracks(t).yy,'Color',linecolor{t});
	end
	% vxx ---------------------------------------------------------------------
	subaxis(3,4,3, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('time [s]');
	ylabel('vxx - corrected [um/s]');
	hold on;
	stacker=0;
	for t=1:N_goodTracks
		plot(get(gca,'xlim'), [stacker stacker],':k');
		plot(goodTracks(t).time(1:end-1),goodTracks(t).vxx+stacker,'Color',linecolor{t});
		stacker = stacker + 50;
	end
	% vyy ---------------------------------------------------------------------
	subaxis(3,4,7, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('time [s]');
	ylabel('vyy - corrected [um/s]');
	hold on;
	stacker=0;
	for t=1:N_goodTracks
		plot(get(gca,'xlim'), [stacker stacker],':k');
		plot(goodTracks(t).time(1:end-1),goodTracks(t).vyy+stacker,'Color',linecolor{t});
		stacker = stacker + 50;
	end
	% speed v ---------------------------------------------------------------------
	subaxis(3,4,11, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('time [s]');
	ylabel('v [um/s]');
	hold on;
	stacker=0;
	for t=1:N_goodTracks
		plot(get(gca,'xlim'), [stacker stacker],':k');
		plot(goodTracks(t).time(1:end-1),goodTracks(t).v+stacker,'Color',linecolor{t});
		stacker = stacker + 50;
	end
	% vxx - smooth overlap  ---------------------------------------------------------------------
	smoothlvl = round(fps/2);		% smoothlevel!!!
	subaxis(3,4,4, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('time [s]');
	ylabel(['vxx - corrected [um/s] smooth:' num2str(smoothlvl)]);
	hold on;
	for t=1:N_goodTracks
		plot(goodTracks(t).time(1:end-1),smooth(goodTracks(t).vxx,smoothlvl),'.','Color',linecolor{t},'MarkerSize',1);
	end
	plot(get(gca,'xlim'), [0 0],':k');
	% vyy - smooth overlap  ---------------------------------------------------------------------
	subaxis(3,4,8, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('time [s]');
	ylabel(['vyy - corrected [um/s] smooth:' num2str(smoothlvl)]);
	hold on;
	for t=1:N_goodTracks
		plot(goodTracks(t).time(1:end-1),smooth(goodTracks(t).vyy,smoothlvl),'.','Color',linecolor{t},'MarkerSize',1);
	end
	plot(get(gca,'xlim'), [0 0],':k');
	% x vs y ---------------------------------------------------------------------
	subaxis(3,4,9, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('x [pixel]');
	ylabel('y [pixel]');
	imshow(zeros(512,512),'Border','tight');
	hold on;
	for t=1:N_goodTracks
		plot(goodTracks(t).x,goodTracks(t).y,'-','Color',linecolor{t});
	end	
	plot([1 512],[256 256+512*tan(mean_angle)],':w');
	% area ---------------------------------------------------------------------
	subaxis(3,4,10, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('time [s]');
	ylabel('area [pixel^2]');
	hold on;
	stacker=0;
	for t=1:N_goodTracks
		plot(get(gca,'xlim'), [stacker stacker],':k');
		plot(goodTracks(t).time,goodTracks(t).area+stacker,'Marker','.','Color',linecolor{t});
		stacker = stacker + 50;
	end

	% quality ---------------------------------------------------------------------
	subaxis(3,4,12, 'Spacing', spacing, 'Padding', padding, 'Margin', margin);
	xlabel('time [s]');
	ylabel('quality (1-eccentricity)');
	hold on;
	stacker=0;
	for t=1:N_goodTracks
		plot(get(gca,'xlim'), [stacker stacker],':k');
		plot(goodTracks(t).time,goodTracks(t).quality+stacker,'Marker','.','Color',linecolor{t});
		stacker = stacker + 1;
	end
	% ---------------------------------------------------------------------
	fig2png(pwd, 'analyzeTrack2.png');
	fprintf('                time...(%4.2f s)\r',toc);
end
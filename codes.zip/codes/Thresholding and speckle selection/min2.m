% min2 - finds the minimal element and index of M
% Author: Isaac Li
% Date: 2014-06-17
% INPUTS:
%  M	  - an (nxm) 2-dimensional numeric array (or
%			vector) that min is able to operate on. M
%			may contain inf or -inf elements.
% OUTPUTS:
%  minel  - overall minimum element found. If the
%			minimum was ot unique, then this is the
%			first element identified. Ties will be
%			resolved in a way consistent with find.
%  IJ	  - a (1x2) row vector, comtaining respectively
%			the row and column indices of the minimum as
%			found.
%
% Example:
%  M = magic(4)
% ans =
%    16     2     3    13
%     5    11    10     8
%     9     7     6    12
%     4    14    15     1
%
% % the overall minimum
%  [minel,IJ] = min2(M)
% minel =
%      1
% IJ =
%      4     4

function [minel,IJ] = min2(M)
	if length(size(M)) > 2
	  error('M must be a 2-d array or a vector')
	end

	% The minimum down the rows
	[minrows,rowind] = min(M,[],1);

	% find the best of these minima across the columns
	[minel,colind] = min(minrows,[],2);
	rowind = rowind(colind);

	% package the row and column indices together, in terms of the original matrix in case there was a restiction.
	IJ = [rowind,colind];
end





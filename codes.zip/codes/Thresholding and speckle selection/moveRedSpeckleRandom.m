% speckle3DRed_Random = moveRedSpeckleRandom(speckle3DRed,speckle3DRef,fp,N_output)
% Author: Isaac Li
% Version history:
% v1.0 20150824: use speckle3DRef as reference image to define region of
% nuclues and regions such as nucleoids to exclude. randomly generate new
% red speckle centers in 2D within the nucleus outside exclusion zones.
% speckle3DRed:		speckle3D containing Red channel
% speckle3DRef:		speckle3D containing reference image channel
% fp:				file path of output
% N_output:			number of output solutions
% speckle3DRed_Random: cell array of randomized speckle3DRed
% sample code: moveRedSpeckleRandom(speckle3DRed,speckle3DRef,'D:\Postdoc\Projects\Collaborations\Jingyi\2015-08-24 - random speckle',20);

function speckle3DRed_Random = moveRedSpeckleRandom(speckle3DRed,speckle3DRef,fp,N_output)

	%% displaying selection image
	IRGBselect(:,:,1) = imadjust(speckle3DRef.I_R3D(:,:,round(size(speckle3DRef.I_R3D,3)/2)));
	IRGBselect(:,:,2) = imadjust(speckle3DRef.I_G3D(:,:,round(size(speckle3DRef.I_G3D,3)/2)));
	IRGBselect(:,:,3) = imadjust(speckle3DRef.I_B3D(:,:,round(size(speckle3DRef.I_B3D,3)/2)));
	h1 = figure, imshow(IRGBselect,'Border','tight'), hold on;
	
	%% selecting outer boundary
	disp('Selecting nucleus boundary: ');
	[x0,y0] = ginput;
	x0 = round(x0);	% mouse event non integer
	y0 = round(y0);	% mouse event non integer
	plot([x0; x0(1)],[y0; y0(1)],'--ow');
	drawnow;

	%% selecting voids
	numberOfVoids = input('Number of voids: ');
	for i = 1:numberOfVoids
		disp(['Selecting void#: ' num2str(i)]);
		[xtmp,ytmp] = ginput;
		xv{i} = round(xtmp);	% mouse event non integer
		yv{i} = round(ytmp);	% mouse event non integer
		plot([xv{i}; xv{i}(1)],[yv{i}; yv{i}(1)],'--ow');
		text(mean(xv{i}),mean(yv{i}),num2str(i),'color','w');
		drawnow;
	end
% 	savefig(h1,[fp '\selection_map.fig']);
	
	%% generating pixel list
	imgSize = size(IRGBselect(:,:,1));
	[ylist,xlist] = ind2sub(imgSize, find(ones(imgSize)));
	
	innucleus = inpolygon(xlist,ylist,x0,y0);
	innucleusImg = zeros(imgSize);
	innucleusImg(innucleus) = 1;
	legalImg = logical(innucleusImg);					% final image
	for i=1:numberOfVoids
		invoid{i} = inpolygon(xlist,ylist,xv{i},yv{i});
		invoidImg{i} = zeros(imgSize);
		invoidImg{i}(invoid{i}) = 1;
		legalImg = legalImg & ~logical(invoidImg{i});
	end
	% figure,imshow(legalImg);
	
	% this is the list of x and y that are within the selection boundary
	[ylistlegal,xlistlegal] = ind2sub(imgSize, find(legalImg));
	legalsize = length(ylistlegal);
	
	%% assign points
	h2 = figure, imshow(IRGBselect,'Border','tight'), hold on;
	plot(speckle3DRed.x,speckle3DRed.y,'sw','markersize',20);
	text(speckle3DRed.x,speckle3DRed.y,'x','color','w');
	for i=1:N_output
% 		speckle3DRed_Random{i} = speckle3DRed;
		for j=1:speckle3DRed.N
			choice = ceil(rand*legalsize-2)+1;
			speckle3DRed_Random{i}.N = speckle3DRed.N;
			speckle3DRed_Random{i}.z = speckle3DRed.z;
			speckle3DRed_Random{i}.imgclass = speckle3DRed.imgclass;
			speckle3DRed_Random{i}.x(j) = xlistlegal(choice);
			speckle3DRed_Random{i}.y(j) = ylistlegal(choice);
	
			plot(xlistlegal(choice),ylistlegal(choice),'ow','markersize',20);
			text(xlistlegal(choice),ylistlegal(choice),num2str(i),'color','w');
		end
	end
	drawnow;
% 	savefig(h2, [fp '\random_speckle_map.fig');

	%% save .mat file

	save([fp '\speckle3DRed_1_Random.mat'],'speckle3DRed_Random');









end
% max2 - finds the maximal element and index of M
% Author: Isaac Li
% Date: 2014-06-17
% INPUTS:
%  M	  - an (nxm) 2-dimensional numeric array (or
%			vector) that max is able to operate on. M
%			may contain inf or -inf elements.
% OUTPUTS:
%  maxel  - overall maximum element found. If the
%			maximum was ot unique, then this is the
%			first element identified. Ties will be
%			resolved in a way consistent with find.
%  IJ	  - a (1x2) row vector, comtaining respectively
%			the row and column indices of the maximum as
%			found.
%
% Example:
%  M = magic(4)
% ans =
%    16     2     3    13
%     5    11    10     8
%     9     7     6    12
%     4    14    15     1
%
% % the overall maximum
%  [maxel,IJ] = max2(M)
% maxel =
%      16
% IJ =
%      1     1

function [maxel,IJ] = max2(M)
	if length(size(M)) > 2
	  error('M must be a 2-d array or a vector')
	end

	% The maximum down the rows
	[maxrows,rowind] = max(M,[],1);

	% find the best of these maxima across the columns
	[maxel,colind] = max(maxrows,[],2);
	rowind = rowind(colind);

	% package the row and column indices together, in terms of the original matrix in case there was a restiction.
	IJ = [rowind,colind];
end





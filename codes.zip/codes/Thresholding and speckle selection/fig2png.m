function fig2png(filepath, filename)
	currentFolder = pwd;
	cd(filepath);
	
	ppm=get(gcf,'PaperPositionMode');
	set(gcf,'PaperPositionMode','auto');
	
	print('-dpng','-r300',filename);
	
	set(gcf,'PaperPositionMode',ppm);
	
	cd(currentFolder);
	return;
end
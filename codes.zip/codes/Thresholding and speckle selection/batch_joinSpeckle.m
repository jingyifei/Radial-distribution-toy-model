clear all
filepath = 'D:\Speckle_SIM\10182015_scr_col_R_SC35_G_SON_B\4\c4\R_T3000_D100_V1000';
load([filepath '\speckle3D.mat']);	% loads speckle3D
channel = 'R';					% set channel
mergeIndex{1} = [2 3];			% sets of speckles to be merged
%mergeIndex{2} = [2 4];
% mergeIndex{3} = [3 4 10];
% mergeIndex{4} = [5 11];

speckle3D = joinSpeckle(speckle3D,channel,mergeIndex);


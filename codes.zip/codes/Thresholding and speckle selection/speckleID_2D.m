% speckle3D = speckleID(filepath, P)
% Author: Isaac Li
% Date: 2015-08-07
% Description: This function is now only to identify speckles from stacks
% of images. 

% Sample code:
% 	filepath = 'D:\Postdoc\Projects\Collaborations\Jingyi\2015-07-01 - more speckle\sample1';
% 	% set parameters
% 	P.imgclass = 'uint16';
% 	P.imageMax = 65535;							% 16 bit data max
% 	P.zdim = 31;								% # z slices updated by cellSelect
% 	P.intensityThreshold = 7000;				% intensity threshold - speckle selection
% 	P.dust = 25;								% < this many pixel in each slice objects destroyed
% 	P.volumeThreshold = 1000;					% volume cut off for selecting speckle
% 	P.method = 'RGB';							% RGB or RB
% 	P.pixelXY = 0.04;							% 0.04 um/pixel x,y, resolution
% 	P.pixelZ = 0.126;							% 0.126 um/pixel z resolution
% 	P.radialHistBin = 0.1;						% radial RGB intensity distribution bin size in um.
% 	P.radialNBin = 20;                          % how many bins are needed
% 	% update parameters
% 	P = cellSelect(filepath, P);				% update P.zdim, P.numCell, P.cellPolygonX, P.cellPolygonY;
% 	% run for each cell
% 	for c = 1:P.numCell
% 		P.cellIndex = c;
% 		speckle3D = speckleID(filepath, P);
% 	end

function speckle2D = speckleID(filepath, P)
	tic;
	%% ========================================================================
	% loading images
	fprintf('1. loading tiff files...\r');
    f1 = dir([filepath '\R.tif']);
    I_raw(:,:,1) = imread([filepath '\' f1.name]);
    f2 = dir([filepath '\G.tif']);
    I_raw(:,:,2) = imread([filepath '\' f2.name]);
    f3 = dir([filepath '\B.tif']);
    I_raw(:,:,3) = imread([filepath '\' f3.name]);
    %[I_raw,filelist,N] = imageLoad(filepath,'tif');


	%% ========================================================================
	% parameter list
	fprintf('2. setting parameters...\r');
	cellIndex			= P.cellIndex;						% current cell
	max16				= P.imageMax;						% 65535 for 16 bit, 255 for 8 bit;
	threshold16			= P.intensityThreshold;				% uint16 threshold
	binaryThreshold		= threshold16/max16;				% binary threshold
	dustThreshold		= P.dust;							% dust pixel size
	volumeThreshold		= P.volumeThreshold;				% speckle volume size
	method				= P.method;							% 'RGB' or 'RB'
	pixelXY				= P.pixelXY;						% 0.04 um/pixel x,y, resolution
	pixelZ				= P.pixelZ;							% 0.126 um/pixel z resolution
	radialHistBin		= P.radialHistBin;					% radial RGB intensity distribution bin size in um.
    radialNBin			= P.radialNBin;						% how many bins are needed
	imgclass			= P.imgclass;

	fp_results	= [filepath '\c' num2str(cellIndex) '\' method '_T' num2str(threshold16) '_D' num2str(dustThreshold) '_V' num2str(volumeThreshold)];
	fn_crop		= ['crop.tif'];
	fn_R		= ['R.tif'];
	fn_G		= ['G.tif'];
	fn_B		= ['B.tif'];
	fn_gray 	= ['gray.tif'];
	fn_IntHist	= ['intensity_histogram.png'];
	fn_Ibw		= ['th' num2str(threshold16) '.tif'];
	fn_Ibw1		= ['th' num2str(threshold16) '_fill.tif'];
	fn_Ibw2		= ['th' num2str(threshold16) '_fill_dust' num2str(dustThreshold) '.tif'];
	fn_Ibw3		= ['th' num2str(threshold16) '_fill_dust' num2str(dustThreshold) '_outline.tif'];
	fn_common	= ['th' num2str(threshold16) '_fill_dust' num2str(dustThreshold) '_common.tif'];
	fn_contour	= ['th' num2str(threshold16) '_fill_dust' num2str(dustThreshold) '_contour.tif'];
	fn_map		= ['th' num2str(threshold16) '_fill_dust' num2str(dustThreshold) '_v' num2str(volumeThreshold) '_map.png'];
% 	fn_radial	= ['th' num2str(threshold16) '_fill_dust' num2str(dustThreshold) '_v' num2str(volumeThreshold) '_radialDistribution.png'];
	fn_3D		= ['3D.png'];
	fn_3Dsurface= ['3D_surface.png'];
% 	fn_AreaZ	= ['AreaZ.png'];
% 	fn_PearsonRGz	= ['PearsonRGz.png'];
% 	fn_PearsonRBz	= ['PearsonRBz.png'];
% 	fn_PearsonGBz	= ['PearsonGBz.png'];
% 	
% 	fn_excel	= [fp_results '\speckle3D.xlsx'];
	fn_mat		= [fp_results '\speckle2D.mat'];
	if ~exist(fp_results,'dir')
		mkdir(fp_results);
	end

	%% ========================================================================
	% crop image
	fprintf('3. crop images...\r');
	xbound = [min(P.cellPolygonX{P.cellIndex}) max(P.cellPolygonX{P.cellIndex})];		%[500 1120] are extrema of x
	ybound = [min(P.cellPolygonY{P.cellIndex}) max(P.cellPolygonY{P.cellIndex})];		%[770 1650] are extrema of y
	xdim = xbound(2)-xbound(1)+1;
	ydim = ybound(2)-ybound(1)+1;
	zdim = P.zdim;

	I_crop = imageCrop(I_raw,xbound(1),xbound(2),ybound(1),ybound(2));
	frame2tiff(I_crop,fp_results,fn_crop);
	
	%% ========================================================================
	% isolate RGB component and convert to grayscale
	fprintf('4. RGB grayscale convert and output...\r');
	%for i=1:zdim
		I_R(:,:) = I_crop(:,:,1);
		I_G(:,:) = I_crop(:,:,2);
		I_B(:,:) = I_crop(:,:,3);
		switch method
			case 'RGB'
				I_gray = I_crop(:,:,1)/3 + I_crop(:,:,2)/3 + I_crop(:,:,3)/3;	% (R+G+B)/3
			case 'RB'
				I_gray = I_crop(:,:,1)/2 + I_crop(:,:,3)/2;	% (R+B)/2
			case 'GB'
				I_gray = I_crop(:,:,2)/2 + I_crop(:,:,3)/2;	% (G+B)/2
			case 'RG'
				I_gray = I_crop(:,:,1)/2 + I_crop(:,:,2)/2;	% (R+G)/2
			case 'R'
				I_gray = I_crop(:,:,1);	% R
			case 'G'
				I_gray = I_crop(:,:,2);	% G
			case 'B'
				I_gray = I_crop(:,:,3);	% B
			otherwise
				I_gray = I_crop(:,:,1)/3 + I_crop(:,:,2)/3 + I_crop(:,:,3)/3;	% (R+G+B)/3
				fprintf('   WARNING: using all RGB channels\r');
		end
	%end
	frame2tiff(I_R,fp_results,fn_R);
	frame2tiff(I_G,fp_results,fn_G);
	frame2tiff(I_B,fp_results,fn_B);
	frame2tiff(I_gray,fp_results,fn_gray);

	%% ========================================================================
	% total intensity histogram 
	fprintf('5. total intensity histogram in for all z stack...\r');
	Nbins = 100;
	%for i=1:zdim
		xhist = 1:(max16/Nbins):max16;
		hist_stack = hist(I_gray(:),xhist);
	%end
	map=colormap(jet);
% 	for i=1:zdim
% 		linecolor{i} = map(ceil(i/zdim*63),:);
% 	end
% 	figure; hold on;
% 	for i=1:zdim
% 		plot(xhist, hist_stack, 'Color', linecolor{i});
        plot(xhist, hist_stack);
% 	end
	hold off;
	set(gca,'YScale','log')

	fig2png(fp_results, fn_IntHist);
	close all;
	
	%% ========================================================================
	% thresholding
	fprintf('6. threshold by z slice and write to tiff...\r');
	seD = strel('diamond',1);						% diamond structure element
% 	for i=1:zdim
		I = mat2gray(I_gray,[0 max16]);			% convert to 0-1 grayscale
		Ibw = im2bw(I,binaryThreshold);			% threshold imagefigure;
		Ibw1 = imdilate(Ibw,seD);				% create connection
		Ibw1 = imfill(Ibw1,'holes');			% fills holes in the image
		Ibw1 = imerode(Ibw1,seD);				% restore edge expansion
		Ibw2 = bwareaopen(Ibw1,dustThreshold);% eat dusts < after 
		Ibw3 = bwperim(Ibw2);					% creates outline
% 	end

	% common region image of all regions stacked
	Ibw_common = Ibw2;
% 	for i=2:zdim
% 		Ibw_common = Ibw_common + Ibw2{i};
% 	end

	% contour image of each z stack
	r = zeros(size(Ibw_common));
	g = zeros(size(Ibw_common));
	b = zeros(size(Ibw_common));
% 	for i=1:zdim
 		r(Ibw3) = 1;
 		g(Ibw3) = 2;
 		b(Ibw3) = 3;
% 	end
	Ibw_contour(:,:,1) = r;
	Ibw_contour(:,:,2) = g;
	Ibw_contour(:,:,3) = b;

	% write to files
	frame2tiff(Ibw,fp_results,fn_Ibw);
	frame2tiff(Ibw1,fp_results,fn_Ibw1);
	frame2tiff(Ibw2,fp_results,fn_Ibw2);
	frame2tiff(Ibw3,fp_results,fn_Ibw3);
	frame2tiff(Ibw_common,fp_results,fn_common);
	frame2tiff(Ibw_contour,fp_results,fn_contour);
	
	%% ========================================================================
	% construct 3D images
% 	fprintf('7. constructing 3D image...\r');
    fprintf('7. constructing 2D image...\r');
% 	for i=1:zdim
% 		Ibw3D(:,:,i) = Ibw2{i};
% 		I_R3D(:,:,i) = I_R{i};
% 		I_G3D(:,:,i) = I_G{i};
% 		I_B3D(:,:,i) = I_B{i};
% 	end
		Ibw2D = Ibw2;
		I_R2D = I_R;
		I_G2D = I_G;
		I_B2D = I_B;
% 	ibw3D_surface = bwperim(Ibw3D);

	% draw 2D solid plot
	clear x y;
	[x y] = ind2sub(size(Ibw2D), find(Ibw2D));
	figure;
	plot(x, y, '.' ,'markersize',1);
% 	axis equal; axis tight;
% 	daspect([max(daspect)*[pixelXY pixelXY] pixelZ]);
	fig2png(fp_results,fn_3D);
	close all;
	
% 	% draw 3D solid plot
% 	clear x y z;
% 	[x y z] = ind2sub(size(Ibw3D), find(Ibw3D));
% 	figure('Position',[100 100 1200 600]);
% 	plot3(x, y, z, '.' ,'markersize',1);
% % 	axis equal; axis tight;
% 	daspect([max(daspect)*[pixelXY pixelXY] pixelZ]);
% 	fig2png(fp_results,fn_3D);
% 	close all;
	
% 	% draw 3D surface plot
% 	clear x y z;
% 	[x y z] = ind2sub(size(ibw3D_surface), find(ibw3D_surface));
% 	figure('Position',[100 100 1200 600]);
% 	plot3(x, y, z, '.' ,'markersize',1);
% % 	axis equal; axis tight;
% 	daspect([max(daspect)*[pixelXY pixelXY] pixelZ]);
% 	fig2png(fp_results,fn_3Dsurface);
% 	close all;

	%% ========================================================================
	% finding clusters with 3D images
	fprintf('8. 3D connected component analysis...\r');
	cc = bwconncomp(Ibw2D, 8);
	Pobj3D = regionprops(cc, 'Area','BoundingBox','Centroid','PixelList','PixelIdxList');
	N = length(Pobj3D);
	
	%% ========================================================================
	% filter Pobj3D and get rid of small volumes and out-of-boundary volumes
	fprintf('9. filter by volume...%4.0f and bound area\r',volumeThreshold);
	for i = N:-1:1
		if (Pobj3D(i).Area < volumeThreshold) || ~inpolygon(Pobj3D(i).Centroid(1),Pobj3D(i).Centroid(2),P.cellPolygonX{P.cellIndex}-xbound(1),P.cellPolygonY{P.cellIndex}-ybound(1))
			Pobj3D(i) = [];
		end
	end
	N = length(Pobj3D);
 
	%% ========================================================================
	% draw index map
	fprintf('10. drawing index map...\r');
% 	figure, imshow(Ibw_contour/2,'Border','tight'), hold on;	
    figure, imshow(Ibw_contour,'Border','tight'), hold on;		
	for i=1:N
		text(Pobj3D(i).Centroid(1),Pobj3D(i).Centroid(2),['\color{white}' num2str(i)],'HorizontalAlignment','center','VerticalAlignment','middle');
	end
	drawnow;
	fig2png(fp_results, fn_map);
	close all
	
	%% ========================================================================
	% write speckle3D data structure.
	fprintf('11. write basic speckle3D data structure.\r');
	speckle2D.N = N;
	for i = 1:N
		% basic properties
		speckle2D.x(i) = Pobj3D(i).Centroid(1);
		speckle2D.y(i) = Pobj3D(i).Centroid(2);
% 		speckle3D.z(i) = Pobj3D(i).Centroid(3);
		speckle2D.v(i) = Pobj3D(i).Area;
		speckle2D.imgclass = imgclass;
		% generating individual speckle
		BoundingBoxSize = [Pobj3D(i).BoundingBox(4) Pobj3D(i).BoundingBox(3)];
%         BoundingBoxSize = [Pobj3D(i).BoundingBox(5) Pobj3D(i).BoundingBox(4) Pobj3D(i).BoundingBox(6)];	% absolutely necessary flip of dimension matlab image processing convention and matrix convention different. x-y flip and index order for images are different.
		speckle2D.R3D{i} = cast(zeros(BoundingBoxSize),imgclass);										% creating appropriate box
		speckle2D.G3D{i} = cast(zeros(BoundingBoxSize),imgclass);
		speckle2D.B3D{i} = cast(zeros(BoundingBoxSize),imgclass);

		PixelListRelative = floor(Pobj3D(i).PixelList - repmat(Pobj3D(i).BoundingBox(1:2),length(Pobj3D(i).PixelList),1) + 1);
% 		[size(speckle3D.R3D{i}) min(PixelListRelative) max(PixelListRelative)]
% 		[size(I_R3D) min(Pobj3D(i).PixelList) max(Pobj3D(i).PixelList)]
		
% 		indList_relative = sub2ind(size(speckle3D.R3D{i}),PixelListRelative(:,2),PixelListRelative(:,1),PixelListRelative(:,3));	% notice the order is 2,1,3
% 		indList_absolute = sub2ind(size(I_R3D),Pobj3D(i).PixelList(:,2),Pobj3D(i).PixelList(:,1),Pobj3D(i).PixelList(:,3));			% notice the order is 2,1,3
		indList_relative = sub2ind(size(speckle2D.R3D{i}),PixelListRelative(:,2),PixelListRelative(:,1));	% notice the order is 2,1,3
		indList_absolute = sub2ind(size(I_R2D),Pobj3D(i).PixelList(:,2),Pobj3D(i).PixelList(:,1));		
        
		speckle2D.R3D{i}(indList_relative) = I_R2D(indList_absolute);	%{index}(x,y)
		speckle2D.G3D{i}(indList_relative) = I_G2D(indList_absolute);
		speckle2D.B3D{i}(indList_relative) = I_B2D(indList_absolute);
        speckle2D.RGB3D{i}(:,:,1) = speckle2D.R3D{i};					% {index}(x,y,color) in a single matrix
		speckle2D.RGB3D{i}(:,:,2) = speckle2D.G3D{i};
		speckle2D.RGB3D{i}(:,:,3) = speckle2D.B3D{i};
% 		speckle3D.RGB3D{i}(:,:,:,1) = speckle3D.R3D{i};					% {index}(x,y,z,color) in a single matrix
% 		speckle3D.RGB3D{i}(:,:,:,2) = speckle3D.G3D{i};
% 		speckle3D.RGB3D{i}(:,:,:,3) = speckle3D.B3D{i};
		
		speckle2D.I_R3D = I_R2D;	% whole nucleus image
		speckle2D.I_G3D = I_G2D;
		speckle2D.I_B3D = I_B2D;
		
		speckle2D.Pobj3D = Pobj3D;
	end
	
	
	%% ========================================================================
	% write matlab file
	fprintf('12. write speckle2D to .mat files\r');
	save(fn_mat,'speckle2D');	% save .mat

	%% ========================================================================
	fprintf('\r');
	fprintf(2, 'DONE! (%4.2f seconds)\r',toc);
	fprintf('\r\r');

end



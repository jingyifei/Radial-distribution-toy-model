% cellID_edge - indentification of individual cells by Canny edge method
% Author: Isaac Li
% Date: 2014-04-30
% Version history:
% 1.2 - individually dialated cells with better boundary shape, a better
% original image filter with imfill(I)-I.
% 1.1 - isolation of individual cells by 8 pass binary method, isolate
% connected cells with certainty, also gets rid of cells touching borders.
% method involves canny edge detection, gap closing operation and reversing
% image to detect interior. version 1.1 is much more superior to previous
% version that required individual tuning
% 1.0 - eukaryotic sample tested. basic method that works, using roberts edge
% method, fill in and connected element detection. still has problems, need
% further development
%
% INPUTS:
%	frames:		cell arrays of images, frames{i} is a grayscale 2D array
%	T:			threshold information (optional with default in place)
%				.binaryThreshold - canny method binary image threshold
%				.dustThreshold - dust size limit for removal
% OUTPUTS:
%	Pobj:		object properties cell array, Pobj{i} for frames{i}
%				Pobj{i}(j).Area - the jth object in ith frame
%				Pobj{i}(j).Centroid - the jth object in ith frame
%	I_Binary:	bw image of detected cells, even with overlap, the area
%				is still of individual images due to v.1.2 processing
%				(sparse)
%	I_Centroid:	centroid position bw image (sparse)
%	I_Outline:	bw image of the outline of each cell (sparse)

function [Pobj,I_Binary,I_Centroid,I_Outline] = cellID_edge(frames,T)
	%% THRESHOLD ASSIGNMENT
	% default values of each threshold	
	binaryThreshold = 2;	% binary image threshold
	dustThreshold = 20;		% max size of dust to be cleaned up
	if nargin == 2
		if isfield(T,'binary') == 1
			binaryThreshold = T.binary;	% binary image threshold for standard deviation
		end
		if isfield(T,'dust') == 1
			dustThreshold = T.dust;		% max size of dust to be cleaned up
		end
	end
		
	%% MAIN ANALYSIS
	N_frames = size(frames,2);
	fprintf('cellID_edge: identifying cells...\r');
	%% GET NEW frames MEAN MODE AND STDEV
% 	fprintf('        getting mean of mode and stdev...\r');
% 	for i=1:N_frames
% 		I_gray = mat2gray(frames{i},[0 255]);
% 		fm(i) = mode(I_gray(:));					% mode of image
%  		fs(i) = std(I_gray(:));						% stdev of image
% 	end
% 	m = mean(fm);
% 	s = mean(fs);
	%% MAIN IMAGE PROCESSING AND OBJECT ID
	fprintf('        process each frame...\r');
	se90 = strel('line', 3, 90);		% 90 degree 3 length segment
	se0 = strel('line', 3, 0);			% 0 degree 3 length segment
	seD = strel('diamond',1);			% cross strel
		
	for i=1:N_frames
% 		frame_height = size(frames{i},1);
% 		frame_width = size(frames{i},2);	
		% convert uint8 frame to 0-1 binary:
		I = mat2gray(frames{i});
		I = imageAdjust(I);

		% version 1.1 - bright field cell
		% background subtraction - made unnecessary from static bg subtraction
% 		disk = strel('disk',20);
% 		background = imopen(I,disk);					% this processes on CPU
% 		I = I - background;	
% 	
%  		[~, threshold] = edge(I, 'roberts');
%  		Ibw = edge(I,'roberts',threshold,'thinning');
% 
% 		se90 = strel('line', 3, 90);		% 90 degree 3 length segment
% 		se0 = strel('line', 3, 0);			% 0 degree 3 length segment
% 		seD = strel('diamond',1);			% diamond structure element
% 		
% 		Ibw = imdilate(Ibw, [se90 se0]);	% dialate
% 		Ibw = imdilate(Ibw, [se90 se0]);	% dialate
% 		
%  		Ibw = imfill(Ibw,'holes');			% fills holes in the image
% 		Ibw = bwareaopen(Ibw,dustThreshold);% eat dusts <100pixel total area
% 		Ibw = imclearborder(Ibw, 4);		% clear images touching border
% 		Ibw = imerode(Ibw,seD);	
% 		Ibw = imerode(Ibw,seD);	
% 		Ibw = bwareaopen(Ibw,dustThreshold);% eat dusts <100pixel total area
		
		% version 1.2

		I = imfill(I) - I;					% very good detector!
		
		% binary detection
		[~, threshold] = edge(I, 'canny');					% canny edge detection
  		Ibw = edge(I,'canny',threshold*binaryThreshold);	% canny edge detection	
		Ibw_dialate = imdilate(Ibw, seD);					% dialate kill gap
		Ibw_fill = 1 - imfill(Ibw_dialate,'holes');			% fills holes and inverse
		Ibw_inside = 1 - (Ibw + Ibw_fill);					% define interior
		Ibw_dialate = imerode(Ibw_inside,seD);				% kill 2ndary boundary
		Ibw_dialate = bwareaopen(Ibw_dialate,dustThreshold);% eat dusts <100pixel total area
		Ibw_dialate = imdilate(Ibw_dialate, seD);			% reverse cell shape level 1 - safe expansion
		Ibw_final = imclearborder(Ibw_dialate, 4);			% clear images touching border
		% find connected components and identify individual cell
		cc = bwconncomp(Ibw_final, 8);		% find connected elements
		N(i) = cc.NumObjects;				% total number of objects in each frame
		Pobj{i} = regionprops(cc, 'Area','Centroid');	% properties of each region
		% reverse cell shape level 2 - safe expansion individually
		I_Binary{i} = sparse(false(size(Ibw)));
		I_Outline{i} = sparse(false(size(Ibw)));
		fprintf('        process each cell...\r');
		fprintf('        ');
		for j=1:N(i)
			ccbw = false(size(Ibw));
			ccbw(cc.PixelIdxList{j}) = true;
			ccbw = imdilate(ccbw, seD);
			cc2 = bwconncomp(ccbw, 8);
			cc2Pobj = regionprops(cc2, 'Area','Centroid');
			Pobj{i}(j).Area = cc2Pobj(1).Area;
			Pobj{i}(j).Centroid = cc2Pobj(1).Centroid;
			I_Binary{i} = I_Binary{i} + ccbw;
			I_Outline{i} = I_Outline{i} + bwperim(ccbw);
			fprintf('%d ',j);
		end
		fprintf('\r');
		% drawing displays
 		I_Centroid{i} = sparse(false(size(Ibw)));			% centroid - sparse matrix method
		%I_Binary{i} = sparse(Ibw_final);			% binary image - sparse matrix method
		%I_Outline{i} = bwperim(Ibw_final);
		for j=1:N(i)
			c_x = ceil(Pobj{i}(j).Centroid(1));
			c_y = ceil(Pobj{i}(j).Centroid(2));
			I_Centroid{i}(c_y,c_x)=1;
		end
	end

end
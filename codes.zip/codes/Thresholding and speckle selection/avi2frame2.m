% avi2frame2: reads avi and spit out frames{i}, i being the frame number
% Author: Isaac Li
% Date: 2014-05-02
% Version history:
% v1.0: global scaling to min and max, select frame range 
% v2.0: much improved memory usage and speed, global min max of 10% frames
%		only, output load and write on the fly, more efficient. also added
%		cropping and enlarging function for processing low magnification
%		images with large number of cells and low pixel counts per cell.
%
% INPUTS:
%	filepath	: obvious
%	filename	: obvious
%	i1			: starting index
%	i2			: ending index, don't worry, auto error handling will take the last frame of the avi even if don't know the last real frame number.
% OUTPUTS:
%	frames		: frame{i} is the ith frame [(0-255) uint8] saves memory, each uint8 is 1 byte
%	Pmov		: movie properties, including size, duration, N frames, fps

function [frames,Pmov] = avi2frame2(filepath,filename,i1,i2)
	
	currentFolder = pwd;
	cd(filepath);

	obj = VideoReader(filename);		% VideoReader handles the total number of frame correctly - actual total number, not computed, like in mmreader
	
	Pmov.dimy = obj.Height;
	Pmov.dimx = obj.Width;
	Pmov.duration = obj.Duration;
	Pmov.Nframes = obj.NumberOfFrames;	% this is accurate now with matlab 2013a
	Pmov.fps = Pmov.Nframes / Pmov.duration;
	Pmov.spf = 1/Pmov.fps;
	
    if nargin<4
        i2 = Pmov.Nframes;
    end
    if nargin<3
        i1 = 1;
    end
    
	i1 = max(1,i1);				% index start/end error handling
	i2 = min(Pmov.Nframes,i2);	% index start/end error handling
	N_frames = i2 - i1 + 1;		% real number of frames to be loaded
	Pmov.Nframes = N_frames;
	
	tic;
	fprintf('avi2frame: video %s\r',filename);
	fprintf('           [min max] = ',filename);
	vid_min=inf;
	vid_max=-inf;
	for i=i1:10:i2		% taking every 10 frames to determins roughly the max and min
		vid = read(obj,i);	% reading only the ith frame
		vid_min = min(vid_min,min(vid(:)));
		vid_max = max(vid_max,max(vid(:)));
	end
	fprintf('[%d %d] (%4.2f s)\r',vid_min,vid_max,toc);
	tic;
	fprintf('           extract & rescale to uint8 frames...');
	for i=1:N_frames
		vid = read(obj,i+i1-1);	% reading only the ith frame
		if size(vid,3)==3		% RGB
			frames{i}(:,:) = imageAdjust(rgb2gray(vid(:,:,:)),vid_min,vid_max);		% extract frame, if originally RGB avi, then RGB is already uint8, and rgb2gray keeps it as uint8
		elseif size(vid,3)==1	% grayscale
			if length(size(vid))==3
				frames{i}(:,:) = im2uint8(imageAdjust(mat2gray(vid(:,:,1)),vid_min,vid_max));		% extract frame and convert to uint8
			elseif length(size(vid))==2
				frames{i}(:,:) = imageAdjust(vid,vid_min,vid_max);		% extract frame and convert to uint8
			end
		end
	end
	fprintf('(%4.2f s)\r',toc);
	cd(currentFolder);
	return;
end
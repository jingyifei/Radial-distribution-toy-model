% fp1='D:\Postdoc\Projects\3. Cell Rolling\2014-03-14 - HL-60 on BSA surface reproducing study\channel 2 - BSAbiotin + NA + PG + P-sel\Area 1\track';
fp2='D:\Postdoc\Projects\3. Cell Rolling\2014-03-14 - HL-60 on BSA surface reproducing study\channel 2 - BSAbiotin + NA + PG + P-sel\Area 2\track';
% fp3='C:\Users\Isaac\Desktop\Isaac\Postdoc - raw data\Projects\3. Cell Rolling\2014-02-08 - HL-60 on TGT 4 - controls\c2 - 12pNTGT-ProteinG + P-sel\region 2A\track';
% fp4='C:\Users\Isaac\Desktop\Isaac\Postdoc - raw data\Projects\3. Cell Rolling\2014-02-08 - HL-60 on TGT 4 - controls\c3 -54pNTGT-ProteinG + P-sel\region 3A\track';
% % 
% [fn1,results1] = analyzeTracks_batch(fp1);
[fn2,results2] = analyzeTracks_batch(fp2);
% [fn3,results3] = analyzeTracks_batch(fp3);
% [fn4,results4] = analyzeTracks_batch(fp4);
% 

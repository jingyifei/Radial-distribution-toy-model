% imageWrite(I,filelist,index,path,postfix)
% index applies I and filelist
% obtain filelist from imageLoad

function imageWrite(I,filelist,index,path,postfix)

	olddir=pwd;

	N1=size(I,2);
	
	% if not specifying the postfix for the new file names, use "new"
	if(nargin<5)
		postfix='new';
	end
	
	% if not specifying the current path, save to current directory
	if(nargin<4)
		path=pwd;
	end
	cd(path);
	
	% if not specifying the index, just use 1234
	if(nargin<3)
		index=1:1:N1;
	end
	
	% if not specifying file names
	if(nargin<2)
		for i=1:N1
			filelist(i,:)='test.tif';%strcat(num2str(i),'.tif');
		end
	end
	
	% error handling, maybe given the wrong names...
	if N1~= size(filelist,1);
		display('ERROR: Image and filename string not same length');
		return;
	end	
	
	N2=size(index,2);
	for i=1:N2
		[tmp,file,ext]=fileparts(filelist(index(i),:));	%splitting the file name string
		newfilelist=strcat(file,postfix,ext)
		imwrite(I{index(i)},newfilelist,'tif');
	end
	
	cd(olddir);			% return to the old directory
end
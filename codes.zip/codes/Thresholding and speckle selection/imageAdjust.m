function I2=imageAdjust(I1,low,high)
	
	if(nargin==1)	% if does not specify min and max, then take the image min and max
		I1max=cast(max(I1(:)),'double');
		I1min=cast(min(I1(:)),'double');
	else			% if specifies, then use the specified min and max
		I1max=cast(high,'double');
		I1min=cast(low,'double');
	end
	
	switch class(I1)
		case 'uint16'		
			I2min=0;			% default class is 'double'
			I2max_uint16=65535;	% uint16 max value

			I1=cast(I1,'double');
			I2=(I1-I1min)/(I1max-I1min)*I2max_uint16+I2min;
			I2=cast(I2,'uint16');
			
		case 'uint8'		
			I2min=0;			% default class is 'double'
			I2max_uint8=255;	% uint8 max value

			I1=cast(I1,'double');
			I2=(I1-I1min)/(I1max-I1min)*I2max_uint8+I2min;
			I2=cast(I2,'uint8');
			
		case {'single','double'}
			I2min=0;
			I2max_double=1;

			I2=(I1-I1min)/(I1max-I1min)*I2max_double+I2min;
	end
end
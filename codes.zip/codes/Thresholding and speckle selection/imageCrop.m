% imageCrop crops input image I or input image cell array I
% INPUT:
%	I	  - input image
%	x1,x2 - x dimension range
%	y1,y2 - y dimension range
% OUTPUT:
%	Icrop - cropped image
%	Ires  - residual image with cropped area = 0

function [Icrop,Ires,Pmov] = imageCrop(I,x1,x2,y1,y2,Pmov)
	switch class(I)
		% case for input being a cell array
		case 'cell'
			s = size(I{1});	% image size s(1) in x, s(2) in y
			Icrop=[];
			Ires=[];
			% error handling
			if x1>=x2 || y1>=y2 || x1<1 || x2>s(2) || y1<1 || y2>s(1)
				fprintf('imageCrop ERROR: x1(%d) x2(%d) y1(%d) y2(%d) dimx(%d) dimy(%d)\r\r',x1,x2,y1,y2,s(1),s(2));
				return;
			end
			for i = 1:length(I)
				Icrop{i} = I{i}(y1:y2,x1:x2,:);		% takes care of both grayscale and RGB images
				Ires{i} = I{i};
				Ires{i}(y1:y2,x1:x2,:) = 0;
			end
			if(nargin>5)
				Pmov.dimx = x2-x1+1;
				Pmov.dimy = y2-y1+1;
			end
		% case for input being a single image (likely the otherwise case)
		otherwise
			s = size(I);	% image size s(1) in x, s(2) in y
			Icrop=[];
			Ires=[];
			% error handling
			if x1>=x2 || y1>=y2 || x1<1 || x2>s(2) || y1<1 || y2>s(1)
				fprintf('imageCrop ERROR: x1(%d) x2(%d) y1(%d) y2(%d) dimx(%d) dimy(%d)\r\r',x1,x2,y1,y2,s(1),s(2));
				return;
			end
			Icrop = I(y1:y2,x1:x2,:);
			Ires = I;
			Ires(y1:y2,x1:x2,:) = 0;
			if(nargin>5)
				Pmov.dimx = x2-x1+1;
				Pmov.dimy = y2-y1+1;
			end
	end
end
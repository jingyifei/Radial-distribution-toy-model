% writeCompositeVideo overlaps a bunch of images per frame together 
% Author: Isaac Li
% Date: 2014-05-02
% Version history:
% v1.0:	basic overlaps, cell colored blue, track and everything using color
%		overlap method.
% v2.0:	tracks no longer cell array as they are slow, using struct arrays
%		instead now. cell are now outlined, tracks also dedicated color,
%		won't change with overlap. speed improvement!
%
% Inputs:
%	frames		: original frames  [(0-255) uint8]
%	I_Binary	: binary image [(0-1) logic] of the identified cells
%	I_Box		: image [(0-1) double, sparse] of the boundary box
%	I_Centroid	: image [(0-1) double, sparse] of centroid in sparse matrix format
%	tracks		: tracks produced by cellTrack
%	T			: threshold values:
%					T.quality	- min mean quality of a track
%					T.distx		- min dxx length to be considered
%					T.area		- max pixel^2 area to be considered
%					T.showBox	- show bounding box or now, 0 or 1;
%					T.showBin	- show binary coloring, 0 or 1;
%					T.showTrack	- show tracks coloring, 0 or 1;

function writeCompositeVideo2(frames,Pmov,I_Binary,I_Box,I_Centroid,tracks,filepath,filename,T)
	tic;
	currentFolder = pwd;
	cd(filepath);
	
	%% THRESHOLD ASSIGNMENT
	% default values of each threshold
	qualityThreshold = 0.3;		% min mean quality of a track
	distanceThreshold = 20;		% min dxx length to be considered
	areaThreshold = 1500;		% max pixel^2 area to be considered
	showBox = 1;				% default show boundingBox
	showBin = 1;				% default show Binary
	showTrack = 1;				% default show Binary
	% if there are input threshold info, use the input threshold
	if nargin == 9
		if isfield(T,'quality') == 1
			qualityThreshold = T.quality;	% min mean quality of a track
		end
		if isfield(T,'distx') == 1
			distanceThreshold = T.distx;		% min dxx length to be considered
		end
		if isfield(T,'area') == 1
			areaThreshold = T.area;			% max pixel^2 area to be considered
		end
		if isfield(T,'showBox') == 1
			showBox = T.showBox;			% max pixel^2 area to be considered
		end
		if isfield(T,'showBin') == 1
			showBin = T.showBin;			% max pixel^2 area to be considered
		end
		if isfield(T,'showTrack') == 1
			showTrack = T.showTrack;			% max pixel^2 area to be considered
		end
	end
	
	%% making computed tracks into image
	dimy = Pmov.dimy;
	dimx = Pmov.dimx;
	I_black = zeros(size(frames{1}));				% 1. create a black image
	h = figure;								% 2. open a figure
	imshow(I_black,'Border','tight');		% 3. use no border to show the black image
	hold on;								% 4. do not close
	N_tracks = size(tracks,2);
	for t=1:N_tracks
		plot(tracks(t).x,tracks(t).y);		% 5. plot all tracks onto the black figure
	end
	drawnow;	%drawing ensures the right frame to be grabbed next
	I_screen = getframe(h);					% 6. grab the frame
	I_tracks = rgb2gray(I_screen.cdata);	% 7. convert to uint8 grayscale
	I_tracks = imageAdjust(I_tracks);		% 8. rescale
	I_tracks = double(mat2gray(I_tracks));	% 9. convert to 0-1 image

	
	%% making structured crosshair for current centroid
	crosshair = [0 0 1 0 0; 0 0 1 0 0; 1 1 1 1 1; 0 0 1 0 0; 0 0 1 0 0];
	
	%% making composite RGB video combining all info, and write to mp4
	if dimy>128 && dimx>128
		% writerObj = VideoWriter(filename,'MPEG-4');
		writerObj = VideoWriter(filename,'Motion JPEG AVI');
	else
		writerObj = VideoWriter(filename,'Motion JPEG AVI');
		% writerObj = VideoWriter(filename,'Uncompressed AVI'); % this is simply too big
	end
		
	writerObj.FrameRate = Pmov.fps;
	open(writerObj);
	fprintf('writeCompositeVideo2: original | box | boundary | centroid | tracks\r');
	fprintf('                      Output file: %s\r',filename);
	fprintf('                      Dimension: %dx%d\r',dimx,dimy);
	fprintf('                      fps: %4.2f\r',Pmov.fps);
	fprintf('                      ');
	N_frames = size(I_Box,2);
	
	I_Centroid_Accum = false(size(I_Centroid{1}));
	for i=1:N_frames
		% display progress every 5 frames
		displayMod = 10;
		if mod(i,displayMod)==0
			if i>(displayMod+1)
				for j=1:length(str_stat)
					fprintf('\b');
				end
			end
			str_stat = sprintf('Writing frames %d/%d',i,N_frames);
			fprintf('%s',str_stat);
		end
		I_Centroid_Accum = I_Centroid_Accum + I_Centroid{i};	% accumulating centroid
		I_BoxFull				= full(I_Box{i});				% convert from sparse matrix to full
		I_Centroid_AccumFull	= full(I_Centroid_Accum);
		I_CentroidFull			= conv2(full(I_Centroid{i}),crosshair,'same');
		I_BinaryFull			= full(I_Binary{i});
		I_CellBoundry			= bwperim(I_BinaryFull);
		
		% overlap colors
		I_composite(:,:,1) = frames{i}*0.5 + im2uint8(I_tracks)*0.4*showTrack;
		I_composite(:,:,2) = frames{i}*0.5 + im2uint8(I_BoxFull)*showBox;
		I_composite(:,:,3) = frames{i}*0.5  + im2uint8(I_BinaryFull).*(frames{i}+1)*0.5*showBin;
		
		% override colors for boundary and centroid
		r = I_composite(:,:,1);	
		g = I_composite(:,:,2);	
		b = I_composite(:,:,3);	
		
		r(I_CellBoundry) = 255;	
		g(I_CellBoundry) = 255;	
		b(I_CellBoundry) = 0;	

		r(I_Centroid_AccumFull==1) = 255;
		g(I_Centroid_AccumFull==1) = 64;
		b(I_Centroid_AccumFull==1) = 0;

		r(I_CentroidFull==1) = 0;
		g(I_CentroidFull==1) = 255;
		b(I_CentroidFull==1) = 0;
		
		I_composite(:,:,1)=r;
		I_composite(:,:,2)=g;
		I_composite(:,:,3)=b;
		
		writeVideo(writerObj,I_composite);
	end
	close(writerObj);
	cd(currentFolder);
	fprintf('\r                      (%4.2f s)\r',toc);
end